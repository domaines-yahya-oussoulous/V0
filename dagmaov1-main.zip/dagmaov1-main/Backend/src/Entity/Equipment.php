<?php

namespace App\Entity;

use ApiPlatform\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Get;
use ApiPlatform\Metadata\GetCollection;
use ApiPlatform\Metadata\Post;
use App\DTO\EquipmentDTO;
use App\Entity\Traits\CommonDate;
use App\Repository\EquipmentRepository;
use App\State\Processors\Equipment\CreateUpdateEquipmentProcessor;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\HasLifecycleCallbacks;
use Gedmo\Mapping\Annotation as Gedmo;
use Gedmo\SoftDeleteable\Traits\SoftDeleteableEntity;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\Serializer\Annotation\Groups;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use ApiPlatform\Doctrine\Orm\Filter\OrderFilter;

#[ORM\Entity(repositoryClass: EquipmentRepository::class)]
#[Gedmo\SoftDeleteable(fieldName: 'deletedAt', timeAware: false, hardDelete: true)]
#[HasLifecycleCallbacks]
#[ApiResource()]
#[Vich\Uploadable]
#[Post(
    input: EquipmentDTO::class,
    processor: CreateUpdateEquipmentProcessor::class,
    denormalizationContext: ['groups'=> ['writeEquipment']],
    name: 'EquipmentCreating',
    uriTemplate: 'equipments/add',
    inputFormats: ['multipart' => ['multipart/form-data']]
)]
#[GetCollection]
#[Get(
    name: 'gettingEquipmentById',
    uriTemplate: 'equipment/{id}',
    normalizationContext: ['groups'=> ['equipment:read']],
)]
#[Get(
    name: 'gettingEquipmentInterventions',
    uriTemplate: 'equipment/{id}/interventions',
    normalizationContext: ['groups'=> ['equipment-interventions:read']],
)]
#[Post(
    input: EquipmentDTO::class,
    processor: CreateUpdateEquipmentProcessor::class,
    denormalizationContext: ['groups'=> ['updateEquipment']],
    name: 'EquipmentUpdating',
    uriTemplate: 'equipments/{id}/update',
    inputFormats: ['multipart' => ['multipart/form-data']]
)]
#[Delete]
class Equipment
{
    use CommonDate;
    use SoftDeleteableEntity;

    #[Groups(['equipment:read'])]
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[ApiFilter(OrderFilter::class,strategy: 'DESC')]
    private ?int $id = null;

    #[Groups(['equipment:read','writeEquipment','updateEquipment','preventive-maintenance:read-collection','equipments-by-farm:read','preventive-maintenance:read','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    #[ApiFilter(SearchFilter::class,strategy: 'partial')]
    private ?string $name = null;

    #[Groups(['equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $categoryName = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $reference = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $inventoryCode = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[Vich\UploadableField(mapping: 'equipment', fileNameProperty: 'image', size: 'imageSize')]
    private ?File $imageFile = null;

    #[Groups(['equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $image = null;

    #[ORM\Column(nullable: true)]
    private ?int $imageSize = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $qrCode = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $family = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $brand = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $acquisitionDate = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(nullable: true)]
    private ?float $acquisitionCost = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(nullable: true)]
    private ?bool $underWarranty = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(nullable: true)]
    private ?array $gpsData = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $originalDomain = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $countingUnit = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?float $counter = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(nullable: true)]
    private ?float $useHoursNumber = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $lastMaintenanceDate = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $nextMaintenanceDate = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $lastBreakdownDate = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $lastBreakdownCause = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[Vich\UploadableField(mapping: 'technical_specification', fileNameProperty: 'technicalSpecificationName', size: 'technicalSpecificationSize')]
    private ?File $technicalSpecificationFile = null;

    #[Groups(['equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $technicalSpecificationName = null;

    #[ORM\Column(nullable: true)]
    private ?int $technicalSpecificationSize = null;

    #[Groups(['writeEquipment','updateEquipment'])]
    #[Vich\UploadableField(mapping: 'maintenance_range', fileNameProperty: 'maintenanceRangeName', size: 'maintenanceRangeSize')]
    private ?File $maintenanceRangeFile = null;

    #[Groups(['equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $maintenanceRangeName = null;

    #[ORM\Column(nullable: true)]
    private ?string $maintenanceRangeSize = null;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\ManyToOne(inversedBy: 'equipment')]
    private ?Farm $farm = null;

    #[Groups(['writeEquipment','updateEquipment'])]
    /**
     * @var Collection<int, SparePart>
     */
    #[ORM\ManyToMany(targetEntity: SparePart::class, mappedBy: 'equipment')]
    private Collection $spareParts;

    #[Groups(['writeEquipment','updateEquipment'])]
    /**
     * @var Collection<int, PreventiveMaintenance>
     */
    #[ORM\OneToMany(targetEntity: PreventiveMaintenance::class, mappedBy: 'equipmentToMaintain')]
    private Collection $preventiveMaintenances;

    #[Groups(['writeEquipment','updateEquipment'])]
    /**
     * @var Collection<int, CorrectiveMaintenance>
     */
    #[ORM\OneToMany(targetEntity: CorrectiveMaintenance::class, mappedBy: 'equipmentToMaintain')]
    private Collection $correctiveMaintenances;

    #[Groups(['writeEquipment','updateEquipment','equipment:read'])]
    #[ORM\ManyToOne(inversedBy: 'equipment')]
    private ?EquipmentCategory $equipmentCategory = null;

    public function __construct()
    {
        $this->spareParts = new ArrayCollection();
        $this->preventiveMaintenances = new ArrayCollection();
        $this->correctiveMaintenances = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }
    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getCategoryName(): ?string
    {
        return $this->categoryName;
    }

    public function setCategoryName(?string $categoryName): static
    {
        $this->categoryName = $categoryName;

        return $this;
    }

    public function getReference(): ?string
    {
        return $this->reference;
    }

    public function setReference(?string $reference): static
    {
        $this->reference = $reference;

        return $this;
    }

    public function getInventoryCode(): ?string
    {
        return $this->inventoryCode;
    }

    public function setInventoryCode(?string $inventoryCode): static
    {
        $this->inventoryCode = $inventoryCode;

        return $this;
    }

    public function setImageFile(?File $imageFile = null): void
    {
        $this->imageFile = $imageFile;

        if (null !== $imageFile) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
    }

    public function getImageFile(): ?File
    {
        return $this->imageFile;
    }

    public function getImage(): ?string
    {
        return $this->image;
    }

    public function setImage(?string $image): static
    {
        $this->image = $image;

        return $this;
    }

    public function setImageSize(?int $imageSize): void
    {
        $this->imageSize = $imageSize;
    }

    public function getImageSize(): ?int
    {
        return $this->imageSize;
    }

    public function getQrCode(): ?string
    {
        return $this->qrCode;
    }

    public function setQrCode(?string $qrCode): static
    {
        $this->qrCode = $qrCode;

        return $this;
    }

    public function getFamily(): ?string
    {
        return $this->family;
    }

    public function setFamily(?string $family): static
    {
        $this->family = $family;

        return $this;
    }


    public function getBrand(): ?string
    {
        return $this->brand;
    }

    public function setBrand(?string $brand): static
    {
        $this->brand = $brand;

        return $this;
    }

    public function getAcquisitionDate(): ?\DateTimeInterface
    {
        return $this->acquisitionDate;
    }

    public function setAcquisitionDate(?\DateTimeInterface $acquisitionDate): static
    {
        $this->acquisitionDate = $acquisitionDate;

        return $this;
    }

    public function getAcquisitionCost(): ?float
    {
        return $this->acquisitionCost;
    }

    public function setAcquisitionCost(?float $acquisitionCost): static
    {
        $this->acquisitionCost = $acquisitionCost;

        return $this;
    }

    public function isUnderWarranty(): ?bool
    {
        return $this->underWarranty;
    }

    public function setUnderWarranty(?bool $underWarranty): static
    {
        $this->underWarranty = $underWarranty;

        return $this;
    }

    public function getGpsData(): ?array
    {
        return $this->gpsData;
    }

    public function setGpsData(?array $gpsData): static
    {
        $this->gpsData = $gpsData;

        return $this;
    }


    public function getOriginalDomain(): ?string
    {
        return $this->originalDomain;
    }

    public function setOriginalDomain(?string $originalDomain): static
    {
        $this->originalDomain = $originalDomain;

        return $this;
    }

    public function getCountingUnit(): ?string
    {
        return $this->countingUnit;
    }

    public function setCountingUnit(?string $countingUnit): static
    {
        $this->countingUnit = $countingUnit;

        return $this;
    }

    public function getCounter(): ?float
    {
        return $this->counter;
    }

    public function setCounter(?float $counter): static
    {
        $this->counter = $counter;

        return $this;
    }

    public function getUseHoursNumber(): ?float
    {
        return $this->useHoursNumber;
    }

    public function setUseHoursNumber(?float $useHoursNumber): static
    {
        $this->useHoursNumber = $useHoursNumber;

        return $this;
    }

    public function getLastMaintenanceDate(): ?\DateTimeInterface
    {
        return $this->lastMaintenanceDate;
    }

    public function setLastMaintenanceDate(?\DateTimeInterface $lastMaintenanceDate): static
    {
        $this->lastMaintenanceDate = $lastMaintenanceDate;

        return $this;
    }


    public function getNextMaintenanceDate(): ?\DateTimeInterface
    {
        return $this->nextMaintenanceDate;
    }

    public function setNextMaintenanceDate(?\DateTimeInterface $nextMaintenanceDate): static
    {
        $this->nextMaintenanceDate = $nextMaintenanceDate;

        return $this;
    }

    public function getLastBreakdownDate(): ?\DateTimeInterface
    {
        return $this->lastBreakdownDate;
    }

    public function setLastBreakdownDate(?\DateTimeInterface $lastBreakdownDate): static
    {
        $this->lastBreakdownDate = $lastBreakdownDate;

        return $this;
    }

    public function getLastBreakdownCause(): ?string
    {
        return $this->lastBreakdownCause;
    }

    public function setLastBreakdownCause(?string $lastBreakdownCause): static
    {
        $this->lastBreakdownCause = $lastBreakdownCause;

        return $this;
    }

    public function setTechnicalSpecificationFile(?File $technicalSpecificationFile = null): void
    {
        $this->technicalSpecificationFile = $technicalSpecificationFile;

        if (null !== $technicalSpecificationFile) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
    }

    public function getTechnicalSpecificationFile(): ?File
    {
        return $this->technicalSpecificationFile;
    }

    public function getTechnicalSpecificationName(): ?string
    {
        return $this->technicalSpecificationName;
    }

    public function setTechnicalSpecificationName(?string $technicalSpecificationName): static
    {
        $this->technicalSpecificationName = $technicalSpecificationName;

        return $this;
    }

    public function getTechnicalSpecificationSize(): ?int
    {
        return $this->technicalSpecificationSize;
    }

    public function setTechnicalSpecificationSize(?int $technicalSpecificationSize): static
    {
        $this->technicalSpecificationSize = $technicalSpecificationSize;

        return $this;
    }

    public function setMaintenanceRangeFile(?File $maintenanceRangeFile = null): void
    {
        $this->maintenanceRangeFile = $maintenanceRangeFile;

        if (null !== $maintenanceRangeFile) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
    }

    public function getMaintenanceRangeFile(): ?File
    {
        return $this->maintenanceRangeFile;
    }

    public function getMaintenanceRangeName(): ?string
    {
        return $this->maintenanceRangeName;
    }

    public function setMaintenanceRangeName(?string $maintenanceRangeName): static
    {
        $this->maintenanceRangeName = $maintenanceRangeName;

        return $this;
    }

    public function getMaintenanceRangeSize(): ?string
    {
        return $this->maintenanceRangeSize;
    }

    public function setMaintenanceRangeSize(?string $maintenanceRangeSize): static
    {
        $this->maintenanceRangeSize = $maintenanceRangeSize;

        return $this;
    }

    public function getFarm(): ?Farm
    {
        return $this->farm;
    }

    public function setFarm(?Farm $farm): static
    {
        $this->farm = $farm;

        return $this;
    }

    /**
     * @return Collection<int, SparePart>
     */
    public function getSpareParts(): Collection
    {
        return $this->spareParts;
    }

    public function addSparePart(SparePart $sparePart): static
    {
        if (!$this->spareParts->contains($sparePart)) {
            $this->spareParts->add($sparePart);
            $sparePart->addEquipment($this);
        }

        return $this;
    }

    public function removeSparePart(SparePart $sparePart): static
    {
        if ($this->spareParts->removeElement($sparePart)) {
            $sparePart->removeEquipment($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, PreventiveMaintenance>
     */
    public function getPreventiveMaintenances(): Collection
    {
        return $this->preventiveMaintenances;
    }

    public function addPreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if (!$this->preventiveMaintenances->contains($preventiveMaintenance)) {
            $this->preventiveMaintenances->add($preventiveMaintenance);
            $preventiveMaintenance->setEquipmentToMaintain($this);
        }

        return $this;
    }

    public function removePreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if ($this->preventiveMaintenances->removeElement($preventiveMaintenance)) {
            // set the owning side to null (unless already changed)
            if ($preventiveMaintenance->getEquipmentToMaintain() === $this) {
                $preventiveMaintenance->setEquipmentToMaintain(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, CorrectiveMaintenance>
     */
    public function getCorrectiveMaintenances(): Collection
    {
        return $this->correctiveMaintenances;
    }

    public function addCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if (!$this->correctiveMaintenances->contains($correctiveMaintenance)) {
            $this->correctiveMaintenances->add($correctiveMaintenance);
            $correctiveMaintenance->setEquipmentToMaintain($this);
        }

        return $this;
    }

    public function removeCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if ($this->correctiveMaintenances->removeElement($correctiveMaintenance)) {
            // set the owning side to null (unless already changed)
            if ($correctiveMaintenance->getEquipmentToMaintain() === $this) {
                $correctiveMaintenance->setEquipmentToMaintain(null);
            }
        }

        return $this;
    }

    //this is for removing image when updating equipment
    #[PreUpdate]
    public function preUpdate(): void
    {
        if ($this->imageFile === null && $this->image !== null) {
            $this->removeImage();
        }
    }

    public function getEquipmentCategory(): ?EquipmentCategory
    {
        return $this->equipmentCategory;
    }

    public function setEquipmentCategory(?EquipmentCategory $equipmentCategory): static
    {
        $this->equipmentCategory = $equipmentCategory;

        return $this;
    }

    #[Groups(['equipment-interventions:read'])]
    public function getInterventions(): ?array
    {
        $interventions = $this->equipmentCategory->getInterventions();

        if ($interventions === null) {
            return null;
        }

        return array_map(function ($intervention) {
            return [
                'id' => $intervention->getId(),
                'name' => $intervention->getName(),
                'apiId' => "/api/interventions/{$intervention->getId()}",
            ];
        }, $interventions->toArray());
    }
}
