<?php

namespace App\Entity;

use ApiPlatform\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Get;
use ApiPlatform\Metadata\GetCollection;
use ApiPlatform\Metadata\Post;
use App\Repository\InterventionRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Serializer\Annotation\Groups;

#[ApiResource()]
#[Post(
    denormalizationContext: ['groups'=> ['intervention:write']],
    name: 'InterventionAdding',
    uriTemplate: 'intervention/add',
)]
#[Get(
    normalizationContext: ['groups'=> ['intervention-operations:read']],
    name: 'InterventionOperationsById',
    uriTemplate: 'intervention-operations/{id}',
)]
#[GetCollection(
    normalizationContext: ['groups'=> ['intervention:read-collection']],
    name: 'AllInterventions',
    uriTemplate: 'interventions',
)]
#[Get]
#[Delete]
#[UniqueEntity('name')]
#[ORM\Entity(repositoryClass: InterventionRepository::class)]
class Intervention
{
    #[Groups(['intervention:read-collection','equipment-category-interventions:read'])]
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[Groups(['intervention:write','intervention:read-collection','equipment-category-interventions:read','intervention-operations:read'])]
    #[ApiFilter(SearchFilter::class,strategy: 'partial')]
    #[ORM\Column(length: 255)]
    private ?string $name = null;

    /**
     * @var Collection<int, EquipmentCategory>
     */
    #[ORM\ManyToMany(targetEntity: EquipmentCategory::class, inversedBy: 'interventions')]
    private Collection $equipmentCategories;

    /**
     * @var Collection<int, Operation>
     */
    #[Groups(['intervention:write','intervention-operations:read'])]
    #[ORM\OneToMany(targetEntity: Operation::class, mappedBy: 'intervention', cascade: ['persist', 'remove'])]
    private Collection $operations;

    /**
     * @var Collection<int, PreventiveMaintenance>
     */
    #[ORM\OneToMany(targetEntity: PreventiveMaintenance::class, mappedBy: 'intervention')]
    private Collection $preventiveMaintenances;

    /**
     * @var Collection<int, CorrectiveMaintenance>
     */
    #[ORM\OneToMany(targetEntity: CorrectiveMaintenance::class, mappedBy: 'intervention')]
    private Collection $correctiveMaintenances;

    public function __construct()
    {
        $this->equipmentCategories = new ArrayCollection();
        $this->operations = new ArrayCollection();
        $this->preventiveMaintenances = new ArrayCollection();
        $this->correctiveMaintenances = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return Collection<int, EquipmentCategory>
     */
    public function getEquipmentCategories(): Collection
    {
        return $this->equipmentCategories;
    }

    public function addEquipmentCategory(EquipmentCategory $equipmentCategory): static
    {
        if (!$this->equipmentCategories->contains($equipmentCategory)) {
            $this->equipmentCategories->add($equipmentCategory);
        }

        return $this;
    }

    public function removeEquipmentCategory(EquipmentCategory $equipmentCategory): static
    {
        $this->equipmentCategories->removeElement($equipmentCategory);

        return $this;
    }

    /**
     * @return Collection<int, Operation>
     */
    public function getOperations(): Collection
    {
        return $this->operations;
    }

    public function addOperation(Operation $operation): static
    {
        if (!$this->operations->contains($operation)) {
            $this->operations->add($operation);
            $operation->setIntervention($this);
        }

        return $this;
    }

    public function removeOperation(Operation $operation): static
    {
        if ($this->operations->removeElement($operation)) {
            // set the owning side to null (unless already changed)
            if ($operation->getIntervention() === $this) {
                $operation->setIntervention(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, PreventiveMaintenance>
     */
    public function getPreventiveMaintenances(): Collection
    {
        return $this->preventiveMaintenances;
    }

    public function addPreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if (!$this->preventiveMaintenances->contains($preventiveMaintenance)) {
            $this->preventiveMaintenances->add($preventiveMaintenance);
            $preventiveMaintenance->setIntervention($this);
        }

        return $this;
    }

    public function removePreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if ($this->preventiveMaintenances->removeElement($preventiveMaintenance)) {
            // set the owning side to null (unless already changed)
            if ($preventiveMaintenance->getIntervention() === $this) {
                $preventiveMaintenance->setIntervention(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, CorrectiveMaintenance>
     */
    public function getCorrectiveMaintenances(): Collection
    {
        return $this->correctiveMaintenances;
    }

    public function addCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if (!$this->correctiveMaintenances->contains($correctiveMaintenance)) {
            $this->correctiveMaintenances->add($correctiveMaintenance);
            $correctiveMaintenance->setIntervention($this);
        }

        return $this;
    }

    public function removeCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if ($this->correctiveMaintenances->removeElement($correctiveMaintenance)) {
            // set the owning side to null (unless already changed)
            if ($correctiveMaintenance->getIntervention() === $this) {
                $correctiveMaintenance->setIntervention(null);
            }
        }

        return $this;
    }
}
