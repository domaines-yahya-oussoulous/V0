<?php

namespace App\Entity;

use App\Repository\CorrectiveMaintenanceImageRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\Serializer\Annotation\Groups;
use Vich\UploaderBundle\Mapping\Annotation as Vich;

#[ORM\Entity(repositoryClass: CorrectiveMaintenanceImageRepository::class)]
#[Vich\Uploadable]
class CorrectiveMaintenanceImage
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[Vich\UploadableField(mapping: 'corrective_maintenance', fileNameProperty: 'imageName')]
    private ?File $imageFile = null;

    #[ORM\Column(length: 255, nullable: true)]
    #[Groups(['corrective-maintenance:read','corrective-maintenance:write'])]
    private ?string $imageName = null;

    #[ORM\ManyToOne(inversedBy: 'correctiveMaintenanceImages')]
    private ?CorrectiveMaintenance $correctiveMaintenance = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getImageFile(): ?File
    {
        return $this->imageFile;
    }

    public function setImageFile(?File $imageFile): self
    {
        $this->imageFile = $imageFile;
        return $this;
    }

    public function getImageName(): ?string
    {
        return $this->imageName;
    }

    public function setImageName(?string $imageName): static
    {
        $this->imageName = $imageName;

        return $this;
    }

    public function getCorrectiveMaintenance(): ?CorrectiveMaintenance
    {
        return $this->correctiveMaintenance;
    }

    public function setCorrectiveMaintenance(?CorrectiveMaintenance $correctiveMaintenance): static
    {
        $this->correctiveMaintenance = $correctiveMaintenance;

        return $this;
    }
}
