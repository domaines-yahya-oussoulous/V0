<?php

namespace App\Entity;

use ApiPlatform\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Get;
use ApiPlatform\Metadata\GetCollection;
use ApiPlatform\Metadata\Patch;
use ApiPlatform\Metadata\Post;
use App\DTO\CorrectiveMaintenanceDTO;
use App\Entity\Traits\CommonDate;
use App\Repository\CorrectiveMaintenanceRepository;
use App\State\Processors\CorrectiveMaintenance\CreateCorrectiveMaintenanceProcessor;
use App\State\Processors\CorrectiveMaintenance\InvalidateCorrectiveMaintenance;
use App\State\Processors\CorrectiveMaintenance\MarkCorrectiveMaintenanceAsCompleted;
use App\State\Processors\CorrectiveMaintenance\MarkCorrectiveMaintenanceAsInProgress;
use App\State\Processors\CorrectiveMaintenance\ValidateCorrectiveMaintenance;
use App\State\Providers\CorrectiveMaintenance\CountCorrectiveMaintenanceByFarmIdsProvider;
use App\State\Providers\CorrectiveMaintenance\CountCorrectiveMaintenanceByStateProvider;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\HasLifecycleCallbacks;
use Symfony\Component\Serializer\Annotation\Groups;
use ApiPlatform\Doctrine\Orm\Filter\OrderFilter;
use Symfony\Component\Validator\Constraints as Assert;


#[ORM\Entity(repositoryClass: CorrectiveMaintenanceRepository::class)]
#[HasLifecycleCallbacks]
#[ApiResource()]
#[Post(
    input: CorrectiveMaintenanceDTO::class,
    processor: CreateCorrectiveMaintenanceProcessor::class,
    denormalizationContext: ['groups'=> ['corrective-maintenance:write']],
    normalizationContext: ['groups'=> ['corrective-maintenance:write']],
    name: 'CorrectivemaintenanceCreating',
    uriTemplate: 'corrective-maintenance/add',
    inputFormats: ['multipart' => ['multipart/form-data']]
)]
#[GetCollection(
    normalizationContext: ['groups'=> ['corrective-maintenance:read-collection']],
    //name: 'PreventiveMaintenanceCreating',
    //uriTemplate: 'preventive-maintenance/add',
)]
#[Get(
    normalizationContext: ['groups'=> ['corrective-maintenance:read']],
    name: 'CorrectiveMaintenanceById',
    uriTemplate: 'corrective-maintenance/{id}',
)]
#[Patch(
    processor: ValidateCorrectiveMaintenance::class,
    denormalizationContext: ['groups'=> ['corrective-maintenance:validate']],
    name: 'ValidatingCorrectiveMaintenance',
    uriTemplate: '/corrective-maintenances/{id}/validate'
)]
#[Patch(
    processor: InvalidateCorrectiveMaintenance::class,
    denormalizationContext: ['groups'=> ['corrective-maintenance:invalidate']],
    name: 'InValidatingCorrectiveMaintenance',
    uriTemplate: '/corrective-maintenances/{id}/invalidate'
)]
#[Patch(
    processor: MarkCorrectiveMaintenanceAsInProgress::class,
    denormalizationContext: ['groups'=> ['corrective-maintenance:mark-as-in-progress']],
    name: 'MarkAsInProgressCorrectiveMaintenance',
    uriTemplate: '/corrective-maintenances/{id}/mark-as-in-progress'
)]
#[Patch(
    processor: MarkCorrectiveMaintenanceAsCompleted::class,
    denormalizationContext: ['groups'=> ['corrective-maintenance:mark-as-completed']],
    name: 'MarkAsCompletedCorrectiveMaintenance',
    uriTemplate: '/corrective-maintenances/{id}/mark-as-completed'
)]
#[Patch(
    //processor: MarkCorrectiveMaintenanceAsCompleted::class,
    denormalizationContext: ['groups'=> ['corrective-maintenance-operations:edit']],
    name: 'AffectingOperationsCorrectiveMaintenance',
    uriTemplate: '/corrective-maintenances/{id}/operations'
)]
#[Get(
    provider: CountCorrectiveMaintenanceByStateProvider::class,
    uriTemplate: 'count-corrective-maintenances-by-state/{farmsId}/{state}',
    uriVariables: ['farmsId','state']
)]
#[Get(
    provider: CountCorrectiveMaintenanceByFarmIdsProvider::class,
    uriTemplate: 'count-corrective-maintenances-by-farm/{farmsId}',
    uriVariables: ['farmsId']
)]
#[Delete]
class CorrectiveMaintenance
{
    use CommonDate;
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[Groups(['corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ApiFilter(OrderFilter::class,strategy: 'DESC')]
    private ?int $id = null;

    #[ApiFilter(SearchFilter::class,strategy: 'partial')]
    #[Groups(['corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $equipmentName = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $failureType = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $failureDescription = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $breakdownTime = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $breakdownSite = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(nullable: true)]
    private ?int $estimatedDownTime = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $estimatedDownTimeUnit = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $breakdownProbableCause = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $urgencyLevel = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(nullable: true)]
    private ?int $interventionEstimatedDuration = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(nullable: true)]
    private ?string $interventionEstimatedDurationUnit = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $estimatedInterventionDate = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $personnelType = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\ManyToOne(inversedBy: 'correctiveMaintenances')]
    private ?Equipment $equipmentToMaintain = null;

    /**
     * @var Collection<int, SparePart>
     */
    #[ORM\ManyToMany(targetEntity: SparePart::class, inversedBy: 'correctiveMaintenances')]
    private Collection $sparePartsToUse;

    /**
     * @var Collection<int, SparePartCorrectiveMaintenanceQuantity>
     */
    #[ORM\OneToMany(targetEntity: SparePartCorrectiveMaintenanceQuantity::class, mappedBy: 'CorrectiveMaintenance', cascade: ['persist', 'remove'])]
    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    private Collection $sparePartCorrectiveMaintenanceQuantities;

    /**
     * @var Collection<int, CorrectiveMaintenanceImage>
     */
    #[ORM\OneToMany(targetEntity: CorrectiveMaintenanceImage::class, mappedBy: 'correctiveMaintenance', cascade: ['persist', 'remove'])]
    #[Groups(['corrective-maintenance:read'])]
    private Collection $images;

    /**
     * @var Collection<int, User>
     */
    #[ORM\ManyToMany(targetEntity: User::class, inversedBy: 'correctiveMaintenances')]
    #[Groups(['corrective-maintenance:write','corrective-maintenance:read'])]
    private Collection $PersonnelInCharge;

    #[Assert\Choice(["PLANNED", "IN_PROGRESS", "COMPLETED", "NON_VALIDATED", "WAITING_FOR_VALIDATION"])]
    #[Groups(['corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $state = null;

    #[ORM\ManyToOne(inversedBy: 'correctiveMaintenances')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Intervention $intervention = null;

    /**
     * @var Collection<int, Operation>
     */

    #[Groups(['corrective-maintenance-operations:edit'])]
    #[ORM\ManyToMany(targetEntity: Operation::class, inversedBy: 'correctiveMaintenances')]
    private Collection $operations;

    #[Groups(['corrective-maintenance:read','corrective-maintenance-operations:edit'])]
    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $tasksDescription = null;

    #[Groups(['corrective-maintenance:mark-as-completed','corrective-maintenance:read'])]
    #[ORM\Column(nullable: true)]
    private ?int $realDownTime = null;

    #[Groups(['corrective-maintenance:mark-as-completed','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $realDownTimeUnit = null;

    #[Groups(['corrective-maintenance:mark-as-completed','corrective-maintenance:read'])]
    #[ORM\Column(nullable: true)]
    private ?int $interventionRealDuration = null;

    #[Groups(['corrective-maintenance:mark-as-completed','corrective-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $interventionRealDurationUnit = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $completionDate = null;

    public function __construct()
    {
        $this->sparePartsToUse = new ArrayCollection();
        $this->sparePartCorrectiveMaintenanceQuantities = new ArrayCollection();
        $this->images = new ArrayCollection();
        $this->PersonnelInCharge = new ArrayCollection();
        $this->operations = new ArrayCollection();
    }

    #[ORM\PreUpdate]
    public function preUpdate(): void
    {
        if ($this->state === "COMPLETED" && $this->completionDate === null) {
            $this->completionDate = new \DateTimeImmutable();
        }
    }

    public function getId(): ?int
    {
        return $this->id;
    }
    public function getEquipmentName(): ?string
    {
        return $this->equipmentName;
    }

    public function setEquipmentName(?string $equipmentName): static
    {
        $this->equipmentName = $equipmentName;

        return $this;
    }

    public function getFailureType(): ?string
    {
        return $this->failureType;
    }

    public function setFailureType(?string $failureType): static
    {
        $this->failureType = $failureType;

        return $this;
    }

    public function getFailureDescription(): ?string
    {
        return $this->failureDescription;
    }

    public function setFailureDescription(?string $failureDescription): static
    {
        $this->failureDescription = $failureDescription;

        return $this;
    }

    public function getBreakdownTime(): ?\DateTimeInterface
    {
        return $this->breakdownTime;
    }

    public function setBreakdownTime(?\DateTimeInterface $breakdownTime): static
    {
        $this->breakdownTime = $breakdownTime;

        return $this;
    }

    public function getBreakdownSite(): ?string
    {
        return $this->breakdownSite;
    }

    public function setBreakdownSite(?string $breakdownSite): static
    {
        $this->breakdownSite = $breakdownSite;

        return $this;
    }

    public function getEstimatedDownTime(): ?int
    {
        return $this->estimatedDownTime;
    }

    public function setEstimatedDownTime(?int $estimatedDownTime): static
    {
        $this->estimatedDownTime = $estimatedDownTime;

        return $this;
    }
    public function getEstimatedDownTimeUnit(): ?string
    {
        return $this->estimatedDownTimeUnit;
    }

    public function setEstimatedDownTimeUnit(?string $estimatedDownTimeUnit): static
    {
        $this->estimatedDownTimeUnit = $estimatedDownTimeUnit;

        return $this;
    }

    public function getBreakdownProbableCause(): ?string
    {
        return $this->breakdownProbableCause;
    }

    public function setBreakdownProbableCause(?string $breakdownProbableCause): static
    {
        $this->breakdownProbableCause = $breakdownProbableCause;

        return $this;
    }

    public function getUrgencyLevel(): ?string
    {
        return $this->urgencyLevel;
    }

    public function setUrgencyLevel(?string $urgencyLevel): static
    {
        $this->urgencyLevel = $urgencyLevel;

        return $this;
    }

    public function getInterventionEstimatedDuration(): ?int
    {
        return $this->interventionEstimatedDuration;
    }

    public function setInterventionEstimatedDuration(?int $interventionEstimatedDuration): static
    {
        $this->interventionEstimatedDuration = $interventionEstimatedDuration;

        return $this;
    }

    public function getInterventionEstimatedDurationUnit(): ?string
    {
        return $this->interventionEstimatedDurationUnit;
    }

    public function setInterventionEstimatedDurationUnit(?string $interventionEstimatedDurationUnit): static
    {
        $this->interventionEstimatedDurationUnit = $interventionEstimatedDurationUnit;

        return $this;
    }

    public function getEstimatedInterventionDate(): ?\DateTimeInterface
    {
        return $this->estimatedInterventionDate;
    }

    public function setEstimatedInterventionDate(?\DateTimeInterface $estimatedInterventionDate): static
    {
        $this->estimatedInterventionDate = $estimatedInterventionDate;

        return $this;
    }

    public function getPersonnelType(): ?string
    {
        return $this->personnelType;
    }

    public function setPersonnelType(?string $personnelType): static
    {
        $this->personnelType = $personnelType;

        return $this;
    }

    public function getEquipmentToMaintain(): ?Equipment
    {
        return $this->equipmentToMaintain;
    }

    public function setEquipmentToMaintain(?Equipment $equipmentToMaintain): static
    {
        $this->equipmentToMaintain = $equipmentToMaintain;

        return $this;
    }

    /**
     * @return Collection<int, SparePart>
     */
    public function getSparePartsToUse(): Collection
    {
        return $this->sparePartsToUse;
    }

    public function addSparePartsToUse(SparePart $sparePartsToUse): static
    {
        if (!$this->sparePartsToUse->contains($sparePartsToUse)) {
            $this->sparePartsToUse->add($sparePartsToUse);
        }

        return $this;
    }

    public function removeSparePartsToUse(SparePart $sparePartsToUse): static
    {
        $this->sparePartsToUse->removeElement($sparePartsToUse);

        return $this;
    }

    /**
     * @return Collection<int, SparePartCorrectiveMaintenanceQuantity>
     */
    public function getSparePartCorrectiveMaintenanceQuantities(): Collection
    {
        return $this->sparePartCorrectiveMaintenanceQuantities;
    }

    public function addSparePartCorrectiveMaintenanceQuantity(SparePartCorrectiveMaintenanceQuantity $sparePartCorrectiveMaintenanceQuantity): static
    {
        if (!$this->sparePartCorrectiveMaintenanceQuantities->contains($sparePartCorrectiveMaintenanceQuantity)) {
            $this->sparePartCorrectiveMaintenanceQuantities->add($sparePartCorrectiveMaintenanceQuantity);
            $sparePartCorrectiveMaintenanceQuantity->setCorrectiveMaintenance($this);
        }

        return $this;
    }

    public function removeSparePartCorrectiveMaintenanceQuantity(SparePartCorrectiveMaintenanceQuantity $sparePartCorrectiveMaintenanceQuantity): static
    {
        if ($this->sparePartCorrectiveMaintenanceQuantities->removeElement($sparePartCorrectiveMaintenanceQuantity)) {
            // set the owning side to null (unless already changed)
            if ($sparePartCorrectiveMaintenanceQuantity->getCorrectiveMaintenance() === $this) {
                $sparePartCorrectiveMaintenanceQuantity->setCorrectiveMaintenance(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, CorrectiveMaintenanceImage>
     */
    public function getImages(): Collection
    {
        return $this->images;
    }

    public function addImage(CorrectiveMaintenanceImage $image): self
    {
        if (!$this->images->contains($image)) {
            $this->images->add($image);
            $image->setCorrectiveMaintenance($this);
        }

        return $this;
    }

    public function removeImage(CorrectiveMaintenanceImage $image): self
    {
        $this->images->removeElement($image);
        $image->setCorrectiveMaintenance(null);

        return $this;
    }

    /**
     * @return Collection<int, User>
     */
    public function getPersonnelInCharge(): Collection
    {
        return $this->PersonnelInCharge;
    }

    public function addPersonnelInCharge(User $personnelInCharge): static
    {
        if (!$this->PersonnelInCharge->contains($personnelInCharge)) {
            $this->PersonnelInCharge->add($personnelInCharge);
        }

        return $this;
    }

    public function removePersonnelInCharge(User $personnelInCharge): static
    {
        $this->PersonnelInCharge->removeElement($personnelInCharge);

        return $this;
    }

    public function getState(): ?string
    {
        return $this->state;
    }

    public function setState(?string $state): static
    {
        $this->state = $state;

        return $this;
    }

    public function getIntervention(): ?Intervention
    {
        return $this->intervention;
    }

    public function setIntervention(?Intervention $intervention): static
    {
        $this->intervention = $intervention;

        return $this;
    }

    /**
     * @return Collection<int, Operation>
     */
    public function getOperations(): Collection
    {
        return $this->operations;
    }

    public function addOperation(Operation $operation): static
    {
        if (!$this->operations->contains($operation)) {
            $this->operations->add($operation);
        }

        return $this;
    }

    public function removeOperation(Operation $operation): static
    {
        $this->operations->removeElement($operation);

        return $this;
    }

    public function getTasksDescription(): ?string
    {
        return $this->tasksDescription;
    }

    public function setTasksDescription(?string $tasksDescription): static
    {
        $this->tasksDescription = $tasksDescription;

        return $this;
    }

    #[Groups(['corrective-maintenance:read','corrective-maintenance:read-collection'])]
    public function getInterventionDetails(): array
    {
        return [
            'id' => $this->intervention->getId(),
            'name' => $this->intervention->getName(),
        ];
    }
    #[Groups(['corrective-maintenance:read'])]
    public function getOperationsDetails(): array
    {
        $descriptions = [];

        foreach ($this->operations as $operation) {
            $descriptions[] = $operation->getDescription();
        }

        return $descriptions;
    }

    public function getRealDownTime(): ?int
    {
        return $this->realDownTime;
    }

    public function setRealDownTime(?int $realDownTime): static
    {
        $this->realDownTime = $realDownTime;

        return $this;
    }

    public function getRealDownTimeUnit(): ?string
    {
        return $this->realDownTimeUnit;
    }

    public function setRealDownTimeUnit(?string $realDownTimeUnit): static
    {
        $this->realDownTimeUnit = $realDownTimeUnit;

        return $this;
    }

    public function getInterventionRealDuration(): ?int
    {
        return $this->interventionRealDuration;
    }

    public function setInterventionRealDuration(?int $interventionRealDuration): static
    {
        $this->interventionRealDuration = $interventionRealDuration;

        return $this;
    }

    public function getInterventionRealDurationUnit(): ?string
    {
        return $this->interventionRealDurationUnit;
    }

    public function setInterventionRealDurationUnit(?string $interventionRealDurationUnit): static
    {
        $this->interventionRealDurationUnit = $interventionRealDurationUnit;

        return $this;
    }
    public function getCompletionDate(): ?\DateTimeInterface
    {
        return $this->completionDate;
    }

    public function setCompletionDate(?\DateTimeInterface $completionDate): static
    {
        $this->completionDate = $completionDate;

        return $this;
    }
}
