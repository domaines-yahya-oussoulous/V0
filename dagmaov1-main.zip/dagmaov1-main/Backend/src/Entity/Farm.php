<?php

namespace App\Entity;

use ApiPlatform\Doctrine\Orm\Filter\OrderFilter;
use ApiPlatform\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Get;
use ApiPlatform\Metadata\GetCollection;
use ApiPlatform\Metadata\Post;
use App\Entity\Traits\CommonDate;
use App\Repository\FarmRepository;
use App\State\Processors\Farm\CreateFarmProcessor;
use App\State\Providers\User\TechniciansProvider;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\HasLifecycleCallbacks;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;


#[ORM\Entity(repositoryClass: FarmRepository::class)]
#[HasLifecycleCallbacks]
#[ApiResource()]
#[Get(
    normalizationContext: ['groups'=> ['equipments-by-farm:read']],
    name: 'EquipmentsByFarm',
    uriTemplate: 'equipments-by-farm/{id}',
)]
#[Get(
    provider: TechniciansProvider::class,
    normalizationContext: ['groups'=> ['technicians-by-farm:read']],
    name: 'TechniciansByFarm',
    uriTemplate: 'technicians-by-farm/{id}',
)]
#[Get(
    normalizationContext: ['groups'=> ['spare-parts-by-farm:read']],
    name: 'SparePartsByFarm',
    uriTemplate: 'spare-parts-by-farm/{id}',
)]
#[GetCollection(
    normalizationContext: ['groups'=> ['spare-parts-by-farm:read-collection']]
)]
#[Get]
#[Post(
    processor: CreateFarmProcessor::class
)]
#[Delete]
#[UniqueEntity('name')]
class Farm
{
    use CommonDate;
    #[ApiFilter(OrderFilter::class,strategy: 'DESC')]
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[Groups(['getUser','spare-parts-by-farm:read-collection','equipment:read'])]
    private ?int $id = null;

    #[ApiFilter(SearchFilter::class,strategy: 'partial')]
    #[Groups(['equipments-by-farm:read','technicians-by-farm:read','getUser','spare-parts-by-farm:read-collection','user:read-collecton','equipment:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $name = null;

    #[Groups(['spare-parts-by-farm:read-collection'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $reference = null;

    #[Groups(['spare-parts-by-farm:read-collection'])]
    #[ORM\Column(length: 255)]
    private ?string $cityName = null;

    #[Groups(['spare-parts-by-farm:read-collection'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $location = null;

    /**
     * @var Collection<int, Equipment>
     */
    #[ORM\OneToMany(targetEntity: Equipment::class, mappedBy: 'farm')]
    #[Groups(['equipments-by-farm:read'])]
    private Collection $equipment;

    /**
     * @var Collection<int, SparePart>
     */
    #[ORM\OneToMany(targetEntity: SparePart::class, mappedBy: 'farm')]
    #[Groups(['spare-parts-by-farm:read'])]
    private Collection $spareParts;

    /**
     * @var Collection<int, User>
     */
    #[ORM\OneToMany(targetEntity: User::class, mappedBy: 'farm')]
    #[Groups(['technicians-by-farm:read'])]
    private Collection $users;

    #[Assert\NotBlank]
    #[ORM\ManyToOne(inversedBy: 'farms')]
    private ?City $city = null;



    public function __construct()
    {
        $this->equipment = new ArrayCollection();
        $this->spareParts = new ArrayCollection();
        $this->users = new ArrayCollection();
    }


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getReference(): ?string
    {
        return $this->reference;
    }

    public function setReference(?string $reference): static
    {
        $this->reference = $reference;

        return $this;
    }

    public function getCityName(): ?string
    {
        return $this->cityName;
    }

    public function setCityName(string $cityName): static
    {
        $this->cityName = $cityName;

        return $this;
    }

    public function getLocation(): ?string
    {
        return $this->location;
    }

    public function setLocation(?string $location): static
    {
        $this->location = $location;

        return $this;
    }

    /**
     * @return Collection<int, Equipment>
     */
    public function getEquipment(): Collection
    {
        return $this->equipment;
    }

    public function addEquipment(Equipment $equipment): static
    {
        if (!$this->equipment->contains($equipment)) {
            $this->equipment->add($equipment);
            $equipment->setFarm($this);
        }

        return $this;
    }

    public function removeEquipment(Equipment $equipment): static
    {
        if ($this->equipment->removeElement($equipment)) {
            // set the owning side to null (unless already changed)
            if ($equipment->getFarm() === $this) {
                $equipment->setFarm(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, SparePart>
     */
    public function getSpareParts(): Collection
    {
        return $this->spareParts;
    }

    public function addSparePart(SparePart $sparePart): static
    {
        if (!$this->spareParts->contains($sparePart)) {
            $this->spareParts->add($sparePart);
            $sparePart->setFarm($this);
        }

        return $this;
    }

    public function removeSparePart(SparePart $sparePart): static
    {
        if ($this->spareParts->removeElement($sparePart)) {
            // set the owning side to null (unless already changed)
            if ($sparePart->getFarm() === $this) {
                $sparePart->setFarm(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, User>
     */
    public function getUsers(): Collection
    {
        return $this->users;
    }

    public function addUser(User $user): static
    {
        if (!$this->users->contains($user)) {
            $this->users->add($user);
            $user->setFarm($this);
        }

        return $this;
    }

    public function removeUser(User $user): static
    {
        if ($this->users->removeElement($user)) {
            // set the owning side to null (unless already changed)
            if ($user->getFarm() === $this) {
                $user->setFarm(null);
            }
        }

        return $this;
    }

    public function getCity(): ?City
    {
        return $this->city;
    }

    public function setCity(?City $city): static
    {
        $this->city = $city;

        return $this;
    }



}
