<?php

namespace App\Entity;

use ApiPlatform\Doctrine\Orm\Filter\OrderFilter;
use ApiPlatform\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Get;
use ApiPlatform\Metadata\GetCollection;
use ApiPlatform\Metadata\Patch;
use ApiPlatform\Metadata\Post;
use App\Entity\Traits\CommonDate;
use App\Repository\EquipmentCategoryRepository;
use App\State\Providers\EquipmentCategory\EquipmentsCountByCategoryProvider;
use App\State\Providers\EquipmentCategory\MaintenanceRatioByCategoryProvider;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\HasLifecycleCallbacks;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\Serializer\Annotation\Groups;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Symfony\Component\Validator\Constraints as Assert;

#[ApiResource()]
#[Vich\Uploadable]
#[Post(
    denormalizationContext: ['groups'=> ['equipment-category:write']],
    name: 'EquipmentCategoryCreating',
    uriTemplate: 'equipment-categories/add',
    inputFormats: ['multipart' => ['multipart/form-data']]
)]
#[Get(
    normalizationContext: ['groups'=> ['equipment-category:read']],
)]
#[Get(
    normalizationContext: ['groups'=> ['equipment-category-interventions:read']],
    uriTemplate: 'equipment-category/{id}/interventions',
)]
#[Get(
    provider: EquipmentsCountByCategoryProvider::class,
    //normalizationContext: ['groups'=> ['equipment-category:read']],
    uriTemplate: 'count-equipments-by-categories'
)]
#[GetCollection(
    normalizationContext: ['groups'=> ['equipment-category:read-collection']]
)]
#[GetCollection(
    normalizationContext: ['groups'=> ['equipment-category:read-collection-brief']],
    uriTemplate: 'equipment-categories-brief',
    paginationEnabled: false
)]
#[Delete]
#[Post(
    denormalizationContext: ['groups'=> ['equipment-category:update']],
    name: 'EquipmentCategoryUpdating',
    uriTemplate: 'equipment-categories/{id}/update',
    inputFormats: ['multipart' => ['multipart/form-data']]
)]
#[Patch(
    denormalizationContext: ['groups'=> ['equipment-category-intervention:edit']],
    name: 'InterventionAffectation',
    uriTemplate: 'equipment-category-intervention/{id}/edit',
)]
#[Get(
    provider: MaintenanceRatioByCategoryProvider::class,
    //normalizationContext: ['groups'=> ['equipment-category:read']],
    uriTemplate: 'maintenance-ratio-by-category/{farmsId}',
    uriVariables: ['farmsId'],
)]
#[UniqueEntity('name')]
#[ORM\Entity(repositoryClass: EquipmentCategoryRepository::class)]
#[HasLifecycleCallbacks]
class EquipmentCategory
{
    use CommonDate;
    #[ApiFilter(OrderFilter::class,strategy: 'DESC')]
    #[Groups(['equipment-category:read-collection','equipment-category:read','equipment-category:read-collection-brief','equipment-category-interventions:read'])]
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[Groups(['equipment-category:write','equipment-category:read-collection','equipment-category:read','equipment-category:update','equipment-category:read-collection-brief','equipment-category-interventions:read'])]
    #[ApiFilter(SearchFilter::class,strategy: 'partial')]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $name = null;

    #[Assert\File(
        maxSize: '2048k',
        extensions: ['jpeg','jpg','png'],
        extensionsMessage: 'Please upload a valid image',
    )]
    #[Groups(['equipment-category:write','equipment-category:update'])]
    #[Vich\UploadableField(mapping: 'equipment_category', fileNameProperty: 'image', size: 'imageSize')]
    private ?File $imageFile = null;

    #[Groups(['equipment-category:write','equipment-category:read-collection','equipment-category:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $image = null;

    #[ORM\Column(nullable: true)]
    private ?int $imageSize = null;

    #[Groups(['equipment-category:write','equipment-category:read','equipment-category:update'])]
    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $description = null;

    /**
     * @var Collection<int, Equipment>
     */
    #[ORM\OneToMany(targetEntity: Equipment::class, mappedBy: 'equipmentCategory')]
    private Collection $equipment;

    /**
     * @var Collection<int, Intervention>
     */
    #[Groups(['equipment-category-intervention:edit','equipment-category-interventions:read'])]
    #[ORM\ManyToMany(targetEntity: Intervention::class, mappedBy: 'equipmentCategories')]
    private Collection $interventions;

    public function __construct()
    {
        $this->equipment = new ArrayCollection();
        $this->interventions = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function setImageFile(?File $imageFile = null): void
    {
        $this->imageFile = $imageFile;

        if (null !== $imageFile) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
    }

    public function getImageFile(): ?File
    {
        return $this->imageFile;
    }

    public function getImage(): ?string
    {
        return $this->image;
    }

    public function setImage(?string $image): static
    {
        $this->image = $image;

        return $this;
    }

    public function setImageSize(?int $imageSize): void
    {
        $this->imageSize = $imageSize;
    }

    public function getImageSize(): ?int
    {
        return $this->imageSize;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): static
    {
        $this->description = $description;

        return $this;
    }

    /**
     * @return Collection<int, Equipment>
     */
    public function getEquipment(): Collection
    {
        return $this->equipment;
    }

    public function addEquipment(Equipment $equipment): static
    {
        if (!$this->equipment->contains($equipment)) {
            $this->equipment->add($equipment);
            $equipment->setEquipmentCategory($this);
        }

        return $this;
    }

    public function removeEquipment(Equipment $equipment): static
    {
        if ($this->equipment->removeElement($equipment)) {
            // set the owning side to null (unless already changed)
            if ($equipment->getEquipmentCategory() === $this) {
                $equipment->setEquipmentCategory(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, Intervention>
     */
    public function getInterventions(): Collection
    {
        return $this->interventions;
    }

    public function addIntervention(Intervention $intervention): static
    {
        if (!$this->interventions->contains($intervention)) {
            $this->interventions->add($intervention);
            $intervention->addEquipmentCategory($this);
        }

        return $this;
    }

    public function removeIntervention(Intervention $intervention): static
    {
        if ($this->interventions->removeElement($intervention)) {
            $intervention->removeEquipmentCategory($this);
        }

        return $this;
    }
}
