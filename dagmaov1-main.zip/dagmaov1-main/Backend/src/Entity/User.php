<?php

namespace App\Entity;

use ApiPlatform\Doctrine\Orm\Filter\OrderFilter;
use ApiPlatform\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Get;
use ApiPlatform\Metadata\GetCollection;
use ApiPlatform\Metadata\Post;
use App\Entity\Traits\CommonDate;
use App\Repository\UserRepository;
use App\State\Processors\User\CreateUserProcessor;
use App\State\Providers\User\GetUserCredentialsProvider;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\HasLifecycleCallbacks;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Entity(repositoryClass: UserRepository::class)]
#[ORM\UniqueConstraint(name: 'UNIQ_IDENTIFIER_EMAIL', fields: ['email'])]
#[HasLifecycleCallbacks]
#[Post(
    processor: CreateUserProcessor::class,
    denormalizationContext: ['groups'=> ['write:user']],
    name: 'UserCreating',
    uriTemplate: 'users',
    //inputFormats: ['multipart' => ['multipart/form-data']]
)]
#[Get(
    security: "is_granted('ROLE_TECHNICIAN') or is_granted('ROLE_MAINTENANCE_MANAGER') or is_granted('ROLE_DIRECTOR') or is_granted('ROLE_ADMIN') and object == user"
)]
#[Get(
    provider: GetUserCredentialsProvider::class,
    normalizationContext: ['groups'=> ['getUser']],
    uriTemplate: 'user-credentials',
    security: "is_granted('ROLE_TECHNICIAN') or is_granted('ROLE_MAINTENANCE_MANAGER') or is_granted('ROLE_DIRECTOR') or is_granted('ROLE_ADMIN') and object == user"
)]
#[GetCollection(
    normalizationContext: ['groups'=> ['user:read-collecton']],
)]
#[Delete]
#[UniqueEntity('email')]
class User implements UserInterface, PasswordAuthenticatedUserInterface
{
    use CommonDate;
    #[ApiFilter(OrderFilter::class,strategy: 'DESC')]
    #[Groups(['technicians-by-farm:read','getUser','user:read-collecton'])]
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 180)]
    #[Groups(['write:user','technicians-by-farm:read','preventive-maintenance:read','getUser','user:read-collecton'])]
    private ?string $email = null;

    /**
     * @var list<string> The user roles
     */
    #[ORM\Column]
    #[Groups(['getUser'])]
    private array $roles = [];

    /**
     * @var string The hashed password
     */
    #[Assert\NotBlank(message: 'Password should not be blank.')]
    #[Assert\Length(
        min: 8,
        minMessage: 'Password must be at least {{ limit }} characters long'
    )]
    #[Assert\Regex(
        pattern: '/[a-z]/',
        message: 'Password must contain at least one lowercase letter'
    )]
    #[Assert\Regex(
        pattern: '/[A-Z]/',
        message: 'Password must contain at least one uppercase letter'
    )]
    #[Assert\Regex(
        pattern: '/[0-9]/',
        message: 'Password must contain at least one number'
    )]
    #[ORM\Column]
    #[Groups(['write:user'])]
    private ?string $password = null;

    #[ORM\Column(length: 255, nullable: true)]
    #[Groups(['write:user','technicians-by-farm:read','preventive-maintenance:read','getUser','user:read-collecton'])]
    private ?string $firstName = null;

    #[ApiFilter(SearchFilter::class,strategy: 'partial')]
    #[ORM\Column(length: 255, nullable: true)]
    #[Groups(['write:user','technicians-by-farm:read','preventive-maintenance:read','getUser','user:read-collecton'])]
    private ?string $lastName = null;

    #[ORM\Column(length: 255)]
    #[Groups(['write:user','getUser','user:read-collecton'])]
    private ?string $type = null;

    #[ORM\ManyToOne(inversedBy: 'users')]
    #[Groups(['write:user','getUser','user:read-collecton'])]
    private ?Farm $farm = null;

    /**
     * @var Collection<int, PreventiveMaintenance>
     */
    #[ORM\ManyToMany(targetEntity: PreventiveMaintenance::class, mappedBy: 'PersonnelInCharge')]
    private Collection $preventiveMaintenances;

    /**
     * @var Collection<int, CorrectiveMaintenance>
     */
    #[ORM\ManyToMany(targetEntity: CorrectiveMaintenance::class, mappedBy: 'PersonnelInCharge')]
    private Collection $correctiveMaintenances;

    public function __construct()
    {
        $this->preventiveMaintenances = new ArrayCollection();
        $this->correctiveMaintenances = new ArrayCollection();
    }


    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): static
    {
        $this->email = $email;

        return $this;
    }

    /**
     * A visual identifier that represents this user.
     *
     * @see UserInterface
     */
    public function getUserIdentifier(): string
    {
        return (string) $this->email;
    }

    /**
     * @see UserInterface
     *
     * @return list<string>
     */
    public function getRoles(): array
    {
        $roles = $this->roles;
        // guarantee every user at least has ROLE_USER
        $roles[] = 'ROLE_USER';

        return array_unique($roles);
    }

    /**
     * @param list<string> $roles
     */
    public function setRoles(array $roles): static
    {
        $this->roles = $roles;

        return $this;
    }

    /**
     * @see PasswordAuthenticatedUserInterface
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): static
    {
        $this->password = $password;

        return $this;
    }

    /**
     * @see UserInterface
     */
    public function eraseCredentials(): void
    {
        // If you store any temporary, sensitive data on the user, clear it here
        // $this->plainPassword = null;
    }

    public function getFirstName(): ?string
    {
        return $this->firstName;
    }

    public function setFirstName(?string $firstName): static
    {
        $this->firstName = $firstName;

        return $this;
    }

    public function getLastName(): ?string
    {
        return $this->lastName;
    }

    public function setLastName(?string $lastName): static
    {
        $this->lastName = $lastName;

        return $this;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(string $type): static
    {
        $this->type = $type;

        return $this;
    }

    public function getFarm(): ?Farm
    {
        return $this->farm;
    }

    public function setFarm(?Farm $farm): static
    {
        $this->farm = $farm;

        return $this;
    }

    /**
     * @return Collection<int, PreventiveMaintenance>
     */
    public function getPreventiveMaintenances(): Collection
    {
        return $this->preventiveMaintenances;
    }

    public function addPreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if (!$this->preventiveMaintenances->contains($preventiveMaintenance)) {
            $this->preventiveMaintenances->add($preventiveMaintenance);
            $preventiveMaintenance->addPersonnelInCharge($this);
        }

        return $this;
    }

    public function removePreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if ($this->preventiveMaintenances->removeElement($preventiveMaintenance)) {
            $preventiveMaintenance->removePersonnelInCharge($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, CorrectiveMaintenance>
     */
    public function getCorrectiveMaintenances(): Collection
    {
        return $this->correctiveMaintenances;
    }

    public function addCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if (!$this->correctiveMaintenances->contains($correctiveMaintenance)) {
            $this->correctiveMaintenances->add($correctiveMaintenance);
            $correctiveMaintenance->addPersonnelInCharge($this);
        }

        return $this;
    }

    public function removeCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if ($this->correctiveMaintenances->removeElement($correctiveMaintenance)) {
            $correctiveMaintenance->removePersonnelInCharge($this);
        }

        return $this;
    }


}
