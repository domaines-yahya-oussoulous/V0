<?php

namespace App\Entity;

use ApiPlatform\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Get;
use ApiPlatform\Metadata\GetCollection;
use ApiPlatform\Metadata\Post;
use App\DTO\SparePartDTO;
use App\Entity\Traits\CommonDate;
use App\Repository\SparePartRepository;
use App\State\Processors\SparePart\CreateUpdateSparePartProcessor;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\HasLifecycleCallbacks;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\Serializer\Annotation\Groups;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use ApiPlatform\Doctrine\Orm\Filter\OrderFilter;

#[ORM\Entity(repositoryClass: SparePartRepository::class)]
#[HasLifecycleCallbacks]
#[ApiResource()]
#[Vich\Uploadable]
#[Post(
    input: SparePartDTO::class,
    processor: CreateUpdateSparePartProcessor::class,
    denormalizationContext: ['groups'=> ['spare-parts:write']],
    name: 'SparePartsCreating',
    uriTemplate: 'spare-parts/add',
    inputFormats: ['multipart' => ['multipart/form-data']]
)]
#[GetCollection]
#[Get]
#[Post(
    input: SparePartDTO::class,
    processor: CreateUpdateSparePartProcessor::class,
    denormalizationContext: ['groups'=> ['spare-parts:update']],
    name: 'SparePartsUpdating',
    uriTemplate: 'spare-parts/{id}/update',
    inputFormats: ['multipart' => ['multipart/form-data']]
)]
#[Delete]
class SparePart
{
    use CommonDate;

    #[Groups(['spare-parts-by-farm:read'])]
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[ApiFilter(OrderFilter::class,strategy: 'DESC')]
    private ?int $id = null;

    #[Groups(['spare-parts:write','spare-parts:update','spare-parts-by-farm:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    #[ApiFilter(SearchFilter::class,strategy: 'partial')]
    private ?string $name = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $categoryName = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $reference = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $inventoryCode = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[Vich\UploadableField(mapping: 'spareparts', fileNameProperty: 'image', size: 'imageSize')]
    private ?File $imageFile = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $image = null;

    #[ORM\Column(nullable: true)]
    private ?int $imageSize = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $brand = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\Column(nullable: true)]
    private ?float $unitPrice = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\Column(nullable: true)]
    private ?bool $availability = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\Column(nullable: true)]
    private ?int $quantity = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\Column(nullable: true)]
    private ?float $orderDuration = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $lastInventoryDate = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    /**
     * @var Collection<int, Equipment>
     */
    #[ORM\ManyToMany(targetEntity: Equipment::class, inversedBy: 'spareParts')]
    private Collection $equipment;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\ManyToOne(inversedBy: 'spareParts')]
    private ?Farm $farm = null;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    /**
     * @var Collection<int, PreventiveMaintenance>
     */
    #[ORM\ManyToMany(targetEntity: PreventiveMaintenance::class, mappedBy: 'SparePartsToUse')]
    private Collection $preventiveMaintenances;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    /**
     * @var Collection<int, CorrectiveMaintenance>
     */
    #[ORM\ManyToMany(targetEntity: CorrectiveMaintenance::class, mappedBy: 'sparePartsToUse')]
    private Collection $correctiveMaintenances;

    /**
     * @var Collection<int, SparePartPreventiveMaintenanceQuantity>
     */
    #[ORM\OneToMany(targetEntity: SparePartPreventiveMaintenanceQuantity::class, mappedBy: 'SparePart')]
    private Collection $sparePartPreventiveMaintenanceQuantities;

    /**
     * @var Collection<int, SparePartCorrectiveMaintenanceQuantity>
     */
    #[ORM\OneToMany(targetEntity: SparePartCorrectiveMaintenanceQuantity::class, mappedBy: 'SparePart')]
    private Collection $sparePartCorrectiveMaintenanceQuantities;

    #[Groups(['spare-parts:write','spare-parts:update'])]
    #[ORM\ManyToOne(inversedBy: 'equipment')]
    private ?SparePartCategory $sparePartCategory = null;





    public function __construct()
    {
        $this->equipment = new ArrayCollection();
        $this->preventiveMaintenances = new ArrayCollection();
        $this->correctiveMaintenances = new ArrayCollection();
        $this->sparePartPreventiveMaintenanceQuantities = new ArrayCollection();
        $this->sparePartCorrectiveMaintenanceQuantities = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): static
    {
        $this->name = $name;

        return $this;
    }

    public function getCategoryName(): ?string
    {
        return $this->categoryName;
    }

    public function setCategoryName(?string $categoryName): static
    {
        $this->categoryName = $categoryName;

        return $this;
    }

    public function getReference(): ?string
    {
        return $this->reference;
    }

    public function setReference(?string $reference): static
    {
        $this->reference = $reference;

        return $this;
    }

    public function getInventoryCode(): ?string
    {
        return $this->inventoryCode;
    }

    public function setInventoryCode(?string $inventoryCode): static
    {
        $this->inventoryCode = $inventoryCode;

        return $this;
    }

    public function setImageFile(?File $imageFile = null): void
    {
        $this->imageFile = $imageFile;

        if (null !== $imageFile) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
    }

    public function getImageFile(): ?File
    {
        return $this->imageFile;
    }

    public function getImage(): ?string
    {
        return $this->image;
    }

    public function setImage(?string $image): static
    {
        $this->image = $image;

        return $this;
    }
    public function setImageSize(?int $imageSize): void
    {
        $this->imageSize = $imageSize;
    }

    public function getImageSize(): ?int
    {
        return $this->imageSize;
    }

    public function getBrand(): ?string
    {
        return $this->brand;
    }

    public function setBrand(?string $brand): static
    {
        $this->brand = $brand;

        return $this;
    }

    public function getUnitPrice(): ?float
    {
        return $this->unitPrice;
    }

    public function setUnitPrice(?float $unitPrice): static
    {
        $this->unitPrice = $unitPrice;

        return $this;
    }


    public function isAvailability(): ?bool
    {
        return $this->availability;
    }

    public function setAvailability(?bool $availability): static
    {
        $this->availability = $availability;

        return $this;
    }

    public function getQuantity(): ?int
    {
        return $this->quantity;
    }

    public function setQuantity(?int $quantity): static
    {
        $this->quantity = $quantity;

        return $this;
    }

    public function getOrderDuration(): ?float
    {
        return $this->orderDuration;
    }

    public function setOrderDuration(?float $orderDuration): static
    {
        $this->orderDuration = $orderDuration;

        return $this;
    }

    /**
     * @return Collection<int, Equipment>
     */
    public function getEquipment(): Collection
    {
        return $this->equipment;
    }

    public function addEquipment(Equipment $equipment): static
    {
        if (!$this->equipment->contains($equipment)) {
            $this->equipment->add($equipment);
        }

        return $this;
    }

    public function removeEquipment(Equipment $equipment): static
    {
        $this->equipment->removeElement($equipment);

        return $this;
    }

    public function getFarm(): ?Farm
    {
        return $this->farm;
    }

    public function setFarm(?Farm $farm): static
    {
        $this->farm = $farm;

        return $this;
    }
    public function getLastInventoryDate(): ?\DateTimeInterface
    {
        return $this->lastInventoryDate;
    }

    public function setLastInventoryDate(?\DateTimeInterface $lastInventoryDate): static
    {
        $this->lastInventoryDate = $lastInventoryDate;

        return $this;
    }

    /**
     * @return Collection<int, PreventiveMaintenance>
     */
    public function getPreventiveMaintenances(): Collection
    {
        return $this->preventiveMaintenances;
    }

    public function addPreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if (!$this->preventiveMaintenances->contains($preventiveMaintenance)) {
            $this->preventiveMaintenances->add($preventiveMaintenance);
            $preventiveMaintenance->addSparePartsToUse($this);
        }

        return $this;
    }

    public function removePreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if ($this->preventiveMaintenances->removeElement($preventiveMaintenance)) {
            $preventiveMaintenance->removeSparePartsToUse($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, CorrectiveMaintenance>
     */
    public function getCorrectiveMaintenances(): Collection
    {
        return $this->correctiveMaintenances;
    }

    public function addCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if (!$this->correctiveMaintenances->contains($correctiveMaintenance)) {
            $this->correctiveMaintenances->add($correctiveMaintenance);
            $correctiveMaintenance->addSparePartsToUse($this);
        }

        return $this;
    }

    public function removeCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if ($this->correctiveMaintenances->removeElement($correctiveMaintenance)) {
            $correctiveMaintenance->removeSparePartsToUse($this);
        }

        return $this;
    }
    #[PreUpdate]
    public function preUpdate(): void
    {
        if ($this->imageFile === null && $this->image !== null) {
            $this->removeImage();
        }
    }

    /**
     * @return Collection<int, SparePartPreventiveMaintenanceQuantity>
     */
    public function getSparePartPreventiveMaintenanceQuantities(): Collection
    {
        return $this->sparePartPreventiveMaintenanceQuantities;
    }

    public function addSparePartPreventiveMaintenanceQuantity(SparePartPreventiveMaintenanceQuantity $sparePartPreventiveMaintenanceQuantity): static
    {
        if (!$this->sparePartPreventiveMaintenanceQuantities->contains($sparePartPreventiveMaintenanceQuantity)) {
            $this->sparePartPreventiveMaintenanceQuantities->add($sparePartPreventiveMaintenanceQuantity);
            $sparePartPreventiveMaintenanceQuantity->setSparePart($this);
        }

        return $this;
    }

    public function removeSparePartPreventiveMaintenanceQuantity(SparePartPreventiveMaintenanceQuantity $sparePartPreventiveMaintenanceQuantity): static
    {
        if ($this->sparePartPreventiveMaintenanceQuantities->removeElement($sparePartPreventiveMaintenanceQuantity)) {
            // set the owning side to null (unless already changed)
            if ($sparePartPreventiveMaintenanceQuantity->getSparePart() === $this) {
                $sparePartPreventiveMaintenanceQuantity->setSparePart(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, SparePartCorrectiveMaintenanceQuantity>
     */
    public function getSparePartCorrectiveMaintenanceQuantities(): Collection
    {
        return $this->sparePartCorrectiveMaintenanceQuantities;
    }

    public function addSparePartCorrectiveMaintenanceQuantity(SparePartCorrectiveMaintenanceQuantity $sparePartCorrectiveMaintenanceQuantity): static
    {
        if (!$this->sparePartCorrectiveMaintenanceQuantities->contains($sparePartCorrectiveMaintenanceQuantity)) {
            $this->sparePartCorrectiveMaintenanceQuantities->add($sparePartCorrectiveMaintenanceQuantity);
            $sparePartCorrectiveMaintenanceQuantity->setSparePart($this);
        }

        return $this;
    }

    public function removeSparePartCorrectiveMaintenanceQuantity(SparePartCorrectiveMaintenanceQuantity $sparePartCorrectiveMaintenanceQuantity): static
    {
        if ($this->sparePartCorrectiveMaintenanceQuantities->removeElement($sparePartCorrectiveMaintenanceQuantity)) {
            // set the owning side to null (unless already changed)
            if ($sparePartCorrectiveMaintenanceQuantity->getSparePart() === $this) {
                $sparePartCorrectiveMaintenanceQuantity->setSparePart(null);
            }
        }

        return $this;
    }

    public function getSparePartCategory(): ?SparePartCategory
    {
        return $this->sparePartCategory;
    }

    public function setSparePartCategory(?SparePartCategory $sparePartCategory): static
    {
        $this->sparePartCategory = $sparePartCategory;

        return $this;
    }



}
