<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\Serializer\Annotation\Groups;

#[ORM\Entity]
#[Vich\Uploadable]
class PreventiveMaintenanceImage
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[Vich\UploadableField(mapping: 'preventive_maintenance', fileNameProperty: 'imageName')]
    private ?File $imageFile = null;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    #[Groups(['preventive-maintenance:read','preventive-maintenance:write'])]
    private ?string $imageName = null;

    #[ORM\ManyToOne(targetEntity: PreventiveMaintenance::class, inversedBy: 'images')]
    private ?PreventiveMaintenance $preventiveMaintenance = null;

    // Getters and setters

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getImageFile(): ?File
    {
        return $this->imageFile;
    }

    public function setImageFile(?File $imageFile): self
    {
        $this->imageFile = $imageFile;
        return $this;
    }

    public function getImageName(): ?string
    {
        return $this->imageName;
    }

    public function setImageName(?string $imageName): self
    {
        $this->imageName = $imageName;
        return $this;
    }

    public function getPreventiveMaintenance(): ?PreventiveMaintenance
    {
        return $this->preventiveMaintenance;
    }

    public function setPreventiveMaintenance(?PreventiveMaintenance $preventiveMaintenance): self
    {
        $this->preventiveMaintenance = $preventiveMaintenance;
        return $this;
    }
}
