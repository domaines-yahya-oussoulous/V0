<?php

namespace App\Entity;

use ApiPlatform\Metadata\ApiResource;
use App\Repository\SparePartCorrectiveMaintenanceQuantityRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;
#[ApiResource()]
#[ORM\Entity(repositoryClass: SparePartCorrectiveMaintenanceQuantityRepository::class)]
class SparePartCorrectiveMaintenanceQuantity
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[Groups(['corrective-maintenance:write'])]
    #[ORM\ManyToOne(inversedBy: 'sparePartCorrectiveMaintenanceQuantities')]
    private ?CorrectiveMaintenance $CorrectiveMaintenance = null;

    #[Groups(['corrective-maintenance:write'])]
    #[ORM\ManyToOne(inversedBy: 'sparePartCorrectiveMaintenanceQuantities')]
    private ?SparePart $SparePart = null;

    #[Groups(['corrective-maintenance:write','corrective-maintenance:read-collection','corrective-maintenance:read'])]
    #[ORM\Column(nullable: true)]
    private ?int $quantity = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCorrectiveMaintenance(): ?CorrectiveMaintenance
    {
        return $this->CorrectiveMaintenance;
    }

    public function setCorrectiveMaintenance(?CorrectiveMaintenance $CorrectiveMaintenance): static
    {
        $this->CorrectiveMaintenance = $CorrectiveMaintenance;

        return $this;
    }

    public function getSparePart(): ?SparePart
    {
        return $this->SparePart;
    }

    public function setSparePart(?SparePart $SparePart): static
    {
        $this->SparePart = $SparePart;

        return $this;
    }

    public function getQuantity(): ?int
    {
        return $this->quantity;
    }

    public function setQuantity(?int $quantity): static
    {
        $this->quantity = $quantity;

        return $this;
    }
    #[Groups(['corrective-maintenance:read-collection','corrective-maintenance:read'])]
    public function getSparePartName(): ?string
    {
        return $this->SparePart ? $this->SparePart->getName() : null;
    }
}
