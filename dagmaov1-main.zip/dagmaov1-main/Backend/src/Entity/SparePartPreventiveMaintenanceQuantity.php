<?php

namespace App\Entity;

use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\GetCollection;
use App\Repository\SparePartPreventiveMaintenanceQuantityRepository;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;
#[ApiResource()]
#[GetCollection]
#[ORM\Entity(repositoryClass: SparePartPreventiveMaintenanceQuantityRepository::class)]
class SparePartPreventiveMaintenanceQuantity
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\ManyToOne(inversedBy: 'sparePartPreventiveMaintenanceQuantities')]
    #[Groups(['preventive-maintenance:write'])]
    private ?PreventiveMaintenance $PreventiveMaintenance = null;

    #[ORM\ManyToOne(inversedBy: 'sparePartPreventiveMaintenanceQuantities')]
    #[Groups(['preventive-maintenance:write'])]
    private ?SparePart $SparePart = null;

    #[ORM\Column(nullable: true)]
    #[Groups(['preventive-maintenance:write','preventive-maintenance:read-collection','preventive-maintenance:read'])]
    private ?int $quantity = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPreventiveMaintenance(): ?PreventiveMaintenance
    {
        return $this->PreventiveMaintenance;
    }

    public function setPreventiveMaintenance(?PreventiveMaintenance $PreventiveMaintenance): static
    {
        $this->PreventiveMaintenance = $PreventiveMaintenance;

        return $this;
    }

    public function getSparePart(): ?SparePart
    {
        return $this->SparePart;
    }

    public function setSparePart(?SparePart $SparePart): static
    {
        $this->SparePart = $SparePart;

        return $this;
    }

    public function getQuantity(): ?int
    {
        return $this->quantity;
    }

    public function setQuantity(?int $quantity): static
    {
        $this->quantity = $quantity;

        return $this;
    }
    #[Groups(['preventive-maintenance:read-collection','preventive-maintenance:read'])]
    public function getSparePartName(): ?string
    {
        return $this->SparePart ? $this->SparePart->getName() : null;
    }
}
