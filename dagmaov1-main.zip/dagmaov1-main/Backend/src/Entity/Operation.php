<?php

namespace App\Entity;

use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Patch;
use App\Repository\OperationRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Serializer\Annotation\Groups;

#[ApiResource()]
#[Delete]
#[Patch(
    denormalizationContext: ['groups'=> ['operation-description:update']],

)]
#[ORM\Entity(repositoryClass: OperationRepository::class)]
class Operation
{
    #[Groups(['intervention-operations:read'])]
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[Groups(['intervention:write','intervention-operations:read','operation-description:update'])]
    #[ORM\Column(type: Types::TEXT)]
    private ?string $description = null;

    #[ORM\ManyToOne(inversedBy: 'operations')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Intervention $intervention = null;

    /**
     * @var Collection<int, PreventiveMaintenance>
     */
    #[ORM\ManyToMany(targetEntity: PreventiveMaintenance::class, mappedBy: 'operations')]
    private Collection $preventiveMaintenances;

    /**
     * @var Collection<int, CorrectiveMaintenance>
     */
    #[ORM\ManyToMany(targetEntity: CorrectiveMaintenance::class, mappedBy: 'operations')]
    private Collection $correctiveMaintenances;

    public function __construct()
    {
        $this->preventiveMaintenances = new ArrayCollection();
        $this->correctiveMaintenances = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }

    public function getIntervention(): ?Intervention
    {
        return $this->intervention;
    }

    public function setIntervention(?Intervention $intervention): static
    {
        $this->intervention = $intervention;

        return $this;
    }

    /**
     * @return Collection<int, PreventiveMaintenance>
     */
    public function getPreventiveMaintenances(): Collection
    {
        return $this->preventiveMaintenances;
    }

    public function addPreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if (!$this->preventiveMaintenances->contains($preventiveMaintenance)) {
            $this->preventiveMaintenances->add($preventiveMaintenance);
            $preventiveMaintenance->addOperation($this);
        }

        return $this;
    }

    public function removePreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): static
    {
        if ($this->preventiveMaintenances->removeElement($preventiveMaintenance)) {
            $preventiveMaintenance->removeOperation($this);
        }

        return $this;
    }

    /**
     * @return Collection<int, CorrectiveMaintenance>
     */
    public function getCorrectiveMaintenances(): Collection
    {
        return $this->correctiveMaintenances;
    }

    public function addCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if (!$this->correctiveMaintenances->contains($correctiveMaintenance)) {
            $this->correctiveMaintenances->add($correctiveMaintenance);
            $correctiveMaintenance->addOperation($this);
        }

        return $this;
    }

    public function removeCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): static
    {
        if ($this->correctiveMaintenances->removeElement($correctiveMaintenance)) {
            $correctiveMaintenance->removeOperation($this);
        }

        return $this;
    }
}
