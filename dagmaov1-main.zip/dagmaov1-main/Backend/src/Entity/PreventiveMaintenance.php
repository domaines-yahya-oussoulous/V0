<?php

namespace App\Entity;

use ApiPlatform\Doctrine\Orm\Filter\SearchFilter;
use ApiPlatform\Metadata\ApiFilter;
use ApiPlatform\Metadata\ApiResource;
use ApiPlatform\Metadata\Delete;
use ApiPlatform\Metadata\Get;
use ApiPlatform\Metadata\GetCollection;
use ApiPlatform\Metadata\Patch;
use ApiPlatform\Metadata\Post;
use App\DTO\PreventiveMaintenanceDTO;
use App\Entity\Traits\CommonDate;
use App\Repository\PreventiveMaintenanceRepository;
use App\State\Processors\PreventiveMaintenance\CreatePreventiveMaintenanceProcessor;
use App\State\Processors\PreventiveMaintenance\InvalidatePreventiveMaintenance;
use App\State\Processors\PreventiveMaintenance\MarkPreventiveMaintenanceAsCompleted;
use App\State\Processors\PreventiveMaintenance\MarkPreventiveMaintenanceAsInProgress;
use App\State\Processors\PreventiveMaintenance\ValidatePreventiveMaintenance;
use App\State\Providers\PreventiveMaintenance\CountPreventiveMaintenanceByFarmIdsProvider;
use App\State\Providers\PreventiveMaintenance\CountPreventiveMaintenanceByStateProvider;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\HasLifecycleCallbacks;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;
use ApiPlatform\Doctrine\Orm\Filter\OrderFilter;

#[ORM\Entity(repositoryClass: PreventiveMaintenanceRepository::class)]
#[HasLifecycleCallbacks]
#[ApiResource()]
#[Post(
    input: PreventiveMaintenanceDTO::class,
    processor: CreatePreventiveMaintenanceProcessor::class,
    denormalizationContext: ['groups'=> ['preventive-maintenance:write']],
    normalizationContext: ['groups'=> ['preventive-maintenance:write']],
    name: 'PreventiveMaintenanceCreating',
    uriTemplate: 'preventive-maintenance/add',
    inputFormats: ['multipart' => ['multipart/form-data']]
)]
#[GetCollection(
    normalizationContext: ['groups'=> ['preventive-maintenance:read-collection']],
    //name: 'PreventiveMaintenanceCreating',
    //uriTemplate: 'preventive-maintenance/add',
)]
#[Get(
    normalizationContext: ['groups'=> ['preventive-maintenance:read']],
    name: 'PreventiveMaintenanceById',
    uriTemplate: 'preventive-maintenance/{id}',
)]
#[Patch(
    processor: ValidatePreventiveMaintenance::class,
    denormalizationContext: ['groups'=> ['preventive-maintenance:validate']],
    name: 'ValidatingPreventiveMaintenance',
    uriTemplate: '/preventive-maintenances/{id}/validate'
)]
#[Patch(
    processor: InvalidatePreventiveMaintenance::class,
    denormalizationContext: ['groups'=> ['preventive-maintenance:invalidate']],
    name: 'InValidatingPreventiveMaintenance',
    uriTemplate: '/preventive-maintenances/{id}/invalidate'
)]
#[Patch(
    processor: MarkPreventiveMaintenanceAsInProgress::class,
    denormalizationContext: ['groups'=> ['preventive-maintenance:mark-as-in-progress']],
    name: 'MarkAsInProgressPreventiveMaintenance',
    uriTemplate: '/preventive-maintenances/{id}/mark-as-in-progress'
)]
#[Patch(
    processor: MarkPreventiveMaintenanceAsCompleted::class,
    denormalizationContext: ['groups'=> ['preventive-maintenance:mark-as-completed']],
    name: 'MarkAsCompletedPreventiveMaintenance',
    uriTemplate: '/preventive-maintenances/{id}/mark-as-completed'
)]
#[Patch(
    //processor: MarkPreventiveMaintenanceAsCompleted::class,
    denormalizationContext: ['groups'=> ['preventive-maintenance-operations:edit']],
    name: 'AffectingOperationsPreventiveMaintenance',
    uriTemplate: '/preventive-maintenances/{id}/operations'
)]
#[Get(
    provider: CountPreventiveMaintenanceByStateProvider::class,
    uriTemplate: 'count-preventive-maintenances-by-state/{farmsId}/{state}',
    uriVariables: ['farmsId','state']
)]
#[Get(
    provider: CountPreventiveMaintenanceByFarmIdsProvider::class,
    uriTemplate: 'count-preventive-maintenances-by-farm/{farmsId}',
    uriVariables: ['farmsId']
)]
#[Delete]
class PreventiveMaintenance
{
    use CommonDate;
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    #[Groups(['preventive-maintenance:read-collection','preventive-maintenance:read'])]
    #[ApiFilter(OrderFilter::class,strategy: 'DESC')]
    private ?int $id = null;

    #[ApiFilter(SearchFilter::class,strategy: 'partial')]
    #[Groups(['preventive-maintenance:read-collection','preventive-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $equipmentName = null;

    #[Groups(['preventive-maintenance:write','preventive-maintenance:read-collection','preventive-maintenance:read'])]
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $interventionDate = null;

    #[Groups(['preventive-maintenance:write','preventive-maintenance:read-collection','preventive-maintenance:read'])]
    #[ORM\Column(nullable: true)]
    private ?int $interventionEstimatedDuration = null;

    #[Groups(['preventive-maintenance:write','preventive-maintenance:read-collection','preventive-maintenance:read'])]
    #[ORM\Column(nullable: true)]
    private ?string $interventionEstimatedDurationUnit = null;

    #[Groups(['preventive-maintenance:write','preventive-maintenance:read-collection','preventive-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $maintenanceFrequency = null;

    #[Groups(['preventive-maintenance:write','preventive-maintenance:read-collection','preventive-maintenance:read'])]
    #[ORM\Column(nullable: true)]
    private ?int $maintenanceFrequencyCount = null;

    #[ORM\ManyToOne(inversedBy: 'preventiveMaintenances',)]
    #[Groups(['preventive-maintenance:write','preventive-maintenance:read-collection','preventive-maintenance:read'])]
    private ?Equipment $equipmentToMaintain = null;


    /**
     * @var Collection<int, SparePart>
     */
    #[ORM\ManyToMany(targetEntity: SparePart::class, inversedBy: 'preventiveMaintenances')]
    #[Groups(['preventive-maintenance:write'])]
    private Collection $SparePartsToUse;

    /**
     * @var Collection<int, SparePartPreventiveMaintenanceQuantity>
     */
    #[ORM\OneToMany(targetEntity: SparePartPreventiveMaintenanceQuantity::class, mappedBy: 'PreventiveMaintenance', cascade: ['persist', 'remove'])]
    #[Groups(['preventive-maintenance:write','preventive-maintenance:read-collection','preventive-maintenance:read'])]
    private Collection $sparePartPreventiveMaintenanceQuantities;

    /**
     * @var Collection<int, PreventiveMaintenanceImage>
     */
    #[ORM\OneToMany(targetEntity: PreventiveMaintenanceImage::class, mappedBy: 'preventiveMaintenance', cascade: ['persist', 'remove'])]
    #[Groups(['preventive-maintenance:read-collection','preventive-maintenance:read','preventive-maintenance:write'])]
    private Collection $images;

    /**
     * @var Collection<int, User>
     */
    #[ORM\ManyToMany(targetEntity: User::class, inversedBy: 'preventiveMaintenances')]
    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    private Collection $PersonnelInCharge;

    #[Groups(['preventive-maintenance:read-collection','preventive-maintenance:read'])]
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $state = null;

    #[Groups(['preventive-maintenance:read','preventive-maintenance-operations:edit'])]
    #[ORM\Column(type: Types::TEXT, nullable: true)]
    private ?string $tasksDescription = null;

    #[Groups(['preventive-maintenance:read'])]
    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $completionDate = null;

    #[ORM\ManyToOne(inversedBy: 'preventiveMaintenances')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Intervention $intervention = null;

    /**
     * @var Collection<int, Operation>
     */
    #[Groups(['preventive-maintenance-operations:edit'])]
    #[ORM\ManyToMany(targetEntity: Operation::class, inversedBy: 'preventiveMaintenances')]
    private Collection $operations;

    public function __construct()
    {
        $this->SparePartsToUse = new ArrayCollection();
        $this->sparePartPreventiveMaintenanceQuantities = new ArrayCollection();
        $this->images = new ArrayCollection();
        $this->PersonnelInCharge = new ArrayCollection();
        $this->operations = new ArrayCollection();
    }

    #[ORM\PreUpdate]
    public function preUpdate(): void
    {
        if ($this->state === "COMPLETED" && $this->completionDate === null) {
            $this->completionDate = new \DateTimeImmutable();
        }
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEquipmentName(): ?string
    {
        return $this->equipmentName;
    }

    public function setEquipmentName(?string $equipmentName): static
    {
        $this->equipmentName = $equipmentName;

        return $this;
    }


    public function getInterventionDate(): ?\DateTimeInterface
    {
        return $this->interventionDate;
    }

    public function setInterventionDate(?\DateTimeInterface $interventionDate): static
    {
        $this->interventionDate = $interventionDate;

        return $this;
    }

    public function getInterventionEstimatedDuration(): ?int
    {
        return $this->interventionEstimatedDuration;
    }

    public function setInterventionEstimatedDuration(?int $interventionEstimatedDuration): static
    {
        $this->interventionEstimatedDuration = $interventionEstimatedDuration;

        return $this;
    }

    public function getInterventionEstimatedDurationUnit(): ?string
    {
        return $this->interventionEstimatedDurationUnit;
    }

    public function setInterventionEstimatedDurationUnit(?string $interventionEstimatedDurationUnit): static
    {
        $this->interventionEstimatedDurationUnit = $interventionEstimatedDurationUnit;

        return $this;
    }

    public function getMaintenanceFrequency(): ?string
    {
        return $this->maintenanceFrequency;
    }

    public function setMaintenanceFrequency(?string $maintenanceFrequency): static
    {
        $this->maintenanceFrequency = $maintenanceFrequency;

        return $this;
    }

    public function getMaintenanceFrequencyCount(): ?int
    {
        return $this->maintenanceFrequencyCount;
    }

    public function setMaintenanceFrequencyCount(?int $maintenanceFrequencyCount): static
    {
        $this->maintenanceFrequencyCount = $maintenanceFrequencyCount;

        return $this;
    }

    public function getEquipmentToMaintain(): ?Equipment
    {
        return $this->equipmentToMaintain;
    }

    public function setEquipmentToMaintain(?Equipment $equipmentToMaintain): static
    {
        $this->equipmentToMaintain = $equipmentToMaintain;

        return $this;
    }

    /**
     * @return Collection<int, SparePart>
     */
    public function getSparePartsToUse(): Collection
    {
        return $this->SparePartsToUse;
    }

    public function addSparePartsToUse(SparePart $sparePartsToUse): static
    {
        if (!$this->SparePartsToUse->contains($sparePartsToUse)) {
            $this->SparePartsToUse->add($sparePartsToUse);
        }

        return $this;
    }

    public function removeSparePartsToUse(SparePart $sparePartsToUse): static
    {
        $this->SparePartsToUse->removeElement($sparePartsToUse);

        return $this;
    }
    public function checkSparePartsAvailability(): bool
    {
        foreach ($this->getSparePartsToUse() as $sparePart) {
            if ($sparePart->getQuantity() < 1) {
                return false;
            }
        }
        return true;
    }

    /**
     * @return Collection<int, SparePartPreventiveMaintenanceQuantity>
     */
    public function getSparePartPreventiveMaintenanceQuantities(): Collection
    {
        return $this->sparePartPreventiveMaintenanceQuantities;
    }

    public function addSparePartPreventiveMaintenanceQuantity(SparePartPreventiveMaintenanceQuantity $sparePartPreventiveMaintenanceQuantity): static
    {
        if (!$this->sparePartPreventiveMaintenanceQuantities->contains($sparePartPreventiveMaintenanceQuantity)) {
            $this->sparePartPreventiveMaintenanceQuantities->add($sparePartPreventiveMaintenanceQuantity);
            $sparePartPreventiveMaintenanceQuantity->setPreventiveMaintenance($this);
        }

        return $this;
    }

    public function removeSparePartPreventiveMaintenanceQuantity(SparePartPreventiveMaintenanceQuantity $sparePartPreventiveMaintenanceQuantity): static
    {
        if ($this->sparePartPreventiveMaintenanceQuantities->removeElement($sparePartPreventiveMaintenanceQuantity)) {
            // set the owning side to null (unless already changed)
            if ($sparePartPreventiveMaintenanceQuantity->getPreventiveMaintenance() === $this) {
                $sparePartPreventiveMaintenanceQuantity->setPreventiveMaintenance(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, PreventiveMaintenanceImage>
     */
    public function getImages(): Collection
    {
        return $this->images;
    }

    public function addImage(PreventiveMaintenanceImage $image): self
    {
        if (!$this->images->contains($image)) {
            $this->images->add($image);
            $image->setPreventiveMaintenance($this);
        }

        return $this;
    }

    public function removeImage(PreventiveMaintenanceImage $image): self
    {
        $this->images->removeElement($image);
        $image->setPreventiveMaintenance(null);

        return $this;
    }

    /**
     * @return Collection<int, User>
     */
    public function getPersonnelInCharge(): Collection
    {
        return $this->PersonnelInCharge;
    }

    public function addPersonnelInCharge(User $personnelInCharge): static
    {
        if (!$this->PersonnelInCharge->contains($personnelInCharge)) {
            $this->PersonnelInCharge->add($personnelInCharge);
        }

        return $this;
    }

    public function removePersonnelInCharge(User $personnelInCharge): static
    {
        $this->PersonnelInCharge->removeElement($personnelInCharge);

        return $this;
    }

    public function getState(): ?string
    {
        return $this->state;
    }

    public function setState(?string $state): static
    {
        $this->state = $state;

        return $this;
    }

    public function getTasksDescription(): ?string
    {
        return $this->tasksDescription;
    }

    public function setTasksDescription(?string $tasksDescription): static
    {
        $this->tasksDescription = $tasksDescription;

        return $this;
    }

    public function getCompletionDate(): ?\DateTimeInterface
    {
        return $this->completionDate;
    }

    public function setCompletionDate(?\DateTimeInterface $completionDate): static
    {
        $this->completionDate = $completionDate;

        return $this;
    }

    public function getIntervention(): ?Intervention
    {
        return $this->intervention;
    }

    public function setIntervention(?Intervention $intervention): static
    {
        $this->intervention = $intervention;

        return $this;
    }

    /**
     * @return Collection<int, Operation>
     */
    public function getOperations(): Collection
    {
        return $this->operations;
    }

    public function addOperation(Operation $operation): static
    {
        if (!$this->operations->contains($operation)) {
            $this->operations->add($operation);
        }

        return $this;
    }

    public function removeOperation(Operation $operation): static
    {
        $this->operations->removeElement($operation);

        return $this;
    }

    #[Groups(['preventive-maintenance:read','preventive-maintenance:read-collection'])]
    public function getInterventionDetails(): array
    {
        return [
            'id' => $this->intervention->getId(),
            'name' => $this->intervention->getName(),
        ];
    }
    #[Groups(['preventive-maintenance:read'])]
    public function getOperationsDetails(): array
    {
        $descriptions = [];

        foreach ($this->operations as $operation) {
            $descriptions[] = $operation->getDescription();
        }

        return $descriptions;
    }
}