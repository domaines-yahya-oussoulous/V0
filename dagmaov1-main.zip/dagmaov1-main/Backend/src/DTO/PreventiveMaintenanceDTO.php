<?php

namespace App\DTO;

use App\Entity\Equipment;
use App\Entity\Intervention;
use App\Entity\SparePart;
use App\Entity\SparePartPreventiveMaintenanceQuantity;
use App\Entity\User;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

class PreventiveMaintenanceDTO
{


    #[Assert\NotBlank]
    #[Assert\Date]
    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    public ?string $interventionDate = null;

    #[Assert\PositiveOrZero]
    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    public ?string $interventionEstimatedDuration = null;

    #[Assert\NotBlank]
    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    public ?string $interventionEstimatedDurationUnit = null;

    #[Assert\NotBlank]
    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    public ?string $maintenanceFrequency = null;

    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    private ?string $maintenanceFrequencyCount = null;

    #[Assert\NotBlank]
    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    public ?Equipment $equipmentToMaintain = null;

    /**
     * @var \Doctrine\Common\Collections\Collection<int, SparePart>
     */
    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    public $sparePartsToUse;

    /**
     * @var \Doctrine\Common\Collections\Collection<int, SparePartPreventiveMaintenanceQuantity>
     */
    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    public $sparePartPreventiveMaintenanceQuantities;

    /**
     * @var Collection<int, User>
     */
    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    private Collection $PersonnelInCharge;

    #[Groups(['preventive-maintenance:write', 'preventive-maintenance:read'])]
    private ?Intervention $intervention = null;

    // Constructor to initialize collections
    public function __construct()
    {
        $this->sparePartsToUse = new \Doctrine\Common\Collections\ArrayCollection();
        $this->sparePartPreventiveMaintenanceQuantities = new \Doctrine\Common\Collections\ArrayCollection();
        $this->PersonnelInCharge = new ArrayCollection();
    }

    public function getInterventionDate(): ?string
    {
        return $this->interventionDate;
    }

    public function setInterventionDate(?string $interventionDate): static
    {
        $this->interventionDate = $interventionDate;
        return $this;
    }

    public function getInterventionEstimatedDuration(): ?string
    {
        return $this->interventionEstimatedDuration;
    }

    public function setInterventionEstimatedDuration(?string $interventionEstimatedDuration): static
    {
        $this->interventionEstimatedDuration = $interventionEstimatedDuration;
        return $this;
    }

    public function getInterventionEstimatedDurationUnit(): ?string
    {
        return $this->interventionEstimatedDurationUnit;
    }

    public function setInterventionEstimatedDurationUnit(?string $interventionEstimatedDurationUnit): static
    {
        $this->interventionEstimatedDurationUnit = $interventionEstimatedDurationUnit;
        return $this;
    }

    public function getMaintenanceFrequency(): ?string
    {
        return $this->maintenanceFrequency;
    }

    public function setMaintenanceFrequency(?string $maintenanceFrequency): static
    {
        $this->maintenanceFrequency = $maintenanceFrequency;
        return $this;
    }

    public function getMaintenanceFrequencyCount(): ?string
    {
        return $this->maintenanceFrequencyCount;
    }

    public function setMaintenanceFrequencyCount(?string $maintenanceFrequencyCount): static
    {
        $this->maintenanceFrequencyCount = $maintenanceFrequencyCount;

        return $this;
    }

    public function getEquipmentToMaintain(): ?Equipment
    {
        return $this->equipmentToMaintain;
    }

    public function setEquipmentToMaintain(?Equipment $equipmentToMaintain): static
    {
        $this->equipmentToMaintain = $equipmentToMaintain;
        return $this;
    }

    /**
     * @return \Doctrine\Common\Collections\Collection<int, SparePart>
     */
    public function getSparePartsToUse()
    {
        return $this->sparePartsToUse;
    }

    /**
     * @param \Doctrine\Common\Collections\Collection<int, SparePart> $sparePartsToUse
     */
    public function setSparePartsToUse($sparePartsToUse): void
    {
        $this->sparePartsToUse = $sparePartsToUse;
    }

    /**
     * @return \Doctrine\Common\Collections\Collection<int, SparePartPreventiveMaintenanceQuantity>
     */
    public function getSparePartPreventiveMaintenanceQuantities()
    {
        return $this->sparePartPreventiveMaintenanceQuantities;
    }

    /**
     * @param \Doctrine\Common\Collections\Collection<int, SparePartPreventiveMaintenanceQuantity> $sparePartPreventiveMaintenanceQuantities
     */
    public function setSparePartPreventiveMaintenanceQuantities($sparePartPreventiveMaintenanceQuantities): void
    {
        $this->sparePartPreventiveMaintenanceQuantities = $sparePartPreventiveMaintenanceQuantities;
    }
    /**
     * @return Collection<int, User>
     */
    public function getPersonnelInCharge(): Collection
    {
        return $this->PersonnelInCharge;
    }

    public function addPersonnelInCharge(User $personnelInCharge): static
    {
        if (!$this->PersonnelInCharge->contains($personnelInCharge)) {
            $this->PersonnelInCharge->add($personnelInCharge);
        }

        return $this;
    }

    public function removePersonnelInCharge(User $personnelInCharge): static
    {
        $this->PersonnelInCharge->removeElement($personnelInCharge);

        return $this;
    }

    public function getIntervention(): ?Intervention
    {
        return $this->intervention;
    }

    public function setIntervention(?Intervention $intervention): static
    {
        $this->intervention = $intervention;

        return $this;
    }
}