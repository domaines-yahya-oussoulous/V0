<?php

namespace App\DTO;


use App\Entity\CorrectiveMaintenance;
use App\Entity\EquipmentCategory;
use App\Entity\Farm;
use App\Entity\PreventiveMaintenance;
use App\Entity\SparePart;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;
use App\Validator\Constraints as CustomAssert;

class EquipmentDTO
{
    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $name = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $reference = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $inventoryCode = null;

    #[Assert\File(
        maxSize: '2048k',
        extensions: ['jpeg','jpg','png'],
        extensionsMessage: 'Please upload a valid image',
    )]
    #[Groups(['writeEquipment', 'updateEquipment'])]
    #[Vich\UploadableField(mapping: 'equipment', fileNameProperty: 'image', size: 'imageSize')]
    private ?File $imageFile = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $image = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $imageSize = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $qrCode = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $family = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $brand = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $acquisitionDate = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $acquisitionCost = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $underWarranty = null;

    #[CustomAssert\Coordinate]
    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?array $gpsData = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $originalDomain = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $countingUnit = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $counter = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $useHoursNumber = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $lastMaintenanceDate = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $nextMaintenanceDate = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $lastBreakdownDate = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $lastBreakdownCause = null;

    #[Assert\File(
        maxSize: '10240k',
        extensions: ['pdf'],
        extensionsMessage: 'Please upload a valid PDF',
    )]
    #[Groups(['writeEquipment', 'updateEquipment'])]
    #[Vich\UploadableField(mapping: 'technical_specification', fileNameProperty: 'technicalSpecificationName', size: 'technicalSpecificationSize')]
    private ?File $technicalSpecificationFile = null;
    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $technicalSpecificationName = null;
    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $technicalSpecificationSize = null;

    #[Assert\File(
        maxSize: '10240k',
        extensions: ['pdf'],
        extensionsMessage: 'Please upload a valid PDF',
    )]
    #[Groups(['writeEquipment', 'updateEquipment'])]
    #[Vich\UploadableField(mapping: 'maintenance_range', fileNameProperty: 'maintenanceRangeName', size: 'maintenanceRangeSize')]
    private ?File $maintenanceRangeFile = null;
    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?string $maintenanceRangeName = null;
    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?int $maintenanceRangeSize = null;

    #[Assert\NotBlank]
    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?Farm $farm = null;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    /**
     * @var Collection<int, SparePart>
     */
    private Collection $spareParts;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    /**
     * @var Collection<int, PreventiveMaintenance>
     */
    private Collection $preventiveMaintenances;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    /**
     * @var Collection<int, CorrectiveMaintenance>
     */
    private Collection $correctiveMaintenances;

    #[Groups(['writeEquipment', 'updateEquipment'])]
    private ?EquipmentCategory $equipmentCategory = null;

    public function __construct()
    {
        $this->spareParts = new ArrayCollection();
        $this->preventiveMaintenances = new ArrayCollection();
        $this->correctiveMaintenances = new ArrayCollection();
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    public function getReference(): ?string
    {
        return $this->reference;
    }

    public function setReference(?string $reference): void
    {
        $this->reference = $reference;
    }

    public function getInventoryCode(): ?string
    {
        return $this->inventoryCode;
    }

    public function setInventoryCode(?string $inventoryCode): void
    {
        $this->inventoryCode = $inventoryCode;
    }

    public function getImageFile(): ?File
    {
        return $this->imageFile;
    }

    public function setImageFile(?File $imageFile): void
    {
        $this->imageFile = $imageFile;
    }

    public function getImage(): ?string
    {
        return $this->image;
    }

    public function setImage(?string $image): void
    {
        $this->image = $image;
    }

    public function getImageSize(): ?string
    {
        return $this->imageSize;
    }

    public function setImageSize(?string $imageSize): void
    {
        $this->imageSize = $imageSize;
    }

    public function getQrCode(): ?string
    {
        return $this->qrCode;
    }

    public function setQrCode(?string $qrCode): void
    {
        $this->qrCode = $qrCode;
    }

    public function getFamily(): ?string
    {
        return $this->family;
    }

    public function setFamily(?string $family): void
    {
        $this->family = $family;
    }

    public function getBrand(): ?string
    {
        return $this->brand;
    }

    public function setBrand(?string $brand): void
    {
        $this->brand = $brand;
    }

    public function getAcquisitionDate(): ?string
    {
        return $this->acquisitionDate;
    }

    public function setAcquisitionDate(?string $acquisitionDate): void
    {
        $this->acquisitionDate = $acquisitionDate;
    }

    public function getAcquisitionCost(): ?string
    {
        return $this->acquisitionCost;
    }

    public function setAcquisitionCost(?string $acquisitionCost): void
    {
        $this->acquisitionCost = $acquisitionCost;
    }

    public function getUnderWarranty(): ?string
    {
        return $this->underWarranty;
    }

    public function setUnderWarranty(?string $underWarranty): void
    {
        $this->underWarranty = $underWarranty;
    }

    public function getGpsData(): ?array
    {
        return $this->gpsData;
    }

    public function setGpsData(?array $gpsData): static
    {
        $this->gpsData = $gpsData;

        return $this;
    }

    public function getOriginalDomain(): ?string
    {
        return $this->originalDomain;
    }

    public function setOriginalDomain(?string $originalDomain): void
    {
        $this->originalDomain = $originalDomain;
    }

    public function getCountingUnit(): ?string
    {
        return $this->countingUnit;
    }

    public function setCountingUnit(?string $countingUnit): void
    {
        $this->countingUnit = $countingUnit;
    }

    public function getCounter(): ?string
    {
        return $this->counter;
    }

    public function setCounter(?string $counter): void
    {
        $this->counter = $counter;
    }

    public function getUseHoursNumber(): ?string
    {
        return $this->useHoursNumber;
    }

    public function setUseHoursNumber(?string $useHoursNumber): void
    {
        $this->useHoursNumber = $useHoursNumber;
    }

    public function getLastMaintenanceDate(): ?string
    {
        return $this->lastMaintenanceDate;
    }

    public function setLastMaintenanceDate(?string $lastMaintenanceDate): void
    {
        $this->lastMaintenanceDate = $lastMaintenanceDate;
    }

    public function getNextMaintenanceDate(): ?string
    {
        return $this->nextMaintenanceDate;
    }

    public function setNextMaintenanceDate(?string $nextMaintenanceDate): void
    {
        $this->nextMaintenanceDate = $nextMaintenanceDate;
    }

    public function getLastBreakdownDate(): ?string
    {
        return $this->lastBreakdownDate;
    }

    public function setLastBreakdownDate(?string $lastBreakdownDate): void
    {
        $this->lastBreakdownDate = $lastBreakdownDate;
    }

    public function getLastBreakdownCause(): ?string
    {
        return $this->lastBreakdownCause;
    }

    public function setLastBreakdownCause(?string $lastBreakdownCause): void
    {
        $this->lastBreakdownCause = $lastBreakdownCause;
    }

    public function setTechnicalSpecificationFile(?File $technicalSpecificationFile = null): void
    {
        $this->technicalSpecificationFile = $technicalSpecificationFile;

        if (null !== $technicalSpecificationFile) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
    }

    public function getTechnicalSpecificationFile(): ?File
    {
        return $this->technicalSpecificationFile;
    }

    public function getTechnicalSpecificationName(): ?string
    {
        return $this->technicalSpecificationName;
    }

    public function setTechnicalSpecificationName(?string $technicalSpecificationName): static
    {
        $this->technicalSpecificationName = $technicalSpecificationName;

        return $this;
    }

    public function getTechnicalSpecificationSize(): ?string
    {
        return $this->technicalSpecificationSize;
    }

    public function setTechnicalSpecificationSize(?string $technicalSpecificationSize): static
    {
        $this->technicalSpecificationSize = $technicalSpecificationSize;

        return $this;
    }

    public function setMaintenanceRangeFile(?File $maintenanceRangeFile = null): void
    {
        $this->maintenanceRangeFile = $maintenanceRangeFile;

        if (null !== $maintenanceRangeFile) {
            // It is required that at least one field changes if you are using doctrine
            // otherwise the event listeners won't be called and the file is lost
            $this->updatedAt = new \DateTimeImmutable();
        }
    }

    public function getMaintenanceRangeFile(): ?File
    {
        return $this->maintenanceRangeFile;
    }

    public function getMaintenanceRangeName(): ?string
    {
        return $this->maintenanceRangeName;
    }

    public function setMaintenanceRangeName(?string $maintenanceRangeName): static
    {
        $this->maintenanceRangeName = $maintenanceRangeName;

        return $this;
    }

    public function getMaintenanceRangeSize(): ?int
    {
        return $this->maintenanceRangeSize;
    }

    public function setMaintenanceRangeSize(?int $maintenanceRangeSize): static
    {
        $this->maintenanceRangeSize = $maintenanceRangeSize;

        return $this;
    }

    public function getFarm(): ?Farm
    {
        return $this->farm;
    }

    public function setFarm(?Farm $farm): void
    {
        $this->farm = $farm;
    }

    /**
     * @return Collection<int, SparePart>
     */
    public function getSpareParts(): Collection
    {
        return $this->spareParts;
    }

    public function addSparePart(SparePart $sparePart): void
    {
        if (!$this->spareParts->contains($sparePart)) {
            $this->spareParts[] = $sparePart;
        }
    }

    public function removeSparePart(SparePart $sparePart): void
    {
        $this->spareParts->removeElement($sparePart);
    }

    /**
     * @return Collection<int, PreventiveMaintenance>
     */
    public function getPreventiveMaintenances(): Collection
    {
        return $this->preventiveMaintenances;
    }

    public function addPreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): void
    {
        if (!$this->preventiveMaintenances->contains($preventiveMaintenance)) {
            $this->preventiveMaintenances[] = $preventiveMaintenance;
        }
    }

    public function removePreventiveMaintenance(PreventiveMaintenance $preventiveMaintenance): void
    {
        $this->preventiveMaintenances->removeElement($preventiveMaintenance);
    }

    /**
     * @return Collection<int, CorrectiveMaintenance>
     */
    public function getCorrectiveMaintenances(): Collection
    {
        return $this->correctiveMaintenances;
    }

    public function addCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): void
    {
        if (!$this->correctiveMaintenances->contains($correctiveMaintenance)) {
            $this->correctiveMaintenances[] = $correctiveMaintenance;
        }
    }

    public function removeCorrectiveMaintenance(CorrectiveMaintenance $correctiveMaintenance): void
    {
        $this->correctiveMaintenances->removeElement($correctiveMaintenance);
    }

    public function getEquipmentCategory(): ?EquipmentCategory
    {
        return $this->equipmentCategory;
    }

    public function setEquipmentCategory(?EquipmentCategory $equipmentCategory): static
    {
        $this->equipmentCategory = $equipmentCategory;

        return $this;
    }

}
