<?php

namespace App\DTO;

use App\Entity\Equipment;
use App\Entity\Farm;
use App\Entity\SparePartCategory;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Symfony\Component\HttpFoundation\File\File;
use Vich\UploaderBundle\Mapping\Annotation as Vich;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

class SparePartDTO
{
    #[Groups(['spare-parts:write', 'spare-parts:update', 'spare-parts-by-farm:read'])]
    private ?string $name = null;

    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?string $reference = null;

    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?string $inventoryCode = null;

    #[Assert\File(
        maxSize: '2048k',
        extensions: ['jpeg','jpg','png'],
        extensionsMessage: 'Please upload a valid image',
    )]
    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    #[Vich\UploadableField(mapping: 'spartparts', fileNameProperty: 'image', size: 'imageSize')]
    private ?File $imageFile = null;

    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?string $brand = null;

    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?string $unitPrice = null;

    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?string $availability = null;

    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?string $quantity = null;

    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?string $orderDuration = null;

    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?string $lastInventoryDate = null;

    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    /**
     * @var Collection<int, Equipment>
     */
    private Collection $equipment;

    #[Assert\NotBlank]
    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?Farm $farm = null;

    #[Assert\NotBlank]
    #[Groups(['spare-parts:write', 'spare-parts:update'])]
    private ?SparePartCategory $sparePartCategory = null;

    public function __construct()
    {
        $this->equipment = new ArrayCollection();
        $this->preventiveMaintenances = new ArrayCollection();
        $this->correctiveMaintenances = new ArrayCollection();
    }

    // Getters and Setters

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    public function getReference(): ?string
    {
        return $this->reference;
    }

    public function setReference(?string $reference): void
    {
        $this->reference = $reference;
    }

    public function getInventoryCode(): ?string
    {
        return $this->inventoryCode;
    }

    public function setInventoryCode(?string $inventoryCode): void
    {
        $this->inventoryCode = $inventoryCode;
    }

    public function getImageFile(): ?File
    {
        return $this->imageFile;
    }

    public function setImageFile(?File $imageFile): void
    {
        $this->imageFile = $imageFile;
    }

    public function getBrand(): ?string
    {
        return $this->brand;
    }

    public function setBrand(?string $brand): void
    {
        $this->brand = $brand;
    }

    public function getUnitPrice(): ?string
    {
        return $this->unitPrice;
    }

    public function setUnitPrice(?string $unitPrice): void
    {
        $this->unitPrice = $unitPrice;
    }

    public function getAvailability(): ?string
    {
        return $this->availability;
    }

    public function setAvailability(?string $availability): void
    {
        $this->availability = $availability;
    }

    public function getQuantity(): ?string
    {
        return $this->quantity;
    }

    public function setQuantity(?string $quantity): void
    {
        $this->quantity = $quantity;
    }

    public function getOrderDuration(): ?string
    {
        return $this->orderDuration;
    }

    public function setOrderDuration(?string $orderDuration): void
    {
        $this->orderDuration = $orderDuration;
    }

    public function getLastInventoryDate(): ?string
    {
        return $this->lastInventoryDate;
    }

    public function setLastInventoryDate(?string $lastInventoryDate): void
    {
        $this->lastInventoryDate = $lastInventoryDate;
    }

    /**
     * @return Collection<int, Equipment>
     */
    public function getEquipment(): Collection
    {
        return $this->equipment;
    }

    public function addEquipment(Equipment $equipment): void
    {
        if (!$this->equipment->contains($equipment)) {
            $this->equipment[] = $equipment;
        }
    }

    public function removeEquipment(Equipment $equipment): void
    {
        $this->equipment->removeElement($equipment);
    }

    public function getFarm(): ?Farm
    {
        return $this->farm;
    }

    public function setFarm(?Farm $farm): void
    {
        $this->farm = $farm;
    }

    public function getSparePartCategory(): ?SparePartCategory
    {
        return $this->sparePartCategory;
    }

    public function setSparePartCategory(?SparePartCategory $sparePartCategory): static
    {
        $this->sparePartCategory = $sparePartCategory;

        return $this;
    }

}
