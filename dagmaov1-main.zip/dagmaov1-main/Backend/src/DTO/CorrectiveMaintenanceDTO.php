<?php
namespace App\DTO;

use App\Entity\CorrectiveMaintenanceImage;
use App\Entity\Equipment;
use App\Entity\Intervention;
use App\Entity\SparePart;
use App\Entity\SparePartCorrectiveMaintenanceQuantity;
use App\Entity\User;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Symfony\Component\Serializer\Annotation\Groups;
use Symfony\Component\Validator\Constraints as Assert;

class CorrectiveMaintenanceDTO
{
    #[Groups(['corrective-maintenance:write'])]
    private ?string $failureType = null;
    #[Groups(['corrective-maintenance:write'])]
    private ?string $failureDescription = null;
    #[Groups(['corrective-maintenance:write'])]
    private ?string $breakdownTime = null;
    #[Groups(['corrective-maintenance:write'])]
    private ?string $breakdownSite = null;
    #[Groups(['corrective-maintenance:write'])]
    private ?string $estimatedDownTime = null;
    #[Assert\Choice(["HOURS", "DAYS", "MONTHS"])]
    #[Groups(['corrective-maintenance:write'])]
    private ?string $estimatedDownTimeUnit = null;
    #[Groups(['corrective-maintenance:write'])]
    private ?string $breakdownProbableCause = null;
    #[Assert\Choice(["HIGH", "MEDIUM", "LOW"])]
    #[Groups(['corrective-maintenance:write'])]
    private ?string $urgencyLevel = null;
    #[Groups(['corrective-maintenance:write'])]
    private ?string $interventionEstimatedDuration = null;
    #[Assert\Choice(["HOURS", "DAYS", "MONTHS"])]
    #[Groups(['corrective-maintenance:write'])]
    private ?string $interventionEstimatedDurationUnit = null;
    #[Groups(['corrective-maintenance:write'])]
    private ?string $estimatedInterventionDate = null;
    #[Assert\Choice(["INTERNAL", "EXTERNAL"])]
    #[Groups(['corrective-maintenance:write'])]
    private ?string $personnelType = null;
    #[Groups(['corrective-maintenance:write'])]
    private ?Equipment $equipmentToMaintain = null;
    /**
     * @var Collection<int, SparePart>
     */
    #[Groups(['corrective-maintenance:write'])]
    private Collection $sparePartsToUse;
    /**
     * @var Collection<int, SparePartCorrectiveMaintenanceQuantity>
     */
    #[Groups(['corrective-maintenance:write'])]
    private Collection $sparePartCorrectiveMaintenanceQuantities;

    /**
     * @var Collection<int, User>
     */
    #[Groups(['corrective-maintenance:write'])]
    private Collection $PersonnelInCharge;

    #[Groups(['corrective-maintenance:write'])]
    private ?Intervention $intervention = null;
    public function __construct()
    {
        $this->sparePartsToUse = new ArrayCollection();
        $this->sparePartCorrectiveMaintenanceQuantities = new ArrayCollection();
        $this->PersonnelInCharge = new ArrayCollection();
    }

    public function getFailureType(): ?string
    {
        return $this->failureType;
    }

    public function setFailureType(?string $failureType): self
    {
        $this->failureType = $failureType;
        return $this;
    }

    public function getFailureDescription(): ?string
    {
        return $this->failureDescription;
    }

    public function setFailureDescription(?string $failureDescription): self
    {
        $this->failureDescription = $failureDescription;
        return $this;
    }

    public function getBreakdownTime(): ?string
    {
        return $this->breakdownTime;
    }

    public function setBreakdownTime(?string $breakdownTime): self
    {
        $this->breakdownTime = $breakdownTime;
        return $this;
    }

    public function getBreakdownSite(): ?string
    {
        return $this->breakdownSite;
    }

    public function setBreakdownSite(?string $breakdownSite): self
    {
        $this->breakdownSite = $breakdownSite;
        return $this;
    }

    public function getEstimatedDownTime(): ?string
    {
        return $this->estimatedDownTime;
    }

    public function setEstimatedDownTime(?string $estimatedDownTime): self
    {
        $this->estimatedDownTime = $estimatedDownTime;
        return $this;
    }
    public function getEstimatedDownTimeUnit(): ?string
    {
        return $this->estimatedDownTimeUnit;
    }

    public function setEstimatedDownTimeUnit(?string $estimatedDownTimeUnit): static
    {
        $this->estimatedDownTimeUnit = $estimatedDownTimeUnit;

        return $this;
    }

    public function getBreakdownProbableCause(): ?string
    {
        return $this->breakdownProbableCause;
    }

    public function setBreakdownProbableCause(?string $breakdownProbableCause): self
    {
        $this->breakdownProbableCause = $breakdownProbableCause;
        return $this;
    }

    public function getUrgencyLevel(): ?string
    {
        return $this->urgencyLevel;
    }

    public function setUrgencyLevel(?string $urgencyLevel): self
    {
        $this->urgencyLevel = $urgencyLevel;
        return $this;
    }

    public function getInterventionEstimatedDuration(): ?string
    {
        return $this->interventionEstimatedDuration;
    }

    public function setInterventionEstimatedDuration(?string $interventionEstimatedDuration): static
    {
        $this->interventionEstimatedDuration = $interventionEstimatedDuration;

        return $this;
    }

    public function getInterventionEstimatedDurationUnit(): ?string
    {
        return $this->interventionEstimatedDurationUnit;
    }

    public function setInterventionEstimatedDurationUnit(?string $interventionEstimatedDurationUnit): static
    {
        $this->interventionEstimatedDurationUnit = $interventionEstimatedDurationUnit;

        return $this;
    }

    public function getEstimatedInterventionDate(): ?string
    {
        return $this->estimatedInterventionDate;
    }

    public function setEstimatedInterventionDate(?string $estimatedInterventionDate): static
    {
        $this->estimatedInterventionDate = $estimatedInterventionDate;

        return $this;
    }

    public function getPersonnelType(): ?string
    {
        return $this->personnelType;
    }

    public function setPersonnelType(?string $personnelType): self
    {
        $this->personnelType = $personnelType;
        return $this;
    }

    public function getEquipmentToMaintain(): ?Equipment
    {
        return $this->equipmentToMaintain;
    }

    public function setEquipmentToMaintain(?Equipment $equipmentToMaintain): self
    {
        $this->equipmentToMaintain = $equipmentToMaintain;
        return $this;
    }

    /**
     * @return Collection<int, SparePart>
     */
    public function getSparePartsToUse(): Collection
    {
        return $this->sparePartsToUse;
    }

    public function addSparePartToUse(SparePart $sparePart): self
    {
        if (!$this->sparePartsToUse->contains($sparePart)) {
            $this->sparePartsToUse->add($sparePart);
        }
        return $this;
    }

    public function removeSparePartToUse(SparePart $sparePart): self
    {
        $this->sparePartsToUse->removeElement($sparePart);
        return $this;
    }

    /**
     * @return Collection<int, SparePartCorrectiveMaintenanceQuantity>
     */
    public function getSparePartCorrectiveMaintenanceQuantities(): Collection
    {
        return $this->sparePartCorrectiveMaintenanceQuantities;
    }

    public function addSparePartCorrectiveMaintenanceQuantity(SparePartCorrectiveMaintenanceQuantity $quantity): self
    {
        if (!$this->sparePartCorrectiveMaintenanceQuantities->contains($quantity)) {
            $this->sparePartCorrectiveMaintenanceQuantities->add($quantity);
        }
        return $this;
    }

    public function removeSparePartCorrectiveMaintenanceQuantity(SparePartCorrectiveMaintenanceQuantity $quantity): self
    {
        $this->sparePartCorrectiveMaintenanceQuantities->removeElement($quantity);
        return $this;
    }
    /**
     * @return Collection<int, User>
     */
    public function getPersonnelInCharge(): Collection
    {
        return $this->PersonnelInCharge;
    }

    public function addPersonnelInCharge(User $personnelInCharge): static
    {
        if (!$this->PersonnelInCharge->contains($personnelInCharge)) {
            $this->PersonnelInCharge->add($personnelInCharge);
        }

        return $this;
    }

    public function removePersonnelInCharge(User $personnelInCharge): static
    {
        $this->PersonnelInCharge->removeElement($personnelInCharge);

        return $this;
    }

    public function getIntervention(): ?Intervention
    {
        return $this->intervention;
    }

    public function setIntervention(?Intervention $intervention): static
    {
        $this->intervention = $intervention;

        return $this;
    }
}
