<?php

namespace App\Validator\Constraints;

use Symfony\Component\Validator\Constraint;
use Attribute;

#[Attribute(Attribute::TARGET_PROPERTY | Attribute::TARGET_METHOD)]
class Coordinate extends Constraint
{
    public $message = 'The value "{{ value }}" is not a valid coordinate.';
}