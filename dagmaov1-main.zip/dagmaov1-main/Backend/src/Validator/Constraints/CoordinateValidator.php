<?php

namespace App\Validator\Constraints;

use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;

class CoordinateValidator extends ConstraintValidator
{
    public function validate($value, Constraint $constraint)
    {
        /* @var $constraint \App\Validator\Constraints\Coordinate */

        // Check if $value is null or an array
        if ($value === null) {
            // If null and nullable, no validation needed
            return;
        }

        if (!is_array($value)) {
            $this->context->buildViolation('The value should be an array or null.')
                ->addViolation();
            return;
        }

        // Validate the structure and values of $value
        $keys = array_keys($value);
        $uniqueKeys = array_unique($keys);

        if (count($keys) !== count($uniqueKeys)) {
            $this->context->buildViolation('Duplicate keys are not allowed.')
                ->addViolation();
            return;
        }

        if (!isset($value['latitude']) || !isset($value['longitude'])) {
            $this->context->buildViolation('The latitude and longitude keys are required.')
                ->addViolation();
            return;
        }

        if (!is_numeric($value['latitude']) || !is_numeric($value['longitude'])) {
            $this->context->buildViolation('Latitude and longitude must be numeric.')
                ->addViolation();
            return;
        }

        // Check for extra keys in $value
        $allowedKeys = ['latitude', 'longitude'];
        $extraKeys = array_diff($keys, $allowedKeys);
        if (!empty($extraKeys)) {
            $this->context->buildViolation('Extra keys are not allowed: ' . implode(', ', $extraKeys))
                ->addViolation();
            return;
        }
    }
}
