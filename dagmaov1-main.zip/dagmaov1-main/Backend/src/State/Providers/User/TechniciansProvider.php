<?php

namespace App\State\Providers\User;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProviderInterface;

class TechniciansProvider implements ProviderInterface
{
    public function __construct(
        private ProviderInterface $provider,
    )
    {
    }
    public function provide(Operation $operation, array $uriVariables = [], array $context = []): object|array|null
    {

        $farm = $this->provider->provide($operation, $uriVariables, $context);
        $users = $farm->getUsers();
        $technicians = [];
        foreach ($users as $user) {
            if ($user->getType() === 'technician') {
                $technicians[] = $user;
            }
        }

        return $technicians;
    }
}
