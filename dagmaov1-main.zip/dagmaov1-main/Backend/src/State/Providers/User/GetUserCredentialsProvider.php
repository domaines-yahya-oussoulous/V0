<?php

namespace App\State\Providers\User;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProviderInterface;
use Symfony\Bundle\SecurityBundle\Security;


class GetUserCredentialsProvider implements ProviderInterface
{
    public function  __construct(private ProviderInterface $provider,private Security $security)
    {

    }
    public function provide(Operation $operation, array $uriVariables = [], array $context = []): object|array|null
    {
        if (!$this->security->isGranted('IS_AUTHENTICATED_FULLY')) {
            return null;
        }
        $userIdFromToken = $this->security->getUser();
        return $userIdFromToken;
    }
}