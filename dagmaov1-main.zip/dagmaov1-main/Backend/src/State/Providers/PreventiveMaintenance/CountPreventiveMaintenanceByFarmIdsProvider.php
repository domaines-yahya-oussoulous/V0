<?php

namespace App\State\Providers\PreventiveMaintenance;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProviderInterface;
use App\Repository\PreventiveMaintenanceRepository;

class CountPreventiveMaintenanceByFarmIdsProvider implements ProviderInterface
{
    public function __construct(
        private PreventiveMaintenanceRepository $preventiveMaintenanceRepository
    )
    {
    }
    public function provide(Operation $operation, array $uriVariables = [], array $context = []): object|array|null
    {
        //dd($uriVariables);
        $farmsIdString = $uriVariables['farmsId'] ?? '';
        $farmsIdArray = array_map('intval', explode(',', $farmsIdString));
        return $this->preventiveMaintenanceRepository->countPreventiveMaintenancesByFarmIds($farmsIdArray);
    }
}
