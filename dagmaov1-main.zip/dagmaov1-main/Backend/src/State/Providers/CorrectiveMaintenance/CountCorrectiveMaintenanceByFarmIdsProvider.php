<?php

namespace App\State\Providers\CorrectiveMaintenance;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProviderInterface;
use App\Repository\CorrectiveMaintenanceRepository;

class CountCorrectiveMaintenanceByFarmIdsProvider implements ProviderInterface
{
    public function __construct(
        private CorrectiveMaintenanceRepository $correctiveMaintenanceRepository
    )
    {
    }
    public function provide(Operation $operation, array $uriVariables = [], array $context = []): object|array|null
    {
        $farmsIdString = $uriVariables['farmsId'] ?? '';
        $farmsIdArray = array_map('intval', explode(',', $farmsIdString));
        return $this->correctiveMaintenanceRepository->countCorrectiveMaintenancesByFarmIds($farmsIdArray);
    }
}
