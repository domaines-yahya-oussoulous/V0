<?php

namespace App\State\Providers\CorrectiveMaintenance;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProviderInterface;
use App\Repository\CorrectiveMaintenanceRepository;

class CountCorrectiveMaintenanceByStateProvider implements ProviderInterface
{
    public function __construct(
        private CorrectiveMaintenanceRepository $correctiveMaintenanceRepository
    )
    {
    }
    public function provide(Operation $operation, array $uriVariables = [], array $context = []): object|array|null
    {
        //dd($uriVariables);
        $farmsIdString = $uriVariables['farmsId'] ?? '';
        $farmsIdArray = array_map('intval', explode(',', $farmsIdString));
        $state = $uriVariables['state'] ?? '';
        return $this->correctiveMaintenanceRepository->countCorrectiveMaintenancesByState($farmsIdArray,$state);
    }
}
