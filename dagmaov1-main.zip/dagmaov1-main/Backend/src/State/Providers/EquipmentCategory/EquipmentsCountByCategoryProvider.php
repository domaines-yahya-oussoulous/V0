<?php

namespace App\State\Providers\EquipmentCategory;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProviderInterface;
use App\Repository\EquipmentCategoryRepository;

class EquipmentsCountByCategoryProvider implements ProviderInterface
{
    public function __construct(
        private ProviderInterface $provider,
        private EquipmentCategoryRepository $equipmentCategoryRepository
    )
    {
    }
    public function provide(Operation $operation, array $uriVariables = [], array $context = []): object|array|null
    {
        return $this->equipmentCategoryRepository->countEquipmentByCategory();
    }
}
