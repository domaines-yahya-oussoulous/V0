<?php

namespace App\State\Processors\SparePart;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProcessorInterface;
use App\Entity\SparePart;
use App\DTO\SparePartDTO;
use Doctrine\ORM\EntityManagerInterface;

class CreateUpdateSparePartProcessor implements ProcessorInterface
{
    public function __construct(private ProcessorInterface $processorInterface,private EntityManagerInterface $entityManager)
    {

    }
    function convertToBoolean($value) {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    }
    public function process(mixed $data, Operation $operation, array $uriVariables = [], array $context = [])
    {
        if (!$data instanceof SparePartDTO) {
            throw new \InvalidArgumentException('Unexpected type for data');
        }
        if ($operation->getName() === "SparePartsCreating") {
            $sparePart = new SparePart();
        } elseif ($operation->getName() === "SparePartsUpdating") {
            $sparePart = $this->entityManager->getRepository(SparePart::class)->find($uriVariables['id']);
            if (!$sparePart) {
                throw new \InvalidArgumentException('SparePart not found');
            }
        } else {
            throw new \InvalidArgumentException('Unexpected operation');
        }
        $sparePart->setName($data->getName());
        $sparePart->setReference($data->getReference());
        $sparePart->setInventoryCode($data->getInventoryCode());
        $sparePart->setImageFile($data->getImageFile());
        $sparePart->setSparePartCategory($data->getSparePartCategory());
        $sparePart->setCategoryName($data->getSparePartCategory()->getName());
        $sparePart->setBrand($data->getBrand());
        $sparePart->setUnitPrice((float)$data->getUnitPrice());
        $sparePart->setAvailability($this->convertToBoolean($data->getAvailability()));
        $sparePart->setQuantity((int)$data->getQuantity());
        $sparePart->setOrderDuration((float)$data->getOrderDuration());
        $sparePart->setLastInventoryDate($data->getLastInventoryDate() ? new \DateTime($data->getLastInventoryDate()) : null);
        $sparePart->setFarm($data->getFarm());
        $equipmentData = $data->getEquipment();
        foreach ($equipmentData as $equipmentItem){
            $sparePart->addEquipment($equipmentItem);
        }
        return $this->processorInterface->process($sparePart, $operation, $uriVariables, $context);

    }
}
