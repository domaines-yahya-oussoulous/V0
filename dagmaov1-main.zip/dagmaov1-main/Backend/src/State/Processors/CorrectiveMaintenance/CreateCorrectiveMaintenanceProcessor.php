<?php

namespace App\State\Processors\CorrectiveMaintenance;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProcessorInterface;
use App\DTO\CorrectiveMaintenanceDTO;
use App\Entity\CorrectiveMaintenance;
use App\Entity\CorrectiveMaintenanceImage;
use App\Entity\SparePart;
use App\Entity\SparePartCorrectiveMaintenanceQuantity;
use App\Exception\InsufficientSparePartsQuantityException;
use App\Exception\InterventionDateInvalidException;
use App\Exception\InvalidPersonnelTypeException;
use App\Exception\SparePartFarmMismatchException;
use App\Exception\SparePartNotFoundException;
use App\Exception\TechnicianFarmMismatchException;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\RequestStack;
use Vich\UploaderBundle\Handler\UploadHandler;

class CreateCorrectiveMaintenanceProcessor implements ProcessorInterface
{
    private ProcessorInterface $processorInterface;
    private RequestStack $requestStack;
    private UploadHandler $uploadHandler;
    private EntityManagerInterface $entityManager;

    public function __construct(EntityManagerInterface $entityManager, ProcessorInterface $processorInterface, RequestStack $requestStack, UploadHandler $uploadHandler)
    {
        $this->entityManager = $entityManager;
        $this->processorInterface = $processorInterface;
        $this->requestStack = $requestStack;
        $this->uploadHandler = $uploadHandler;
    }
    public function process(mixed $data, Operation $operation, array $uriVariables = [], array $context = [])
    {
        if (!$data instanceof CorrectiveMaintenanceDTO) {
            throw new \InvalidArgumentException('Unexpected type for data');
        }
        $correctiveMaintenance = new CorrectiveMaintenance();
        $correctiveMaintenance->setFailureType($data->getFailureType());
        $correctiveMaintenance->setFailureDescription($data->getFailureDescription());
        $correctiveMaintenance->setBreakdownSite($data->getBreakdownSite());
        $correctiveMaintenance->setEstimatedDownTime((int)$data->getEstimatedDownTime());
        $correctiveMaintenance->setEstimatedDownTimeUnit($data->getEstimatedDownTimeUnit());
        $correctiveMaintenance->setInterventionEstimatedDuration((int)$data->getInterventionEstimatedDuration());
        $correctiveMaintenance->setInterventionEstimatedDurationUnit($data->getInterventionEstimatedDurationUnit());
        $correctiveMaintenance->setIntervention($data->getIntervention());
        //$correctiveMaintenance->setInterventionDate($data->getInterventionDate() ? new \DateTime($data->getInterventionDate()) : null);
        $correctiveMaintenance->setBreakdownProbableCause($data->getBreakdownProbableCause());
        $correctiveMaintenance->setUrgencyLevel($data->getUrgencyLevel());
        $correctiveMaintenance->setPersonnelType($data->getPersonnelType());
        $correctiveMaintenance->setEquipmentToMaintain($data->getEquipmentToMaintain());
        $correctiveMaintenance->setState("WAITING_FOR_VALIDATION");
        $equipment = $correctiveMaintenance->getEquipmentToMaintain();
        $correctiveMaintenance->setEquipmentName($equipment->getName());
        $equipmentFarm = $equipment->getFarm();
        $sparePartQuantities = $data->getSparePartCorrectiveMaintenanceQuantities();

        //intervention time exception

        $estimatedInterventionDate = $data->getEstimatedInterventionDate();

        if ($estimatedInterventionDate) {
            $dateTime = new \DateTime($estimatedInterventionDate);

            // Get the current date without time (today starts from midnight)
            $now = new \DateTime('today');

            // Allow the estimatedInterventionDate to be today or in the future
            if ($dateTime < $now) {
                throw new InterventionDateInvalidException(sprintf('Intervention date cannot be in the past.'));
            } else {
                $correctiveMaintenance->setEstimatedInterventionDate($dateTime);
            }
        } else {
            $correctiveMaintenance->setEstimatedInterventionDate(null);
        }
        //breakdown time exception
        $breakdownTime = $data->getBreakdownTime();

        if ($breakdownTime) {
            $dateTime = new \DateTime($breakdownTime);

            // Get the current date without time (only date part matters)
            $now = new \DateTime('today');

            // Allow breakdownTime to be today or in the past
            if ($dateTime > $now) {
                throw new InterventionDateInvalidException(sprintf('Breakdown time cannot be in the future.'));
            } else {
                $correctiveMaintenance->setBreakdownTime($dateTime);
            }
        } else {
            $correctiveMaintenance->setBreakdownTime(null);
        }

        foreach ($sparePartQuantities as $sparePartQuantity) {
            //dd($sparePartQuantities);
            $sparePartUri = $sparePartQuantity->getSparePart()->getId();
            //dd($sparePartUri);
            /** @var SparePart $sparePart */
            $sparePart = $this->entityManager->getRepository(SparePart::class)->find($sparePartUri);

            if (!$sparePart) {
                throw new SparePartNotFoundException('Spare part not found for id ' . $sparePartUri);
            }

            if ($sparePart->getFarm() !== $equipmentFarm) {
                throw new SparePartFarmMismatchException(sprintf('Spare part ' . $sparePart->getName() . ' does not belong to the same farm as the equipment.'));
            }

            $quantityNeeded = $sparePartQuantity->getQuantity();
            $currentQuantity = $sparePart->getQuantity();

            if ($currentQuantity < $quantityNeeded) {
                throw new InsufficientSparePartsQuantityException(sprintf('Insufficient quantity of ' . $sparePart->getName() . ' available.'));
            }
            $sparePart->setQuantity($currentQuantity - $quantityNeeded);

            $sparePartCorrectiveMaintenanceQuantity = new SparePartCorrectiveMaintenanceQuantity();
            $sparePartCorrectiveMaintenanceQuantity->setSparePart($sparePart);
            $sparePartCorrectiveMaintenanceQuantity->setQuantity($quantityNeeded);
            $sparePartCorrectiveMaintenanceQuantity->setCorrectiveMaintenance($correctiveMaintenance);

            $correctiveMaintenance->addSparePartCorrectiveMaintenanceQuantity($sparePartCorrectiveMaintenanceQuantity);
        }
        //for personnal in charge
        $personnelInCharge = $data->getPersonnelInCharge();
        foreach ($personnelInCharge as $person) {
            if ($person->getType() !== 'technician') {
                throw new InvalidPersonnelTypeException(sprintf('Personnel in charge must be of type technician.'));
            }
            if ($person->getFarm() !== $equipmentFarm) {
                throw new TechnicianFarmMismatchException(sprintf('Technician ' . $person->getFirstName() .' '. $person->getLastName() . ' does not belong to the same farm as the equipment.'));
            }
            $correctiveMaintenance->addPersonnelInCharge($person);
        }
        //

        // Process the main PreventiveMaintenance entity
        $this->processorInterface->process($correctiveMaintenance, $operation, $uriVariables, $context);

        // Handle file uploads and persist them
        $request = $this->requestStack->getCurrentRequest();
        $files = $request->files->get('imageFiles'); // Adjusted to match your form field name

        if ($files && is_array($files)) {
            foreach ($files as $file) {
                if ($file instanceof UploadedFile) {
                    // Validate if it's an image
                    if ($file->getMimeType() && strpos($file->getMimeType(), 'image/') === 0) {
                        $pmImage = new CorrectiveMaintenanceImage();
                        $pmImage->setImageFile($file);
                        $this->uploadHandler->upload($pmImage, 'imageFile'); // Adjusted to match your entity field name
                        $correctiveMaintenance->addImage($pmImage);

                        // Persist the image entity
                        $this->entityManager->persist($pmImage);
                    } else {
                        throw new \Exception('Uploaded file is not an image.');
                    }
                }
            }

            // Flush all changes to the database
            $this->entityManager->flush();
        }
        return $correctiveMaintenance;
    }
}
