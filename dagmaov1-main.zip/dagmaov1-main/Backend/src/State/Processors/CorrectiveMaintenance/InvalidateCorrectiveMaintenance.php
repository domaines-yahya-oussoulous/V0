<?php

namespace App\State\Processors\CorrectiveMaintenance;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProcessorInterface;

class InvalidateCorrectiveMaintenance implements ProcessorInterface
{
    public function __construct(private ProcessorInterface $processorInterface)
    {
    }

    public function process(mixed $data, Operation $operation, array $uriVariables = [], array $context = [])
    {
        $data->setState('NON_VALIDATED');
        return $this->processorInterface->process($data, $operation, $uriVariables, $context);
    }
}
