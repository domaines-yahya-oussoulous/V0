<?php

namespace App\State\Processors\User;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProcessorInterface;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class CreateUserProcessor implements ProcessorInterface
{
    private const VALID_USER_TYPES = ['technician', 'maintenance_manager', 'director', 'admin'];
    public function __construct(private UserPasswordHasherInterface $userPasswordHasherInterface, private ProcessorInterface $processorInterface)
    {
    }

    public function process(mixed $data, Operation $operation, array $uriVariables = [], array $context = [])
    {
        if (!in_array($data->getType(), self::VALID_USER_TYPES, true)) {
            throw new \InvalidArgumentException(sprintf('Invalid user type: %s. Valid types are: %s', $data->getType(), implode(', ', self::VALID_USER_TYPES)));
        }
        // Ensure the farm is assigned for non-admin users
        if ($data->getType() !== 'admin' && !$data->getFarm()) {
            throw new \RuntimeException('Farm must be assigned for non-admin users.');
        }
        // Ensure admin does not have a farm
        if ($data->getType() === 'admin' && $data->getFarm()) {
            throw new \RuntimeException('Admin user should not be assigned a farm.');
        }

        // Hash the user's password
        $hashedPassword = $this->userPasswordHasherInterface->hashPassword($data, $data->getPassword());
        $data->setPassword($hashedPassword);

        // Set roles based on user type
        $roles = [];
        switch ($data->getType()) {
            case 'technician':
                $roles[] = 'ROLE_TECHNICIAN';
                break;
            case 'maintenance_manager':
                $roles[] = 'ROLE_MAINTENANCE_MANAGER';
                break;
            case 'director':
                $roles[] = 'ROLE_DIRECTOR';
                break;
            case 'admin':
                $roles[] = 'ROLE_ADMIN';
                break;
            default:
                break;
        }
        $data->setRoles($roles);

        // Delegate further processing
        return $this->processorInterface->process($data, $operation, $uriVariables, $context);
    }
}
