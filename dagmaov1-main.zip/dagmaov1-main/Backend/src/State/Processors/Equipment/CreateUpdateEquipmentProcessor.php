<?php

namespace App\State\Processors\Equipment;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProcessorInterface;
use App\Entity\Equipment;
use App\DTO\EquipmentDTO;
use Doctrine\ORM\EntityManagerInterface;

class CreateUpdateEquipmentProcessor implements ProcessorInterface
{
    public function __construct(private ProcessorInterface $processorInterface,private EntityManagerInterface $entityManager)
    {

    }
    function convertToBoolean($value) {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    }

    public function process(mixed $data, Operation $operation, array $uriVariables = [], array $context = [])
    {
        if (!$data instanceof EquipmentDTO) {
            throw new \InvalidArgumentException('Unexpected type for data');
        }
        if ($operation->getName() === "EquipmentCreating") {
            $equipment = new Equipment();
        } elseif ($operation->getName() === "EquipmentUpdating") {
            $equipment = $this->entityManager->getRepository(Equipment::class)->find($uriVariables['id']);
            if (!$equipment) {
                throw new \InvalidArgumentException('Equipment not found');
            }
        } else {
            throw new \InvalidArgumentException('Unexpected operation');
        }
        //$equipment = new Equipment();
        //$equipment = $data;
        $equipment->setName($data->getName());
        $equipment->setReference($data->getReference());
        $equipment->setInventoryCode($data->getInventoryCode());
        $equipment->setImageFile($data->getImageFile());
        $equipment->setQrCode($data->getQrCode());
        $equipment->setFamily($data->getFamily());
        $equipment->setEquipmentCategory($data->getEquipmentCategory());
        $equipment->setCategoryName($data->getEquipmentCategory()->getName());
        $equipment->setBrand($data->getBrand());
        //$equipment->setUnitsNumber((int)$data->getUnitsNumber());
        $equipment->setAcquisitionDate($data->getAcquisitionDate() ? new \DateTime($data->getAcquisitionDate()) : null);
        $equipment->setAcquisitionCost((float)$data->getAcquisitionCost());
        //dd($this->convertToBoolean($data->getUnderWarranty()));
        $equipment->setUnderWarranty($this->convertToBoolean($data->getUnderWarranty()));
        $equipment->setGpsData($data->getGpsData());
        $equipment->setOriginalDomain($data->getOriginalDomain());
        $equipment->setCountingUnit($data->getCountingUnit());
        $equipment->setCounter((float)$data->getCounter());
        $equipment->setUseHoursNumber((float)$data->getUseHoursNumber());
        $equipment->setLastMaintenanceDate($data->getLastMaintenanceDate() ? new \DateTime($data->getLastMaintenanceDate()) : null);
        $equipment->setNextMaintenanceDate($data->getNextMaintenanceDate() ? new \DateTime($data->getNextMaintenanceDate()) : null);
        $equipment->setLastBreakdownDate($data->getLastBreakdownDate() ? new \DateTime($data->getLastBreakdownDate()) : null);
        $equipment->setLastBreakdownCause($data->getLastBreakdownCause());
        $equipment->setTechnicalSpecificationFile($data->getTechnicalSpecificationFile());
        $equipment->setMaintenanceRangeFile($data->getMaintenanceRangeFile());
        $equipment->setFarm($data->getFarm());
        //$equipment->addSparePart($data->getSpareParts());
        $sparePartsData = $data->getSpareParts();
        foreach ($sparePartsData as $sparePartItem) {
            $equipment->addSparePart($sparePartItem);
        }
        return $this->processorInterface->process($equipment, $operation, $uriVariables, $context);
    }
}
