<?php

namespace App\State\Processors\PreventiveMaintenance;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProcessorInterface;

class ValidatePreventiveMaintenance implements ProcessorInterface
{
    public function __construct(private ProcessorInterface $processorInterface)
    {
    }

    public function process(mixed $data, Operation $operation, array $uriVariables = [], array $context = [])
    {
        $data->setState('PLANNED');
        return $this->processorInterface->process($data, $operation, $uriVariables, $context);
    }
}
