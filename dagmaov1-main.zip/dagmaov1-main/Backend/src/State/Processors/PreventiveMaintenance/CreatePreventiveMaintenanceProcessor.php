<?php

namespace App\State\Processors\PreventiveMaintenance;

use ApiPlatform\Metadata\Operation;
use ApiPlatform\State\ProcessorInterface;
use App\DTO\PreventiveMaintenanceDTO;
use App\Entity\PreventiveMaintenance;
use App\Entity\PreventiveMaintenanceImage;
use App\Entity\SparePart;
use App\Entity\SparePartPreventiveMaintenanceQuantity;
use App\Exception\DuplicateSparePartException;
use App\Exception\InsufficientSparePartsQuantityException;
use App\Exception\InterventionDateInvalidException;
use App\Exception\InvalidPersonnelTypeException;
use App\Exception\SparePartFarmMismatchException;
use App\Exception\SparePartNotFoundException;
use App\Exception\TechnicianFarmMismatchException;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\HttpFoundation\RequestStack;
use Vich\UploaderBundle\Handler\UploadHandler;

class CreatePreventiveMaintenanceProcessor implements ProcessorInterface
{
    private ProcessorInterface $processorInterface;
    private RequestStack $requestStack;
    private UploadHandler $uploadHandler;
    private EntityManagerInterface $entityManager;

    public function __construct(EntityManagerInterface $entityManager, ProcessorInterface $processorInterface, RequestStack $requestStack, UploadHandler $uploadHandler)
    {
        $this->entityManager = $entityManager;
        $this->processorInterface = $processorInterface;
        $this->requestStack = $requestStack;
        $this->uploadHandler = $uploadHandler;
    }

    public function process($data, Operation $operation, array $uriVariables = [], array $context = [])
    {
        if (!$data instanceof PreventiveMaintenanceDTO) {
            throw new \InvalidArgumentException('Unexpected type for data');
        }

        $preventiveMaintenance = new PreventiveMaintenance();
        $interventionDate = $data->getInterventionDate();
        if ($interventionDate) {
            $dateTime = new \DateTime($interventionDate);

            // Get the current date without time (today starts from midnight)
            $now = new \DateTime('today');

            // Allow the estimatedInterventionDate to be today or in the future
            if ($dateTime < $now) {
                throw new InterventionDateInvalidException(sprintf('Intervention date cannot be in the past.'));
            } else {
                $preventiveMaintenance->setInterventionDate($dateTime);
            }
        } else {
            $preventiveMaintenance->setInterventionDate(null);
        }
        //$preventiveMaintenance->setInterventionDate($data->getInterventionDate() ? new \DateTime($data->getInterventionDate()) : null);
        $preventiveMaintenance->setInterventionEstimatedDuration((int) $data->getInterventionEstimatedDuration());
        $preventiveMaintenance->setInterventionEstimatedDurationUnit($data->getInterventionEstimatedDurationUnit());
        $preventiveMaintenance->setMaintenanceFrequency($data->getMaintenanceFrequency());
        $preventiveMaintenance->setMaintenanceFrequencyCount((int) $data->getMaintenanceFrequencyCount());
        $preventiveMaintenance->setEquipmentToMaintain($data->getEquipmentToMaintain());
        $preventiveMaintenance->setState("WAITING_FOR_VALIDATION");
        $preventiveMaintenance->setIntervention($data->getIntervention());

        $equipment = $preventiveMaintenance->getEquipmentToMaintain();
        $preventiveMaintenance->setEquipmentName($equipment->getName());
        $equipmentFarm = $equipment->getFarm();

        $existingSpareParts = [];

        foreach ($data->getSparePartPreventiveMaintenanceQuantities() as $sparePartQuantity) {
            $sparePartUri = $sparePartQuantity->getSparePart()->getId();

            /** @var SparePart $sparePart */
            $sparePart = $this->entityManager->getRepository(SparePart::class)->find($sparePartUri);

            if (!$sparePart) {
                throw new SparePartNotFoundException('Spare part not found for id ' . $sparePartUri);
            }

            if ($sparePart->getFarm() !== $equipmentFarm) {
                throw new SparePartFarmMismatchException(sprintf('Spare part %s does not belong to the same farm as the equipment.', $sparePart->getName()));
            }

            if (in_array($sparePartUri, $existingSpareParts)) {
                throw new DuplicateSparePartException(sprintf('Duplicate spare part: %s has already been added.', $sparePart->getName()));
            }

            $existingSpareParts[] = $sparePartUri;

            $quantityNeeded = $sparePartQuantity->getQuantity();
            $currentQuantity = $sparePart->getQuantity();

            if ($currentQuantity < $quantityNeeded) {
                throw new InsufficientSparePartsQuantityException(sprintf('Insufficient quantity of %s available.', $sparePart->getName()));
            }
            $sparePart->setQuantity($currentQuantity - $quantityNeeded);

            $sparePartPreventiveMaintenanceQuantity = new SparePartPreventiveMaintenanceQuantity();
            $sparePartPreventiveMaintenanceQuantity->setSparePart($sparePart);
            $sparePartPreventiveMaintenanceQuantity->setQuantity($quantityNeeded);
            $sparePartPreventiveMaintenanceQuantity->setPreventiveMaintenance($preventiveMaintenance);

            $preventiveMaintenance->addSparePartPreventiveMaintenanceQuantity($sparePartPreventiveMaintenanceQuantity);
        }

        $personnelInCharge = $data->getPersonnelInCharge();
        foreach ($personnelInCharge as $person) {
            if ($person->getType() !== 'technician') {
                throw new InvalidPersonnelTypeException(sprintf('Personnel in charge must be of type technician.'));
            }
            if ($person->getFarm() !== $equipmentFarm) {
                throw new TechnicianFarmMismatchException(sprintf('Technician %s %s does not belong to the same farm as the equipment.', $person->getFirstName(), $person->getLastName()));
            }
            $preventiveMaintenance->addPersonnelInCharge($person);
        }

        $this->processorInterface->process($preventiveMaintenance, $operation, $uriVariables, $context);

        $request = $this->requestStack->getCurrentRequest();
        $files = $request->files->get('imageFiles');

        if ($files && is_array($files)) {
            foreach ($files as $file) {
                if ($file instanceof UploadedFile && strpos($file->getMimeType(), 'image/') === 0) {
                    $pmImage = new PreventiveMaintenanceImage();
                    $pmImage->setImageFile($file);
                    $this->uploadHandler->upload($pmImage, 'imageFile');
                    $preventiveMaintenance->addImage($pmImage);

                    $this->entityManager->persist($pmImage);
                } else {
                    throw new \Exception('Uploaded file is not an image.');
                }
            }

            $this->entityManager->flush();
        }

        return $preventiveMaintenance;
    }
}
