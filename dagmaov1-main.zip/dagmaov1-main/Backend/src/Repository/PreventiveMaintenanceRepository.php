<?php

namespace App\Repository;

use App\Entity\PreventiveMaintenance;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<PreventiveMaintenance>
 */
class PreventiveMaintenanceRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, PreventiveMaintenance::class);
    }

    public function countPreventiveMaintenancesByState(array $farmIds, string $state): array
    {
        $qb = $this->createQueryBuilder('p')
            ->select('COUNT(p.id) as count')
            ->join('p.equipmentToMaintain', 'e')
            ->join('e.farm', 'f')
            ->where('f.id IN (:farmIds)')
            ->andWhere('p.state = :state')
            ->setParameter('farmIds', $farmIds)
            ->setParameter('state', $state);
        $count = (int) $qb->getQuery()->getSingleScalarResult();
        return [
            [
                'state' => $state,
                'count' => $count
            ]
        ];
    }
    public function countPreventiveMaintenancesByFarmIds(array $farmIds): array
    {
        // Define the states directly
        $states = ["PLANNED", "IN_PROGRESS", "COMPLETED", "NON_VALIDATED", "WAITING_FOR_VALIDATION"];

        $qb = $this->createQueryBuilder('p')
            ->select('p.state, COUNT(p.id) as count')
            ->join('p.equipmentToMaintain', 'e')
            ->join('e.farm', 'f')
            ->where('f.id IN (:farmIds)')
            ->andWhere('p.state IN (:states)')
            ->setParameter('farmIds', $farmIds)
            ->setParameter('states', $states)
            ->groupBy('p.state');

        $results = $qb->getQuery()->getArrayResult();

        // Reformat the results to match the previous format
        $formattedResults = [];
        foreach ($results as $result) {
            $formattedResults[] = [
                'state' => $result['state'],
                'count' => (int) $result['count'],
            ];
        }

        return $formattedResults;
    }
}
