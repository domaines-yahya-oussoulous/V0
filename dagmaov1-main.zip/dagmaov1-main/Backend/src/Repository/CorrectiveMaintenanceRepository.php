<?php

namespace App\Repository;

use App\Entity\CorrectiveMaintenance;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<CorrectiveMaintenance>
 */
class CorrectiveMaintenanceRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, CorrectiveMaintenance::class);
    }

    public function countCorrectiveMaintenancesByState(array $farmIds, string $state): array
    {
        $qb = $this->createQueryBuilder('c')
            ->select('COUNT(c.id) as count')
            ->join('c.equipmentToMaintain', 'e')
            ->join('e.farm', 'f')
            ->where('f.id IN (:farmIds)')
            ->andWhere('c.state = :state')
            ->setParameter('farmIds', $farmIds)
            ->setParameter('state', $state);
        $count = (int) $qb->getQuery()->getSingleScalarResult();
        return [
                [
                    'state' => $state,
                    'count' => $count
                ]
            ];
    }
    public function countCorrectiveMaintenancesByFarmIds(array $farmIds): array
    {
        // Define the states directly
        $states = ["PLANNED", "IN_PROGRESS", "COMPLETED", "NON_VALIDATED", "WAITING_FOR_VALIDATION"];

        $qb = $this->createQueryBuilder('c')
            ->select('c.state, COUNT(c.id) as count')
            ->join('c.equipmentToMaintain', 'e')
            ->join('e.farm', 'f')
            ->where('f.id IN (:farmIds)')
            ->andWhere('c.state IN (:states)')
            ->setParameter('farmIds', $farmIds)
            ->setParameter('states', $states)
            ->groupBy('c.state');

        $results = $qb->getQuery()->getArrayResult();

        // Reformat the results to match the previous format
        $formattedResults = [];
        foreach ($results as $result) {
            $formattedResults[] = [
                'state' => $result['state'],
                'count' => (int) $result['count'],
            ];
        }

        return $formattedResults;
    }
}
