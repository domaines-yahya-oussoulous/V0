<?php

namespace App\Repository;

use App\Entity\EquipmentCategory;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<EquipmentCategory>
 */
class EquipmentCategoryRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, EquipmentCategory::class);
    }

    public function countEquipmentByCategory(): array
    {
        $qb = $this->createQueryBuilder('ec')  // 'ec' for EquipmentCategory
        ->select('ec.name AS categoryName, COUNT(e.id) AS equipmentCount')
            ->leftJoin('ec.equipment', 'e')  // Join from EquipmentCategory to Equipment
            ->groupBy('ec.id');  // Group by EquipmentCategory id to ensure unique categories

        return $qb->getQuery()->getArrayResult();
    }
    public function getMaintenanceRatioByFarm($farmId)
    {
        $dql = "
    SELECT 
        ec.id AS categoryId, 
        ec.name AS categoryName, 
        ec.image AS categoryImage, 
        COUNT(DISTINCT e.id) AS totalEquipments,
        SUM(CASE 
            WHEN cm.id IS NOT NULL 
            AND cm.state NOT IN ('WAITING_FOR_VALIDATION', 'NON_VALIDATED', 'COMPLETED') 
            THEN 1 
            ELSE 0 
        END) AS equipmentsInMaintenance,
        (COUNT(DISTINCT e.id) - SUM(CASE 
            WHEN cm.id IS NOT NULL 
            AND cm.state NOT IN ('WAITING_FOR_VALIDATION', 'NON_VALIDATED', 'COMPLETED') 
            THEN 1 
            ELSE 0 
        END)) AS availableEquipments
    FROM App\Entity\EquipmentCategory ec
    LEFT JOIN ec.equipment e
    LEFT JOIN e.correctiveMaintenances cm
    WHERE e.farm = :farmId
    GROUP BY ec.id, ec.name
    ";

        $query = $this->getEntityManager()->createQuery($dql);
        $query->setParameter('farmId', $farmId);

        return $query->getResult();
    }
    public function getMaintenanceRatioByFarms(array $farmIds)
    {
        $dql = "
    SELECT 
        ec.id AS categoryId, 
        ec.name AS categoryName, 
        ec.image AS categoryImage, 
        COUNT(DISTINCT e.id) AS totalEquipments,
        SUM(CASE 
            WHEN cm.id IS NOT NULL 
            AND cm.state NOT IN ('WAITING_FOR_VALIDATION', 'NON_VALIDATED', 'COMPLETED') 
            THEN 1 
            ELSE 0 
        END) AS equipmentsInMaintenance,
        (COUNT(DISTINCT e.id) - SUM(CASE 
            WHEN cm.id IS NOT NULL 
            AND cm.state NOT IN ('WAITING_FOR_VALIDATION', 'NON_VALIDATED', 'COMPLETED') 
            THEN 1 
            ELSE 0 
        END)) AS availableEquipments
    FROM App\Entity\EquipmentCategory ec
    LEFT JOIN ec.equipment e
    LEFT JOIN e.correctiveMaintenances cm
    WHERE e.farm IN (:farmIds)
    GROUP BY ec.id, ec.name
    ";

        $query = $this->getEntityManager()->createQuery($dql);
        $query->setParameter('farmIds', $farmIds);

        return $query->getResult();
    }

}
