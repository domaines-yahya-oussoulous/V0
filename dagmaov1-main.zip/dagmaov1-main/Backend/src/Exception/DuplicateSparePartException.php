<?php

namespace App\Exception;

class DuplicateSparePartException extends \InvalidArgumentException
{
}
