<?php
namespace App\Exception;

final class SparePartFarmMismatchException extends \Exception
{

}