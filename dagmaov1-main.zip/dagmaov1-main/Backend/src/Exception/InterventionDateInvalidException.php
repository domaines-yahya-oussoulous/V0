<?php
namespace App\Exception;

final class InterventionDateInvalidException extends \InvalidArgumentException
{
}
