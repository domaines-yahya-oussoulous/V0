<?php

namespace App\Exception;

final class InvalidPersonnelTypeException extends \Exception
{

}
