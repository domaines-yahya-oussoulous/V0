<?php

namespace App\Exception;

final class InsufficientSparePartsQuantityException extends \Exception
{
}