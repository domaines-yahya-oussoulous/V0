<?php

namespace App\Exception;

final class TechnicianFarmMismatchException extends \Exception
{

}
