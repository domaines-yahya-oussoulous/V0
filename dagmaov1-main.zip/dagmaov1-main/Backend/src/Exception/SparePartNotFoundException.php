<?php

namespace App\Exception;

final class SparePartNotFoundException extends \InvalidArgumentException
{

}
