<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240825111536 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE corrective_maintenance_operation (corrective_maintenance_id INT NOT NULL, operation_id INT NOT NULL, INDEX IDX_48711AB75FBA4BBB (corrective_maintenance_id), INDEX IDX_48711AB744AC3583 (operation_id), PRIMARY KEY(corrective_maintenance_id, operation_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE corrective_maintenance_operation ADD CONSTRAINT FK_48711AB75FBA4BBB FOREIGN KEY (corrective_maintenance_id) REFERENCES corrective_maintenance (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE corrective_maintenance_operation ADD CONSTRAINT FK_48711AB744AC3583 FOREIGN KEY (operation_id) REFERENCES operation (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE corrective_maintenance ADD intervention_id INT NOT NULL');
        $this->addSql('ALTER TABLE corrective_maintenance ADD CONSTRAINT FK_E202D5398EAE3863 FOREIGN KEY (intervention_id) REFERENCES intervention (id)');
        $this->addSql('CREATE INDEX IDX_E202D5398EAE3863 ON corrective_maintenance (intervention_id)');
        $this->addSql('ALTER TABLE equipment CHANGE maintenance_range_size maintenance_range_size VARCHAR(255) DEFAULT NULL');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE corrective_maintenance_operation DROP FOREIGN KEY FK_48711AB75FBA4BBB');
        $this->addSql('ALTER TABLE corrective_maintenance_operation DROP FOREIGN KEY FK_48711AB744AC3583');
        $this->addSql('DROP TABLE corrective_maintenance_operation');
        $this->addSql('ALTER TABLE corrective_maintenance DROP FOREIGN KEY FK_E202D5398EAE3863');
        $this->addSql('DROP INDEX IDX_E202D5398EAE3863 ON corrective_maintenance');
        $this->addSql('ALTER TABLE corrective_maintenance DROP intervention_id');
        $this->addSql('ALTER TABLE equipment CHANGE maintenance_range_size maintenance_range_size INT DEFAULT NULL');
    }
}
