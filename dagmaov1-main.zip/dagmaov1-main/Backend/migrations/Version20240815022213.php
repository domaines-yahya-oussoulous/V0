<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240815022213 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE city (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE corrective_maintenance (id INT AUTO_INCREMENT NOT NULL, equipment_to_maintain_id INT DEFAULT NULL, equipment_name VARCHAR(255) DEFAULT NULL, failure_type VARCHAR(255) DEFAULT NULL, failure_description LONGTEXT DEFAULT NULL, breakdown_time DATETIME DEFAULT NULL, breakdown_site VARCHAR(255) DEFAULT NULL, estimated_down_time INT DEFAULT NULL, estimated_down_time_unit VARCHAR(255) DEFAULT NULL, breakdown_probable_cause VARCHAR(255) DEFAULT NULL, urgency_level VARCHAR(255) DEFAULT NULL, intervention_estimated_duration INT DEFAULT NULL, intervention_estimated_duration_unit VARCHAR(255) DEFAULT NULL, intervention_date DATETIME DEFAULT NULL, personnel_type VARCHAR(255) DEFAULT NULL, state VARCHAR(255) DEFAULT NULL, created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX IDX_E202D539D844B60 (equipment_to_maintain_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE corrective_maintenance_spare_part (corrective_maintenance_id INT NOT NULL, spare_part_id INT NOT NULL, INDEX IDX_858756405FBA4BBB (corrective_maintenance_id), INDEX IDX_8587564049B7A72 (spare_part_id), PRIMARY KEY(corrective_maintenance_id, spare_part_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE corrective_maintenance_user (corrective_maintenance_id INT NOT NULL, user_id INT NOT NULL, INDEX IDX_2C1700E5FBA4BBB (corrective_maintenance_id), INDEX IDX_2C1700EA76ED395 (user_id), PRIMARY KEY(corrective_maintenance_id, user_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE corrective_maintenance_image (id INT AUTO_INCREMENT NOT NULL, corrective_maintenance_id INT DEFAULT NULL, image_name VARCHAR(255) DEFAULT NULL, INDEX IDX_2D0A82CA5FBA4BBB (corrective_maintenance_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE equipment (id INT AUTO_INCREMENT NOT NULL, farm_id INT DEFAULT NULL, equipment_category_id INT DEFAULT NULL, name VARCHAR(255) DEFAULT NULL, category_name VARCHAR(255) DEFAULT NULL, reference VARCHAR(255) DEFAULT NULL, inventory_code VARCHAR(255) DEFAULT NULL, image VARCHAR(255) DEFAULT NULL, image_size INT DEFAULT NULL, qr_code VARCHAR(255) DEFAULT NULL, family VARCHAR(255) DEFAULT NULL, brand VARCHAR(255) DEFAULT NULL, acquisition_date DATETIME DEFAULT NULL, acquisition_cost DOUBLE PRECISION DEFAULT NULL, under_warranty TINYINT(1) DEFAULT NULL, gps_data JSON DEFAULT NULL COMMENT \'(DC2Type:json)\', original_domain VARCHAR(255) DEFAULT NULL, counting_unit VARCHAR(255) DEFAULT NULL, counter DOUBLE PRECISION DEFAULT NULL, use_hours_number DOUBLE PRECISION DEFAULT NULL, last_maintenance_date DATETIME DEFAULT NULL, next_maintenance_date DATETIME DEFAULT NULL, last_breakdown_date DATETIME DEFAULT NULL, last_breakdown_cause VARCHAR(255) DEFAULT NULL, technical_specification LONGTEXT DEFAULT NULL, created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', deleted_at DATETIME DEFAULT NULL, INDEX IDX_D338D58365FCFA0D (farm_id), INDEX IDX_D338D583730469C5 (equipment_category_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE equipment_category (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) DEFAULT NULL, image VARCHAR(255) DEFAULT NULL, image_size INT DEFAULT NULL, description LONGTEXT DEFAULT NULL, created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE farm (id INT AUTO_INCREMENT NOT NULL, city_id INT DEFAULT NULL, name VARCHAR(255) DEFAULT NULL, reference VARCHAR(255) DEFAULT NULL, city_name VARCHAR(255) NOT NULL, location VARCHAR(255) DEFAULT NULL, created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX IDX_5816D0458BAC62AF (city_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE intervention (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE intervention_equipment_category (intervention_id INT NOT NULL, equipment_category_id INT NOT NULL, INDEX IDX_6EAD06BD8EAE3863 (intervention_id), INDEX IDX_6EAD06BD730469C5 (equipment_category_id), PRIMARY KEY(intervention_id, equipment_category_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE operation (id INT AUTO_INCREMENT NOT NULL, intervention_id INT NOT NULL, description LONGTEXT NOT NULL, INDEX IDX_1981A66D8EAE3863 (intervention_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE preventive_maintenance (id INT AUTO_INCREMENT NOT NULL, equipment_to_maintain_id INT DEFAULT NULL, intervention_id INT NOT NULL, equipment_name VARCHAR(255) DEFAULT NULL, intervention_date DATETIME DEFAULT NULL, intervention_estimated_duration INT DEFAULT NULL, intervention_estimated_duration_unit VARCHAR(255) DEFAULT NULL, maintenance_frequency VARCHAR(255) DEFAULT NULL, maintenance_frequency_count INT DEFAULT NULL, state VARCHAR(255) DEFAULT NULL, tasks_description LONGTEXT DEFAULT NULL, completion_date DATETIME DEFAULT NULL, created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX IDX_6BEC0DC1D844B60 (equipment_to_maintain_id), INDEX IDX_6BEC0DC18EAE3863 (intervention_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE preventive_maintenance_spare_part (preventive_maintenance_id INT NOT NULL, spare_part_id INT NOT NULL, INDEX IDX_44C1DB5CEA3EE932 (preventive_maintenance_id), INDEX IDX_44C1DB5C49B7A72 (spare_part_id), PRIMARY KEY(preventive_maintenance_id, spare_part_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE preventive_maintenance_user (preventive_maintenance_id INT NOT NULL, user_id INT NOT NULL, INDEX IDX_D058244CEA3EE932 (preventive_maintenance_id), INDEX IDX_D058244CA76ED395 (user_id), PRIMARY KEY(preventive_maintenance_id, user_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE preventive_maintenance_operation (preventive_maintenance_id INT NOT NULL, operation_id INT NOT NULL, INDEX IDX_6FE1AD89EA3EE932 (preventive_maintenance_id), INDEX IDX_6FE1AD8944AC3583 (operation_id), PRIMARY KEY(preventive_maintenance_id, operation_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE preventive_maintenance_image (id INT AUTO_INCREMENT NOT NULL, preventive_maintenance_id INT DEFAULT NULL, image_name VARCHAR(255) DEFAULT NULL, INDEX IDX_B50A3B22EA3EE932 (preventive_maintenance_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE refresh_tokens (id INT AUTO_INCREMENT NOT NULL, refresh_token VARCHAR(128) NOT NULL, username VARCHAR(255) NOT NULL, valid DATETIME NOT NULL, UNIQUE INDEX UNIQ_9BACE7E1C74F2195 (refresh_token), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE spare_part (id INT AUTO_INCREMENT NOT NULL, farm_id INT DEFAULT NULL, spare_part_category_id INT DEFAULT NULL, name VARCHAR(255) DEFAULT NULL, category_name VARCHAR(255) DEFAULT NULL, reference VARCHAR(255) DEFAULT NULL, inventory_code VARCHAR(255) DEFAULT NULL, image VARCHAR(255) DEFAULT NULL, image_size INT DEFAULT NULL, brand VARCHAR(255) DEFAULT NULL, units_number INT DEFAULT NULL, unit_price DOUBLE PRECISION DEFAULT NULL, availability TINYINT(1) DEFAULT NULL, quantity INT DEFAULT NULL, order_duration DOUBLE PRECISION DEFAULT NULL, last_inventory_date DATETIME DEFAULT NULL, created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX IDX_E3D09D3665FCFA0D (farm_id), INDEX IDX_E3D09D36F9C632CC (spare_part_category_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE spare_part_equipment (spare_part_id INT NOT NULL, equipment_id INT NOT NULL, INDEX IDX_F4C6E91E49B7A72 (spare_part_id), INDEX IDX_F4C6E91E517FE9FE (equipment_id), PRIMARY KEY(spare_part_id, equipment_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE spare_part_category (id INT AUTO_INCREMENT NOT NULL, name VARCHAR(255) DEFAULT NULL, image VARCHAR(255) DEFAULT NULL, image_size INT DEFAULT NULL, description LONGTEXT DEFAULT NULL, created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE spare_part_corrective_maintenance_quantity (id INT AUTO_INCREMENT NOT NULL, corrective_maintenance_id INT DEFAULT NULL, spare_part_id INT DEFAULT NULL, quantity INT DEFAULT NULL, INDEX IDX_9FC9BB9C5FBA4BBB (corrective_maintenance_id), INDEX IDX_9FC9BB9C49B7A72 (spare_part_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE spare_part_preventive_maintenance_quantity (id INT AUTO_INCREMENT NOT NULL, preventive_maintenance_id INT DEFAULT NULL, spare_part_id INT DEFAULT NULL, quantity INT DEFAULT NULL, INDEX IDX_D3F2FEDEA3EE932 (preventive_maintenance_id), INDEX IDX_D3F2FED49B7A72 (spare_part_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE user (id INT AUTO_INCREMENT NOT NULL, farm_id INT DEFAULT NULL, email VARCHAR(180) NOT NULL, roles JSON NOT NULL COMMENT \'(DC2Type:json)\', password VARCHAR(255) NOT NULL, first_name VARCHAR(255) DEFAULT NULL, last_name VARCHAR(255) DEFAULT NULL, type VARCHAR(255) NOT NULL, created_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', updated_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX IDX_8D93D64965FCFA0D (farm_id), UNIQUE INDEX UNIQ_IDENTIFIER_EMAIL (email), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE messenger_messages (id BIGINT AUTO_INCREMENT NOT NULL, body LONGTEXT NOT NULL, headers LONGTEXT NOT NULL, queue_name VARCHAR(190) NOT NULL, created_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', available_at DATETIME NOT NULL COMMENT \'(DC2Type:datetime_immutable)\', delivered_at DATETIME DEFAULT NULL COMMENT \'(DC2Type:datetime_immutable)\', INDEX IDX_75EA56E0FB7336F0 (queue_name), INDEX IDX_75EA56E0E3BD61CE (available_at), INDEX IDX_75EA56E016BA31DB (delivered_at), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE corrective_maintenance ADD CONSTRAINT FK_E202D539D844B60 FOREIGN KEY (equipment_to_maintain_id) REFERENCES equipment (id)');
        $this->addSql('ALTER TABLE corrective_maintenance_spare_part ADD CONSTRAINT FK_858756405FBA4BBB FOREIGN KEY (corrective_maintenance_id) REFERENCES corrective_maintenance (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE corrective_maintenance_spare_part ADD CONSTRAINT FK_8587564049B7A72 FOREIGN KEY (spare_part_id) REFERENCES spare_part (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE corrective_maintenance_user ADD CONSTRAINT FK_2C1700E5FBA4BBB FOREIGN KEY (corrective_maintenance_id) REFERENCES corrective_maintenance (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE corrective_maintenance_user ADD CONSTRAINT FK_2C1700EA76ED395 FOREIGN KEY (user_id) REFERENCES user (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE corrective_maintenance_image ADD CONSTRAINT FK_2D0A82CA5FBA4BBB FOREIGN KEY (corrective_maintenance_id) REFERENCES corrective_maintenance (id)');
        $this->addSql('ALTER TABLE equipment ADD CONSTRAINT FK_D338D58365FCFA0D FOREIGN KEY (farm_id) REFERENCES farm (id)');
        $this->addSql('ALTER TABLE equipment ADD CONSTRAINT FK_D338D583730469C5 FOREIGN KEY (equipment_category_id) REFERENCES equipment_category (id)');
        $this->addSql('ALTER TABLE farm ADD CONSTRAINT FK_5816D0458BAC62AF FOREIGN KEY (city_id) REFERENCES city (id)');
        $this->addSql('ALTER TABLE intervention_equipment_category ADD CONSTRAINT FK_6EAD06BD8EAE3863 FOREIGN KEY (intervention_id) REFERENCES intervention (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE intervention_equipment_category ADD CONSTRAINT FK_6EAD06BD730469C5 FOREIGN KEY (equipment_category_id) REFERENCES equipment_category (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE operation ADD CONSTRAINT FK_1981A66D8EAE3863 FOREIGN KEY (intervention_id) REFERENCES intervention (id)');
        $this->addSql('ALTER TABLE preventive_maintenance ADD CONSTRAINT FK_6BEC0DC1D844B60 FOREIGN KEY (equipment_to_maintain_id) REFERENCES equipment (id)');
        $this->addSql('ALTER TABLE preventive_maintenance ADD CONSTRAINT FK_6BEC0DC18EAE3863 FOREIGN KEY (intervention_id) REFERENCES intervention (id)');
        $this->addSql('ALTER TABLE preventive_maintenance_spare_part ADD CONSTRAINT FK_44C1DB5CEA3EE932 FOREIGN KEY (preventive_maintenance_id) REFERENCES preventive_maintenance (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE preventive_maintenance_spare_part ADD CONSTRAINT FK_44C1DB5C49B7A72 FOREIGN KEY (spare_part_id) REFERENCES spare_part (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE preventive_maintenance_user ADD CONSTRAINT FK_D058244CEA3EE932 FOREIGN KEY (preventive_maintenance_id) REFERENCES preventive_maintenance (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE preventive_maintenance_user ADD CONSTRAINT FK_D058244CA76ED395 FOREIGN KEY (user_id) REFERENCES user (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE preventive_maintenance_operation ADD CONSTRAINT FK_6FE1AD89EA3EE932 FOREIGN KEY (preventive_maintenance_id) REFERENCES preventive_maintenance (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE preventive_maintenance_operation ADD CONSTRAINT FK_6FE1AD8944AC3583 FOREIGN KEY (operation_id) REFERENCES operation (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE preventive_maintenance_image ADD CONSTRAINT FK_B50A3B22EA3EE932 FOREIGN KEY (preventive_maintenance_id) REFERENCES preventive_maintenance (id)');
        $this->addSql('ALTER TABLE spare_part ADD CONSTRAINT FK_E3D09D3665FCFA0D FOREIGN KEY (farm_id) REFERENCES farm (id)');
        $this->addSql('ALTER TABLE spare_part ADD CONSTRAINT FK_E3D09D36F9C632CC FOREIGN KEY (spare_part_category_id) REFERENCES spare_part_category (id)');
        $this->addSql('ALTER TABLE spare_part_equipment ADD CONSTRAINT FK_F4C6E91E49B7A72 FOREIGN KEY (spare_part_id) REFERENCES spare_part (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE spare_part_equipment ADD CONSTRAINT FK_F4C6E91E517FE9FE FOREIGN KEY (equipment_id) REFERENCES equipment (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE spare_part_corrective_maintenance_quantity ADD CONSTRAINT FK_9FC9BB9C5FBA4BBB FOREIGN KEY (corrective_maintenance_id) REFERENCES corrective_maintenance (id)');
        $this->addSql('ALTER TABLE spare_part_corrective_maintenance_quantity ADD CONSTRAINT FK_9FC9BB9C49B7A72 FOREIGN KEY (spare_part_id) REFERENCES spare_part (id)');
        $this->addSql('ALTER TABLE spare_part_preventive_maintenance_quantity ADD CONSTRAINT FK_D3F2FEDEA3EE932 FOREIGN KEY (preventive_maintenance_id) REFERENCES preventive_maintenance (id)');
        $this->addSql('ALTER TABLE spare_part_preventive_maintenance_quantity ADD CONSTRAINT FK_D3F2FED49B7A72 FOREIGN KEY (spare_part_id) REFERENCES spare_part (id)');
        $this->addSql('ALTER TABLE user ADD CONSTRAINT FK_8D93D64965FCFA0D FOREIGN KEY (farm_id) REFERENCES farm (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE corrective_maintenance DROP FOREIGN KEY FK_E202D539D844B60');
        $this->addSql('ALTER TABLE corrective_maintenance_spare_part DROP FOREIGN KEY FK_858756405FBA4BBB');
        $this->addSql('ALTER TABLE corrective_maintenance_spare_part DROP FOREIGN KEY FK_8587564049B7A72');
        $this->addSql('ALTER TABLE corrective_maintenance_user DROP FOREIGN KEY FK_2C1700E5FBA4BBB');
        $this->addSql('ALTER TABLE corrective_maintenance_user DROP FOREIGN KEY FK_2C1700EA76ED395');
        $this->addSql('ALTER TABLE corrective_maintenance_image DROP FOREIGN KEY FK_2D0A82CA5FBA4BBB');
        $this->addSql('ALTER TABLE equipment DROP FOREIGN KEY FK_D338D58365FCFA0D');
        $this->addSql('ALTER TABLE equipment DROP FOREIGN KEY FK_D338D583730469C5');
        $this->addSql('ALTER TABLE farm DROP FOREIGN KEY FK_5816D0458BAC62AF');
        $this->addSql('ALTER TABLE intervention_equipment_category DROP FOREIGN KEY FK_6EAD06BD8EAE3863');
        $this->addSql('ALTER TABLE intervention_equipment_category DROP FOREIGN KEY FK_6EAD06BD730469C5');
        $this->addSql('ALTER TABLE operation DROP FOREIGN KEY FK_1981A66D8EAE3863');
        $this->addSql('ALTER TABLE preventive_maintenance DROP FOREIGN KEY FK_6BEC0DC1D844B60');
        $this->addSql('ALTER TABLE preventive_maintenance DROP FOREIGN KEY FK_6BEC0DC18EAE3863');
        $this->addSql('ALTER TABLE preventive_maintenance_spare_part DROP FOREIGN KEY FK_44C1DB5CEA3EE932');
        $this->addSql('ALTER TABLE preventive_maintenance_spare_part DROP FOREIGN KEY FK_44C1DB5C49B7A72');
        $this->addSql('ALTER TABLE preventive_maintenance_user DROP FOREIGN KEY FK_D058244CEA3EE932');
        $this->addSql('ALTER TABLE preventive_maintenance_user DROP FOREIGN KEY FK_D058244CA76ED395');
        $this->addSql('ALTER TABLE preventive_maintenance_operation DROP FOREIGN KEY FK_6FE1AD89EA3EE932');
        $this->addSql('ALTER TABLE preventive_maintenance_operation DROP FOREIGN KEY FK_6FE1AD8944AC3583');
        $this->addSql('ALTER TABLE preventive_maintenance_image DROP FOREIGN KEY FK_B50A3B22EA3EE932');
        $this->addSql('ALTER TABLE spare_part DROP FOREIGN KEY FK_E3D09D3665FCFA0D');
        $this->addSql('ALTER TABLE spare_part DROP FOREIGN KEY FK_E3D09D36F9C632CC');
        $this->addSql('ALTER TABLE spare_part_equipment DROP FOREIGN KEY FK_F4C6E91E49B7A72');
        $this->addSql('ALTER TABLE spare_part_equipment DROP FOREIGN KEY FK_F4C6E91E517FE9FE');
        $this->addSql('ALTER TABLE spare_part_corrective_maintenance_quantity DROP FOREIGN KEY FK_9FC9BB9C5FBA4BBB');
        $this->addSql('ALTER TABLE spare_part_corrective_maintenance_quantity DROP FOREIGN KEY FK_9FC9BB9C49B7A72');
        $this->addSql('ALTER TABLE spare_part_preventive_maintenance_quantity DROP FOREIGN KEY FK_D3F2FEDEA3EE932');
        $this->addSql('ALTER TABLE spare_part_preventive_maintenance_quantity DROP FOREIGN KEY FK_D3F2FED49B7A72');
        $this->addSql('ALTER TABLE user DROP FOREIGN KEY FK_8D93D64965FCFA0D');
        $this->addSql('DROP TABLE city');
        $this->addSql('DROP TABLE corrective_maintenance');
        $this->addSql('DROP TABLE corrective_maintenance_spare_part');
        $this->addSql('DROP TABLE corrective_maintenance_user');
        $this->addSql('DROP TABLE corrective_maintenance_image');
        $this->addSql('DROP TABLE equipment');
        $this->addSql('DROP TABLE equipment_category');
        $this->addSql('DROP TABLE farm');
        $this->addSql('DROP TABLE intervention');
        $this->addSql('DROP TABLE intervention_equipment_category');
        $this->addSql('DROP TABLE operation');
        $this->addSql('DROP TABLE preventive_maintenance');
        $this->addSql('DROP TABLE preventive_maintenance_spare_part');
        $this->addSql('DROP TABLE preventive_maintenance_user');
        $this->addSql('DROP TABLE preventive_maintenance_operation');
        $this->addSql('DROP TABLE preventive_maintenance_image');
        $this->addSql('DROP TABLE refresh_tokens');
        $this->addSql('DROP TABLE spare_part');
        $this->addSql('DROP TABLE spare_part_equipment');
        $this->addSql('DROP TABLE spare_part_category');
        $this->addSql('DROP TABLE spare_part_corrective_maintenance_quantity');
        $this->addSql('DROP TABLE spare_part_preventive_maintenance_quantity');
        $this->addSql('DROP TABLE user');
        $this->addSql('DROP TABLE messenger_messages');
    }
}
