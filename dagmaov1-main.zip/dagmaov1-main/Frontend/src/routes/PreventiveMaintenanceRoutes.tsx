
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import PreventiveMaintenancePage from "@/pages/PreventiveMaintenancePage.tsx";
import PreventiveMaintenanceAdd from "@/features/preventive-maintenance/PreventiveMaintenanceAdd.tsx";
import PreventiveMaintenanceShow from "@/features/preventive-maintenance/PreventiveMaintenanceShow.tsx";



const PreventiveMaintenanceRoutes: React.FC = () => {
    return (
        <Routes>
            <Route path='/' element={<PreventiveMaintenancePage />} />
            <Route path='/add' element={<PreventiveMaintenanceAdd />} />
            <Route path='/:id' element={<PreventiveMaintenanceShow />} />
        </Routes>
    );
};

export default PreventiveMaintenanceRoutes;
