
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import SparepartsPage from "@/pages/SparepartsPage.tsx";
import SparepartsAdd from "@/features/spareparts/SparepartsAdd.tsx";
import SparepartsShow from "@/features/spareparts/SparepartsShow.tsx";
import SparepartsEdit from "@/features/spareparts/SparepartsEdit.tsx";
import SparePartsCategoryPage from "@/pages/SparePartsCategoryPage.tsx";
import SparePartsCategoryAdd from "@/features/spareparts/category/SparepartsCategoryAdd.tsx";
import SparepartsCategoryEdit from "@/features/spareparts/category/SparepartsCategoryEdit.tsx";
import SparePartsCategoryShow from "@/features/spareparts/category/SparepartsCategoryShow.tsx";


const EquipmentRoutes: React.FC = () => {
    return (
        <Routes>
            <Route path='/' element={<SparepartsPage />} />
            <Route path='/add' element={<SparepartsAdd />} />
            <Route path='/:id/edit' element={<SparepartsEdit />} />
            <Route path='/:id' element={<SparepartsShow />} />
            <Route path='/category' element={<SparePartsCategoryPage />} />
            <Route path='/category/add' element={<SparePartsCategoryAdd />} />
            <Route path='category/:id/edit' element={<SparepartsCategoryEdit />} />
            <Route path='category/:id/show' element={<SparePartsCategoryShow/>} />
        </Routes>
    );
};

export default EquipmentRoutes;
