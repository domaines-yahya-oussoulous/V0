import React from 'react';
import { Route, Routes } from 'react-router-dom';
import CityPage from "@/pages/CityPage.tsx";
import CityAdd from "@/features/city/CityAdd.tsx";



const CityRoutes: React.FC = () => {
    return (
        <Routes>
            <Route path='/' element={<CityPage />} />
            <Route path='/add' element={<CityAdd />} />
            {/*}
            <Route path='/' element={<CorrectiveMaintenancePage />} />
            <Route path='/:id' element={<CorrectiveMaintenanceShow />} />
            */}
        </Routes>
    );
};

export default CityRoutes;
