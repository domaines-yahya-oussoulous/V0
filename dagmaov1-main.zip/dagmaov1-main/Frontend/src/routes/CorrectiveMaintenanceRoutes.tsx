
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import CorrectiveMaintenancePage from "@/pages/CorrectiveMaintenancePage.tsx";
import CorrectiveMaintenanceAdd from "@/features/corrective-maintenance/CorrectiveMaintenanceAdd.tsx";
import CorrectiveMaintenanceShow from "@/features/corrective-maintenance/CorrectiveMaintenanceShow.tsx";



const CorrectiveMaintenanceRoutes: React.FC = () => {
    return (
        <Routes>
            <Route path='/' element={<CorrectiveMaintenancePage />} />

            <Route path='/add' element={<CorrectiveMaintenanceAdd />} />

            <Route path='/:id' element={<CorrectiveMaintenanceShow />} />
        </Routes>
    );
};

export default CorrectiveMaintenanceRoutes;
