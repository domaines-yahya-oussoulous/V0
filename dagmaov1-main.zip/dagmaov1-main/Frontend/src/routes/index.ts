
import EquipmentRoutes from './EquipmentRoutes.tsx';
import SparepartsRoutes from "@/routes/SparepartsRoutes.tsx";
import PreventiveMaintenanceRoutes from "@/routes/PreventiveMaintenanceRoutes.tsx";
import CorrectiveMaintenanceRoutes from "@/routes/CorrectiveMaintenanceRoutes.tsx";
import CityRoutes from "@/routes/CityRoutes.tsx";
import FarmRoutes from "@/routes/FarmRoutes.tsx";
import UserRoutes from "@/routes/UserRoutes.tsx";
import InterventionRoutes from "@/routes/InterventionRoutes.tsx";
export {  EquipmentRoutes,SparepartsRoutes,PreventiveMaintenanceRoutes,CorrectiveMaintenanceRoutes,CityRoutes,FarmRoutes,UserRoutes,InterventionRoutes };
