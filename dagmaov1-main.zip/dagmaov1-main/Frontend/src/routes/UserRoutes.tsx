
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import UserPage from "@/pages/UserPage.tsx";
import UserAdd from "@/features/user/UserAdd.tsx";



const UserRoutes: React.FC = () => {
    return (
        <Routes>
            <Route path='/' element={<UserPage />} />
            <Route path='/add' element={<UserAdd />} />
        </Routes>
    );
};

export default UserRoutes;
