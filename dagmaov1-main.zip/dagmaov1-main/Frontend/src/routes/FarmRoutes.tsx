
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import FarmPage from "@/pages/FarmPage.tsx";
import FarmAdd from "@/features/farm/FarmAdd.tsx";



const FarmRoutes: React.FC = () => {
    return (
        <Routes>
            <Route path='/' element={<FarmPage />} />
            <Route path='/add' element={<FarmAdd />} />
        </Routes>
    );
};

export default FarmRoutes;
