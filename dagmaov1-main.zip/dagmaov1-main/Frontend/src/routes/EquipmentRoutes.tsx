
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import EquipmentPage from '@/pages/EquipmentPage';
import EquipmentShow from "@/features/equipment/EquipmentShow.tsx";
import EquipmentAdd from "@/features/equipment/EquipmentAdd.tsx";
import EquipmentEdit from "@/features/equipment/EquipmentEdit.tsx";
import EquipmentCategoryPage from "@/pages/EquipmentCategoryPage.tsx";
import EquipmentCategoryAdd from "@/features/equipment/category/EquipmentCategoryAdd.tsx";
import EquipmentCategoryEdit from "@/features/equipment/category/EquipmentCategoryEdit.tsx";
import EquipmentCategoryShow from "@/features/equipment/category/EquipmentCategoryShow.tsx";
import EquipmentCategoryInterventions from "@/features/equipment/category/EquipmentCategoryInterventions.tsx";



const EquipmentRoutes: React.FC = () => {
    return (
        <Routes>
            <Route path='/' element={<EquipmentPage />} />
            <Route path='/add' element={<EquipmentAdd />} />
            <Route path='/:id/edit' element={<EquipmentEdit />} />
            <Route path='/:id' element={<EquipmentShow />} />
            <Route path='/category' element={<EquipmentCategoryPage />} />
            <Route path='/category/add' element={<EquipmentCategoryAdd />} />
            <Route path='category/:id/edit' element={<EquipmentCategoryEdit />} />
            <Route path='category/:id/show' element={<EquipmentCategoryShow />} />
            <Route path='category/interventions' element={<EquipmentCategoryInterventions />} />
        </Routes>
    );
};

export default EquipmentRoutes;
