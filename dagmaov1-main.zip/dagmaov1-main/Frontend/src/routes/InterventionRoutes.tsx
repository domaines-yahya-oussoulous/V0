
import React from 'react';
import { Route, Routes } from 'react-router-dom';
import InterventionPage from "@/pages/InterventionPage.tsx";
import InterventionAdd from "@/features/intervention/InterventionAdd.tsx";
import InterventionShow from "@/features/intervention/InterventionShow.tsx";



const InterventionRoutes: React.FC = () => {
    return (
        <Routes>
            <Route path='/' element={<InterventionPage />} />
            <Route path='/add' element={<InterventionAdd />} />
            <Route path='/:id' element={<InterventionShow />} />
        </Routes>
    );
};

export default InterventionRoutes;
