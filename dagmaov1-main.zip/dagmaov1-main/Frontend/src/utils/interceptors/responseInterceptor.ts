import axios from 'axios';
import store from '@/store';
import { logout } from '@/features/login/loginSlice.ts';

// Response interceptor
const responseInterceptor = (response) => {
    return response;
};

// Handle response errors
const handleResponseError = async (error) => {
    const originalRequest = error.config;

    // Check if the error is a 401 Unauthorized
    if (error?.response?.status === 401) {
        // Prevent multiple retries
        if (originalRequest._retry) {
            store.dispatch(logout());
            return Promise.reject(error);
        }

        // Mark the request as a retry
        originalRequest._retry = true;

        // Check if the original request was a token refresh request
        if (originalRequest.url.includes('token/refresh')) {
            store.dispatch(logout());
            return Promise.reject(error);
        }

        try {
            // Get the refresh token from local storage
            const refreshToken = localStorage.getItem('refresh_token');

            if (refreshToken) {
                // Attempt to refresh the token
                const response = await axios.post('token/refresh', {
                    refresh_token: refreshToken,
                });

                if (response.status === 200) {
                    // Save the new token and retry the original request
                    const newToken = response.data.token;
                    localStorage.setItem('token', newToken);
                    originalRequest.headers['Authorization'] = `Bearer ${newToken}`;
                    return axios(originalRequest);
                }
            }
        } catch (refreshError) {
            store.dispatch(logout());
            return Promise.reject(refreshError);
        }
    }

    return Promise.reject(error);
};

// Add response interceptors
axios.interceptors.response.use(responseInterceptor, handleResponseError);

export default responseInterceptor;
