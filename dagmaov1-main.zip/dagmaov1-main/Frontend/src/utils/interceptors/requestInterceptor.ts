import axios from 'axios';

const requestInterceptor = (config) => {
    if (config.url === 'token/refresh' || config.url === 'api/auth') {
        return config;
    }
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
};

const handleRequestError = (error) => {
    return Promise.reject(error);
};

axios.interceptors.request.use(requestInterceptor, handleRequestError);

export default requestInterceptor;
