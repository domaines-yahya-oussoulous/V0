import axios from 'axios';

export const handleAxiosError = (error: unknown): string => {
    if (axios.isAxiosError(error)) {
        // If the error is an Axios error, return the error message
        return error.message;
    } else {
        // For any other error, return a generic error message
        return 'An unknown error occurred';
    }
};