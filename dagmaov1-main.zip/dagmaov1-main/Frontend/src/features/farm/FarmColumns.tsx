
import React, { useState } from 'react';
import { ColumnDef } from "@tanstack/react-table";
import { ArrowUpDown, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useDispatch } from "react-redux";
import DeleteModal from "@/components/deletemodal/DeleteModal.tsx";
import {deleteFarm} from "@/features/farm/FarmSlice.ts";
import {FarmType} from "@/types/FarmType.ts";


const FarmColumns: ColumnDef<FarmType>[] = [
    {
        accessorKey: "id",
        header: "Id",
    },
    {
        accessorKey: "name",
        header: "Name",
    },
    {
        accessorKey: "cityName",
        header: "City",
    },
    {
        accessorKey: "reference",
        header: "Reference",
    },

    {
        id: "actions",
        cell: ({ row }) => {
            const dispatch = useDispatch();
            const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
            const farm = row.original;

            const handleDelete = () => {
                dispatch(deleteFarm(farm.id));
                setIsDeleteModalOpen(false);
            };

            const handleOpenDeleteModal = () => {
                setIsDeleteModalOpen(true);
            };

            const handleCloseDeleteModal = () => {
                setIsDeleteModalOpen(false);
            };

            return (
                <>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={handleOpenDeleteModal}>Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                    <DeleteModal
                        isOpen={isDeleteModalOpen}
                        onClose={handleCloseDeleteModal}
                        onDelete={handleDelete}
                        deleteMessage={`Are you sure you want to delete ${farm.name}?`}
                    />
                </>
            );
        },
    },
];

export default FarmColumns;
