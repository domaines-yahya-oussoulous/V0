import * as z from 'zod';

export const farmFormSchema = z.object({
    name: z.string().nonempty(),
    reference: z.string().optional(),
    location: z.string().optional(),
    city: z.string().nonempty()
});

export const farmDefaultValues = {
    name: "",
    reference: "",
    location: "",
    city: ""
};
