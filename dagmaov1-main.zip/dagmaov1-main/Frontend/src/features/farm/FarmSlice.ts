import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import { FarmType } from "@/types/FarmType.ts";
import {handleAxiosError} from "@/utils/handlers/handleAxiosError.ts";

interface FarmState {
    farms: FarmType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: FarmState = {
    farms: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const farmSlice = createSlice({
    name: 'farms',
    initialState,
    reducers: {
        fetchFarmsStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchFarmsSuccess(state, action: PayloadAction<{ farms: FarmType[], total: number }>) {
            state.loading = false;
            state.farms = action.payload.farms;
            state.total = action.payload.total;
        },
        fetchFarmsFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deleteFarmStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deleteFarmSuccess(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = null;
            state.farms = state.farms.filter(farm => farm.id!== action.payload);
        },
        deleteFarmFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchFarmsStart,
    fetchFarmsSuccess,
    fetchFarmsFailure,
    setPage,
    setSearchTerm,
    deleteFarmStart,
    deleteFarmSuccess,
    deleteFarmFailure,
} = farmSlice.actions;

export const fetchFarms = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchFarmsStart());

        // Construire l'URL en fonction de la présence de searchTerm
        let url = `farms?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&name=${searchTerm}`;
        }
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const farms = response.data['hydra:member'];
        dispatch(fetchFarmsSuccess({ farms, total: totalItems }));
    } catch (error) {
        dispatch(fetchFarmsFailure(handleAxiosError(error)));
    }
};

export const deleteFarm = (id: string): AppThunk => async (dispatch) => {
    try {
        dispatch(deleteFarmStart());
        await axios.delete(`farms/${id}`);
        dispatch(deleteFarmSuccess(id));
    } catch (error) {
        dispatch(deleteFarmFailure(handleAxiosError(error)));
    }
};

export default farmSlice.reducer;
