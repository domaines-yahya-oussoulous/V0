import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import {UserType} from "@/types/UserType.ts";
import {handleAxiosError} from "@/utils/handlers/handleAxiosError.ts";


interface LoginState {
    loading: boolean;
    error: string | null;
    user: UserType | null;
    auth: boolean;
}

const initialState: LoginState = {
    loading: false,
    error: null,
    user: null,
    auth: false,
};

const loginSlice = createSlice({
    name: 'users',
    initialState,
    reducers: {
        loginStart(state) {
            state.loading = true;
            state.error = null;
        },
        loginSuccess(state) {
            state.loading = false;
            state.auth = true;
        },
        loginFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
            state.auth = false;
        },
        setUser(state, action: PayloadAction<UserType>) {
            state.user = action.payload;
        },
        logout(state) {
            state.user = null;
            state.auth = false;
            localStorage.removeItem('token');
            localStorage.removeItem('refresh_token');
        },
        clearError(state) {
            state.error = null;
        }
    },
});

export const { loginStart, loginSuccess, loginFailure, setUser, logout, clearError } = loginSlice.actions;

export const login = (email: string, password: string): AppThunk => async (dispatch) => {
    const timeoutDuration = 40000;
    let didTimeout = false;

    const timeout = setTimeout(() => {
        didTimeout = true;
        dispatch(loginFailure('Request timed out'));
    }, timeoutDuration);

    try {
        dispatch(loginStart());

        const loginResponse = await axios.post('auth', { email, password });

        if (!didTimeout) {
            localStorage.setItem('token', loginResponse.data.token);
            localStorage.setItem('refresh_token', loginResponse.data.refresh_token);
            dispatch(loginSuccess());

            // Fetch user credentials
            const userCredentialsResponse = await axios.get('user-credentials');
            dispatch(setUser(userCredentialsResponse.data));
        }

        clearTimeout(timeout);
    } catch (error) {
        if (!didTimeout) {
            clearTimeout(timeout);
            dispatch(loginFailure(handleAxiosError(error)));
        }
    }
};

export default loginSlice.reducer;
