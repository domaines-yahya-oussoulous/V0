import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { SparepartsType } from '@/types/SparepartsType.ts';
import Loader from "@/components/loader/Loader.tsx";

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + "spare-parts/";
const SparePartsShowPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const [sparePart, setSparePart] = useState<SparepartsType | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchSparePart = async () => {
            try {
                const response = await axios.get(`/spare_parts/${id}`);
                setSparePart(response.data);
                setLoading(false);
            } catch (err) {
                setError('Error fetching spare part details.');
                setLoading(false);
            }
        };

        fetchSparePart();
    }, [id]);

    if (loading) {
        return <Loader loading={loading} />;
    }

    if (error) {
        return <p className="text-center text-red-500">{error}</p>;
    }

    if (!sparePart) {
        return <p className="text-center text-gray-500">No spare part found.</p>;
    }

    return (
        <section className='py-10'>
            <div className='max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8'>
                <h1 className='mb-6 text-3xl font-bold text-gray-900'>{sparePart.inventoryCode}</h1>
                <div className="space-y-4 bg-white p-6 rounded-lg shadow-md">
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">ID:</p>
                        <p className="ml-2 text-gray-600">{sparePart.id}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Inventory Code:</p>
                        <p className="ml-2 text-gray-600">{sparePart.inventoryCode}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Category:</p>
                        <p className="ml-2 text-gray-600">{sparePart.category}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Brand:</p>
                        <p className="ml-2 text-gray-600">{sparePart.brand}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Units Number:</p>
                        <p className="ml-2 text-gray-600">{sparePart.unitsNumber}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Unit Price:</p>
                        <p className="ml-2 text-gray-600">${sparePart.unitPrice}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Last Inventory:</p>
                        <p className="ml-2 text-gray-600">{sparePart.lastInventory}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Availability:</p>
                        <p className="ml-2 text-gray-600">{sparePart.availability ? 'Available' : 'Unavailable'}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Quantity:</p>
                        <p className="ml-2 text-gray-600">{sparePart.quantity}</p>
                    </div>
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Order Duration:</p>
                        <p className="ml-2 text-gray-600">{sparePart.orderDuration}</p>
                    </div>
                    {sparePart.image && (
                        <div className="flex flex-col items-center">
                            <p className="font-semibold text-gray-700">Image:</p>
                            <img src={`${IMAGE_BASE_URL}/${sparePart.image}`} alt={sparePart.inventoryCode} className="mt-2 w-64 h-64 object-cover rounded-lg shadow-md" />
                        </div>
                    )}
                    <div className="flex items-center">
                        <p className="font-semibold text-gray-700">Farm:</p>
                        <p className="ml-2 text-gray-600">{sparePart.farm?.name ?? 'N/A'}</p>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default SparePartsShowPage;
