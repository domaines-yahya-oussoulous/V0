// sparepartsSlice.ts
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import { SparepartsType } from "@/types/SparepartsType.ts";
import {handleAxiosError} from "@/utils/handlers/handleAxiosError.ts";

interface SparepartsState {
    spareParts: SparepartsType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: SparepartsState = {
    spareParts: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const sparepartsSlice = createSlice({
    name: 'spareparts',
    initialState,
    reducers: {
        fetchSparepartsStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchSparepartsSuccess(state, action: PayloadAction<{ spareParts: SparepartsType[], total: number }>) {
            state.loading = false;
            state.spareParts = action.payload.spareParts;
            state.total = action.payload.total;
        },
        fetchSparepartsFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deleteSparepartStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deleteSparepartSuccess(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = null;
            state.spareParts = state.spareParts.filter(sparePart => sparePart.id !== action.payload);
        },
        deleteSparepartFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchSparepartsStart,
    fetchSparepartsSuccess,
    fetchSparepartsFailure,
    setPage,
    setSearchTerm,
    deleteSparepartStart,
    deleteSparepartSuccess,
    deleteSparepartFailure,
} = sparepartsSlice.actions;

export const fetchSpareparts = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchSparepartsStart());

        // Construire l'URL en fonction de la présence de searchTerm
        let url = `spare_parts?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&name=${searchTerm}`;
        }
        // Ajouter order[id] à la fin de l'URL
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const spareParts = response.data['hydra:member'];
        dispatch(fetchSparepartsSuccess({ spareParts, total: totalItems }));
    } catch (error) {
        dispatch(fetchSparepartsFailure(handleAxiosError(error)));
    }
};

export const deleteSparepart = (id: string): AppThunk => async (dispatch) => {
    try {
        dispatch(deleteSparepartStart());
        await axios.delete(`spare_parts/${id}`);
        dispatch(deleteSparepartSuccess(id));
    } catch (error) {
        dispatch(deleteSparepartFailure(handleAxiosError(error)));
    }
};

export default sparepartsSlice.reducer;
