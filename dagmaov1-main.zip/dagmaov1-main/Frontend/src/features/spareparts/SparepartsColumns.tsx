import { useState } from "react";
import { ColumnDef } from "@tanstack/react-table";
import { ArrowUpDown, MoreHorizontal } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useDispatch } from "react-redux";

import { SparepartsType } from "@/types/SparepartsType.ts";
import {deleteSparepart} from "@/features/spareparts/SparePartsSlice.ts";
import DeleteModal from "@/components/deletemodal/DeleteModal.tsx"; // Adjust path if necessary

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + "spare-parts/";

export const SparePartsColumns: ColumnDef<SparepartsType>[] = [
    {
        accessorKey: "id",
        header: "Id",
    },
    {
        accessorKey: "name",
        header: "Name",
    },
    {
        accessorKey: "inventoryCode",
        header: "Inventory Code",
    },
    {
        accessorKey: "categoryName",
        header: "Category",
    },
    {
        accessorKey: "brand",
        header: "Brand",
    },
    {
        accessorKey: "unitPrice",
        header: "Unit Price",
    },
    {
        accessorKey: "lastInventory",
        header: "Last Inventory",
    },
    {
        accessorKey: "availability",
        header: "Availability",
        cell: ({ row }) => (row.original.availability ? "Available" : "Not Available"),
    },
    {
        accessorKey: "quantity",
        header: "Quantity",
    },
    {
        accessorKey: "orderDuration",
        header: "Order Duration",
    },
    {
        accessorKey: "image",
        header: "Image",
        cell: ({ row }) => {
            const imageUrl = `${IMAGE_BASE_URL}${row.original.image}`;
            return (
                <div className="flex items-center justify-center">
                    {row.original.image ? (
                        <img src={imageUrl} alt="Spare Part" className="h-10 w-10 object-cover" />
                    ) : (
                        <span>No Image</span>
                    )}
                </div>
            );
        },
    },
    {
        id: "actions",
        cell: ({ row }) => {
            const dispatch = useDispatch();
            const sparePart = row.original;

            const [isModalOpen, setIsModalOpen] = useState(false);

            const toggleModal = () => {
                setIsModalOpen(!isModalOpen);
            };

            const handleDelete = () => {
                dispatch(deleteSparepart(sparePart.id));
                setIsModalOpen(false); // Close modal after dispatching delete action
            };

            return (
                <>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                                <Link to={`/spare-parts/${sparePart.id}`}>View</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                                <Link to={`/spare-parts/${sparePart.id}/edit`}>Edit</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={toggleModal}>Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                    <DeleteModal
                        isOpen={isModalOpen}
                        onClose={toggleModal}
                        onDelete={handleDelete}
                        deleteMessage="Are you sure you want to delete this spare part?"
                    />
                </>
            );
        },
    },
];

