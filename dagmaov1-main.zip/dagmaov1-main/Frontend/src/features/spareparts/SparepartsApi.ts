import axios from "axios";

export const createSpareparts = async (formData: FormData) => {
    try {
        const response = await axios.post(`spare-parts/add`, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('spare part created:', response.data);
        return response.data; // Return the response data if needed
    } catch (error) {
        console.error('Failed to create spare part:', error);
        throw error; // Re-throw the error to propagate it further
    }
};
export const getSpareparts = async (id: string) => {
    try {
        const response = await axios.get(`spare_parts/${id}`);
        return response.data; // Assuming the response contains the spare part data
    } catch (error) {
        throw new Error(`Failed to fetch spare part with ID ${id}: ${error.message}`);
    }
};

// Function to update a spare part by ID
export const updateSpareparts = async (id: string, data: any) => {
    try {
        const response = await axios.post(`spare-parts/${id}/update`, data, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data; // Assuming the response contains the updated spare part data
    } catch (error) {
        throw new Error(`Failed to update spare part with ID ${id}: ${error.message}`);
    }
};