// SparepartsAdd.tsx
import React, { useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import axios from 'axios';
import { toast } from "@/components/ui/use-toast.ts";
import { Button } from "@/components/ui/button.tsx";
import * as z from 'zod';
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage
} from "@/components/ui/form.tsx";
import { Toaster } from "@/components/ui/toaster.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import {sparePartDefaultValues, sparePartFormSchema} from "@/features/spareparts/sparepartsFormSchema.ts";
import {createSpareparts} from "@/features/spareparts/SparepartsApi.ts";
import MessageModal from "@/components/messagemodal/MessageModal.tsx";
import {useNavigate} from "react-router-dom";
import Loader from "@/components/loader/Loader.tsx";
import FormParameterField from "@/components/formparameterfield/FormParameterField.tsx";
import {Checkbox} from "@/components/ui/checkbox.tsx";
import MoneyInput from "@/components/ui/MoneyInput.tsx";


const SparepartsAdd: React.FC = () => {
    const [farms, setFarms] = useState([]);
    const [loading, setLoading] = useState(false); // Loading state
    const [modalVisible, setModalVisible] = useState(false); // Modal visibility state
    const [modalMessage, setModalMessage] = useState(''); // Modal message state
    const [modalSuccess, setModalSuccess] = useState(false);
    const [categories, setCategories] = useState([]);// Modal message state
    const navigate = useNavigate();
    const form = useForm<z.infer<typeof sparePartFormSchema>>({
        resolver: zodResolver(sparePartFormSchema),
        defaultValues: sparePartDefaultValues
    });

    useEffect(() => {
        const fetchFarms = async () => {
            setLoading(true); // Start loading
            try {
                const response = await axios.get('farms');
                setFarms(response.data["hydra:member"]);
            } catch (error) {
                console.error("Error fetching farms:", error);
                toast({
                    title: "Error",
                    description: 'Failed to fetch farms.',
                    variant: "destructive",
                });
            } finally {
                setLoading(false); // End loading
            }
        };
        const fetchCategories = async () => {
            try {
                const response = await axios.get('spare-parts-categories-brief');
                setCategories(response.data["hydra:member"]);
            } catch (error) {
                console.error("Error fetching categories:", error);
                toast({
                    title: "Error",
                    description: 'Failed to fetch categories.',
                    variant: "destructive",
                });
            } finally {
                setLoading(false); // End loading
            }
        };

        fetchFarms();
        fetchCategories();
    }, []);

    const handleSubmit = async (data: z.infer<typeof sparePartFormSchema>) => {
        if (data.farm) {
            data.farm = `/api/farms/${data.farm}`;
        }
        console.log("Form Data Submitted:", data);
        setLoading(true); // Start loading
        try {
            await createSpareparts(data);
            setModalSuccess(true)
            setModalMessage('Spare parts has been created successfully.');
            setModalVisible(true);
            form.reset();
        } catch (error) {
            console.error("Error adding spare part:", error);
            setModalSuccess(false)
            setModalMessage(error.response?.data?.detail || 'An unknown error occurred');
            setModalVisible(true);
        } finally {
            setLoading(false); // End loading
        }
    };

    const handleModalClose = () => {
        setModalVisible(false);
        if (modalSuccess) {
            navigate('/spare-parts'); // Navigate to spare parts list after successful update
        }
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    return (
        <>
            <div className={`mt-12 sm:mt-24 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
                <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Add Spare Part</h2>
                <Form {...form}>
                    <form className="m-4 sm:m-12" onSubmit={form.handleSubmit(handleSubmit)}>
                        <div className="max-w-7xl mx-auto p-4 sm:flex sm:justify-between sm:space-x-8">
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2 mb-4 sm:mb-0">
                                <FormField
                                    control={form.control}
                                    name="farm"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel required>Farm</FormLabel>
                                            <FormControl>
                                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select a farm" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {farms.map((farm) => (
                                                            <SelectItem key={farm.id} value={farm.id.toString()}>
                                                                {farm.name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                            <FormDescription>
                                                Select the farm where the spare part is located.
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="sparePartCategory"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel required>Category</FormLabel>
                                            <FormControl>
                                                <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select a category" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {categories.map((category) => (
                                                            <SelectItem key={category.id} value={`/api/spare_part_categories/${category.id.toString()}`}>
                                                                {category.name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                            <FormDescription>
                                                Select the category of the spare part.
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="name"
                                    label="Name"
                                    placeholder="Spare part name"
                                    description="This is the name of the spare part"
                                    required
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="reference"
                                    label="Reference"
                                    placeholder="Spare part reference"
                                    description="This is the reference of the spare part"
                                    required
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="inventoryCode"
                                    label="Inventory Code"
                                    placeholder="Inventory code"
                                    description="This is the inventory code of the spare part"
                                    required
                                />
                                <FormField
                                    control={form.control}
                                    name="imageFile"
                                    render={({ field: { value, onChange, ...fieldProps } }) => (
                                        <FormItem>
                                            <FormLabel>Image</FormLabel>
                                            <FormControl>
                                                <Input
                                                    {...fieldProps}
                                                    type="file"
                                                    onChange={(event) =>
                                                        onChange(event.target.files && event.target.files[0])
                                                    }
                                                />
                                            </FormControl>
                                            <FormDescription />
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2">
                                <MoneyInput
                                    form={form}
                                    label="Unit Price"
                                    name="unitPrice"
                                    placeholder="Unit Price"
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="lastInventoryDate"
                                    label="Last Inventory Date"
                                    placeholder="Last Inventory Date"
                                    type="date"
                                />
                                <FormField
                                    control={form.control}
                                    name="availability"
                                    render={({ field }) => (
                                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                                            <FormControl>
                                                <Checkbox
                                                    checked={field.value}
                                                    onCheckedChange={field.onChange}
                                                />
                                            </FormControl>
                                            <div className="space-y-1 leading-none">
                                                <FormLabel>
                                                    Availability
                                                </FormLabel>
                                                <FormDescription>
                                                    Is the spare part available?
                                                </FormDescription>
                                            </div>
                                        </FormItem>
                                    )}
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="quantity"
                                    label="Quantity"
                                    placeholder="Quantity"
                                    type="number"
                                    description="Quantity of the spare part"
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="orderDuration"
                                    label="Order Duration"
                                    placeholder="Order Duration"
                                    type="number"
                                    description="Duration of the order"
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="brand"
                                    label="Brand"
                                    placeholder="Brand"
                                    description="This is the brand of the spare part"
                                    required
                                />
                            </div>
                        </div>
                        <div className="flex justify-center mt-6">
                            <Button type="submit" className="w-full sm:w-auto px-6 py-3 text-lg" disabled={loading}>
                                Submit
                            </Button>
                        </div>
                    </form>
                </Form>
            </div>
            <Toaster />
            <MessageModal
                visible={modalVisible}
                text={modalMessage}
                success={modalSuccess}
                onPressEvent={handleModalClose}
                LeftButtonLabel={"ok"}
            />
        </>
    );
};

export default SparepartsAdd;
