// SparePartsCategoryEdit.tsx

import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button.tsx';
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from '@/components/ui/form.tsx';
import { Toaster } from '@/components/ui/toaster.tsx';
import { Input } from '@/components/ui/input.tsx';
import MessageModal from '@/components/messagemodal/MessageModal.tsx';
import { useNavigate, useParams } from 'react-router-dom';
import Loader from '@/components/loader/Loader.tsx';


import { Textarea } from '@/components/ui/textarea.tsx';
import {
    sparePartsCategoryDefaultValues,
    sparePartsCategoryFormSchema
} from "@/features/spareparts/category/SparepartsCategoryFormSchema.ts";
import {getSparePartsCategory, updateSparePartsCategory} from "@/features/spareparts/category/SparepartsCategoryApi.ts";
import {SparePartsCategoryType} from "@/types/SparepartsCategoryType.ts";
import FormParameterField from "@/components/formparameterfield/FormParameterField.tsx";


const SparePartsCategoryEdit: React.FC = () => {
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [modalMessage, setModalMessage] = useState('');
    const [modalSuccess, setModalSuccess] = useState(false);
    const navigate = useNavigate();
    const { id } = useParams(); // Assuming you're using React Router to get the ID from URL params
    const form = useForm<z.infer<typeof sparePartsCategoryFormSchema>>({
        resolver: zodResolver(sparePartsCategoryFormSchema),
        defaultValues: sparePartsCategoryDefaultValues,
    });

    useEffect(() => {
        const fetchCategory = async () => {
            setLoading(true);
            try {
                const category = await getSparePartsCategory(id);
                form.reset(category); // Set form values from fetched category
            } catch (error) {
                console.error('Error fetching spare parts category:', error);
                setModalMessage(error.response?.data?.detail || 'An unknown error occurred');
                setModalVisible(true);
            } finally {
                setLoading(false);
            }
        };

        fetchCategory();
    }, [id, form]);

    const handleSubmit = async (data: SparePartsCategoryType) => {
        setLoading(true);
        try {
            await updateSparePartsCategory(id, data);
            setModalSuccess(true);
            setModalMessage('Spare Parts Category has been updated successfully.');
            setModalVisible(true);
        } catch (error) {
            console.error('Error updating spare parts category:', error);
            setModalSuccess(false);
            setModalMessage(error.response?.data?.detail || 'An unknown error occurred');
            setModalVisible(true);
        } finally {
            setLoading(false);
        }
    };

    const handleModalClose = () => {
        setModalVisible(false);
        if (modalSuccess) {
            navigate('/spare-parts/category'); // Navigate to spare parts category list after successful update
        }
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    return (
        <>
            <div className={`mt-12 sm:mt-24 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
                <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Edit Spare Parts Category</h2>
                <Form {...form}>
                    <form className="m-4 sm:m-12" onSubmit={form.handleSubmit(handleSubmit)}>
                        <div className="max-w-7xl mx-auto p-4 sm:flex sm:justify-between sm:space-x-8">
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2 mb-4 sm:mb-0 mx-auto">
                                <FormParameterField
                                    control={form.control}
                                    name="name"
                                    label="Name"
                                    placeholder="Category name"
                                    description="This is the name of the category"
                                />
                                <FormField
                                    control={form.control}
                                    name="description"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Description</FormLabel>
                                            <FormControl>
                                                <Textarea
                                                    placeholder="Category description"
                                                    className="resize-none"
                                                    {...field}
                                                />
                                            </FormControl>
                                            <FormDescription>
                                                This is the description of the category
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="imageFile"
                                    render={({ field: { value, onChange, ...fieldProps } }) => (
                                        <FormItem>
                                            <FormLabel>Image</FormLabel>
                                            <FormControl>
                                                <Input
                                                    {...fieldProps}
                                                    type="file"
                                                    onChange={(event) =>
                                                        onChange(event.target.files && event.target.files[0])
                                                    }
                                                />
                                            </FormControl>
                                            <FormDescription />
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                        </div>
                        <div className="flex justify-center mt-6">
                            <Button type="submit" className="w-full sm:w-auto px-6 py-3 text-lg">Submit</Button>
                        </div>
                    </form>
                </Form>
            </div>
            <Toaster />
            <MessageModal
                visible={modalVisible}
                text={modalMessage}
                success={modalSuccess}
                onPressEvent={handleModalClose}
                LeftButtonLabel="Ok"
            />
        </>
    );
};

export default SparePartsCategoryEdit;
