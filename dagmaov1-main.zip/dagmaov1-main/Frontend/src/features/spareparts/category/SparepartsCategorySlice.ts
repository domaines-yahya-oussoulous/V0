// store/sparePartsCategorySlice.ts

import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import {SparePartsCategoryType} from "@/types/SparepartsCategoryType.ts";
import {handleAxiosError} from "@/utils/handlers/handleAxiosError.ts";

interface SparePartsCategoryState {
    sparePartsCategories: SparePartsCategoryType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: SparePartsCategoryState = {
    sparePartsCategories: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const sparePartsCategorySlice = createSlice({
    name: 'sparePartsCategories',
    initialState,
    reducers: {
        fetchSparePartsCategoryStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchSparePartsCategorySuccess(state, action: PayloadAction<{ sparePartsCategories: SparePartsCategoryType[], total: number }>) {
            state.loading = false;
            state.sparePartsCategories = action.payload.sparePartsCategories;
            state.total = action.payload.total;
        },
        fetchSparePartsCategoryFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deleteSparePartsCategoryStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deleteSparePartsCategorySuccess(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.sparePartsCategories = state.sparePartsCategories.filter(category => category.id !== action.payload);
        },
        deleteSparePartsCategoryFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchSparePartsCategoryStart,
    fetchSparePartsCategorySuccess,
    fetchSparePartsCategoryFailure,
    setPage,
    setSearchTerm,
    deleteSparePartsCategoryStart,
    deleteSparePartsCategorySuccess,
    deleteSparePartsCategoryFailure,
} = sparePartsCategorySlice.actions;

export const fetchSparePartsCategories = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchSparePartsCategoryStart());

        let url = `spare_part_categories?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&name=${searchTerm}`;
        }
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const sparePartsCategories = response.data['hydra:member'];
        dispatch(fetchSparePartsCategorySuccess({ sparePartsCategories, total: totalItems }));
    } catch (error) {
        dispatch(fetchSparePartsCategoryFailure(handleAxiosError(error)));
    }
};

export const deleteSparePartsCategory = (id: string): AppThunk => async (dispatch) => {
    try {
        dispatch(deleteSparePartsCategoryStart());
        await axios.delete(`spare_part_categories/${id}`);
        dispatch(deleteSparePartsCategorySuccess(id));
    } catch (error) {
        dispatch(deleteSparePartsCategoryFailure(handleAxiosError(error)));
    }
};

export const createSparePartsCategory = (formData: FormData): AppThunk => async () => {
    try {
        const response = await axios.post(`spare_parts_categories/add`, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('Spare parts category created:', response.data);
        // Optionally handle response if needed
        // You might dispatch an action if creation modifies state
    } catch (error) {
        console.error('Failed to create spare parts category:', error);
        // Handle error if needed
    }
};

export default sparePartsCategorySlice.reducer;
