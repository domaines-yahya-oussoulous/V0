import React, { useState } from 'react';
import { ColumnDef } from "@tanstack/react-table";
import { ArrowUpDown, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useDispatch } from "react-redux";
import DeleteModal from "@/components/deletemodal/DeleteModal.tsx";
import { Link } from "react-router-dom";
import {deleteSparePartsCategory} from "@/features/spareparts/category/SparepartsCategorySlice.ts";
import {SparePartsCategoryType} from "@/types/SparepartsCategoryType.ts";

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + "spare-parts-category-images/";
const SparePartsCategoryColumns: ColumnDef<SparePartsCategoryType>[] = [
    {
        accessorKey: "id",
        header: "Id",
    },
    {
        accessorKey: "name",
        header: "Name",
    },
    {
        accessorKey: "image",
        header: "Image",
        cell: ({ row }) => {
            const imageUrl = `${IMAGE_BASE_URL}${row.original.image}`;
            return (
                <div className="flex items-center justify-center">
                    {row.original.image ? (
                        <img src={imageUrl} alt="Spare Parts" className="h-10 w-10 object-cover" />
                    ) : (
                        <span>No Image</span>
                    )}
                </div>
            );
        },
    },
    {
        id: "actions",
        cell: ({ row }) => {
            const dispatch = useDispatch();
            const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
            const sparePartsCategory = row.original;

            const handleDelete = () => {
                dispatch(deleteSparePartsCategory(sparePartsCategory.id));
                setIsDeleteModalOpen(false);
            };

            const handleOpenDeleteModal = () => {
                setIsDeleteModalOpen(true);
            };

            const handleCloseDeleteModal = () => {
                setIsDeleteModalOpen(false);
            };

            return (
                <>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                                <Link to={`/spare-parts/category/${sparePartsCategory.id}/show`}>Show</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                                <Link to={`/spare-parts/category/${sparePartsCategory.id}/edit`}>Edit</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={handleOpenDeleteModal}>Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                    <DeleteModal
                        isOpen={isDeleteModalOpen}
                        onClose={handleCloseDeleteModal}
                        onDelete={handleDelete}
                        deleteMessage={`Are you sure you want to delete ${sparePartsCategory.name}?`}
                    />
                </>
            );
        },
    },
];

export default SparePartsCategoryColumns;
