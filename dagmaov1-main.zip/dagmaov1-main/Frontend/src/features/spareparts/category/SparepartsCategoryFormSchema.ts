import * as z from 'zod';

export const MAX_FILE_SIZE = 5000000;
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

export const sparePartsCategoryFormSchema = z.object({
    name: z.string().nonempty("Name is required."),
    description: z.string().optional(),
    imageFile: z.any().optional().nullable()
        .refine(file => file?.length == 1 ? ACCEPTED_IMAGE_TYPES.includes(file?.[0]?.type) ? true : false : true, 'Invalid file. choose either JPEG or PNG image')
        .refine(file => file?.length == 1 ? file[0]?.size <= MAX_FILE_SIZE ? true : false : true, 'Max file size allowed is 5MB.'),
});

export const sparePartsCategoryDefaultValues = {
    name: "",
    description: "",
    imageFile: null,
};