import axios from "axios";

export const createSparePartsCategory = async (formData: FormData) => {
    try {
        const response = await axios.post('spare-parts-categories/add', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('Spare parts category created:', response.data);
        return response.data; // Return the response data if needed
    } catch (error) {
        console.error('Failed to create spare parts category:', error);
        throw error; // Re-throw the error to propagate it further
    }
};

export const updateSparePartsCategory = async (id: string, data: any) => {
    try {
        const response = await axios.post(`spare-parts-categories/${id}/update`, data, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
        });
        return response.data;
    } catch (error) {
        throw error;
    }
};

export const getSparePartsCategory = async (id: string) => {
    try {
        const response = await axios.get(`spare_part_categories/${id}`);
        return response.data; // Assuming your API returns the spare parts category data
    } catch (error) {
        throw error; // Handle error as per your application's error handling strategy
    }
};

export const deleteSparePartsCategory = async (categoryId: string) => {
    const url = `spare-parts-categories/${categoryId}`;

    try {
        const response = await axios.delete(url);
        return response.data; // Return the response if necessary
    } catch (error) {
        throw new Error(`Failed to delete spare parts category: ${error.message}`);
    }
};
