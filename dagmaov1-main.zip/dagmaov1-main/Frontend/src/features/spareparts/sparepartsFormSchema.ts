import * as z from 'zod';

export const MAX_FILE_SIZE = 5000000;
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

export const sparePartFormSchema = z.object({
    name: z.string().nonempty("Name is required."),
    reference: z.string().nonempty("Reference is required."),
    inventoryCode: z.string().nonempty("Inventory code is required."),
    imageFile: z.any().optional().nullable()
        .refine(file => file?.length === 1 ? ACCEPTED_IMAGE_TYPES.includes(file?.[0]?.type) : true, 'Invalid file type. Choose either JPEG, JPG, PNG, or WEBP image.')
        .refine(file => file?.length === 1 ? file[0]?.size <= MAX_FILE_SIZE : true, 'Max file size allowed is 5MB.'),
    sparePartCategory: z.string().nonempty("Spare part category is required."),
    brand: z.string().nonempty("Brand is required."),
    unitPrice: z.coerce.number().min(0, "Unit price cannot be negative."),
    lastInventory: z.string().optional().nullable(),
    availability: z.boolean().optional(),
    quantity: z.coerce.number().min(0, "Quantity cannot be negative."),
    orderDuration: z.coerce.number().min(0, "Order duration cannot be negative."),
    equipment: z.array(z.string()).optional(),
    lastInventoryDate: z.string().optional().nullable()
        .refine(date => date ? !isNaN(Date.parse(date)) : true, "Invalid date format."),
    farm: z.string().optional().nullable(),
});

export const sparePartDefaultValues = {
    name: "",
    reference: "",
    inventoryCode: "",
    imageFile: null,
    sparePartCategory: "",
    brand: "",
    unitPrice: 0,
    lastInventory: "",
    availability: false,
    quantity: 0,
    orderDuration: 0,
    equipment: [],
    lastInventoryDate: "",
    farm: "",
};
