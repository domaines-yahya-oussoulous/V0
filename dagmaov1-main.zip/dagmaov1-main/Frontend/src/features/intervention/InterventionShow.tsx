import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import Loader from "@/components/loader/Loader.tsx";
import { List, CheckCircle, AlertTriangle, Trash, Edit } from "lucide-react";
import DeleteModal from "@/components/deletemodal/DeleteModal.tsx";
import MessageModal from "@/components/messagemodal/MessageModal.tsx"; // Import Lucide icons


interface Operation {
    id: number;
    description: string;
}

interface Intervention {
    name: string;
    operations: Operation[];
}

const InterventionShow: React.FC = () => {
    const { id } = useParams<{ id: string }>(); // Extract id from the URL
    const [intervention, setIntervention] = useState<Intervention | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [deletingId, setDeletingId] = useState<number | null>(null); // ID of the operation being deleted
    const [editingId, setEditingId] = useState<number | null>(null); // ID of the operation being edited
    const [editDescription, setEditDescription] = useState<string>(''); // Current description being edited
    const [deleteModalOpen, setDeleteModalOpen] = useState<boolean>(false); // Control delete modal visibility
    const [messageModalOpen, setMessageModalOpen] = useState<boolean>(false); // Control message modal visibility
    const [messageText, setMessageText] = useState<string>(''); // Text to display in message modal
    const [messageSuccess, setMessageSuccess] = useState<boolean>(false); // Success or error status

    useEffect(() => {
        const fetchIntervention = async () => {
            try {
                const response = await axios.get(`intervention-operations/${id}`);
                setIntervention(response.data);
            } catch (err) {
                setError('Error fetching intervention data.');
            } finally {
                setLoading(false);
            }
        };

        fetchIntervention();
    }, [id]);

    const handleDelete = async () => {
        if (deletingId === null) return; // Ensure there's an ID to delete

        setLoading(true); // Show loader while deleting
        try {
            await axios.delete(`operations/${deletingId}`);
            setIntervention((prev) => (prev ? {
                ...prev,
                operations: prev.operations.filter(op => op.id !== deletingId),
            } : null));
            setMessageText('Operation deleted successfully.');
            setMessageSuccess(true);
        } catch (err) {
            setMessageText('Error deleting operation.');
            setMessageSuccess(false);
        } finally {
            setDeleteModalOpen(false); // Close delete modal
            setMessageModalOpen(true); // Open message modal
            setLoading(false); // Hide loader
        }
    };

    const handleEdit = async () => {
        if (editingId === null || editDescription.trim() === '') return; // Ensure there's an ID and description to update

        setLoading(true); // Show loader while updating
        try {
            await axios.patch(
                `operations/${editingId}`,
                { description: editDescription },
                { headers: { 'Content-Type': 'application/merge-patch+json' } }
            );
            setIntervention((prev) => (prev ? {
                ...prev,
                operations: prev.operations.map(op =>
                    op.id === editingId ? { ...op, description: editDescription } : op
                ),
            } : null));
            setMessageText('Operation updated successfully.');
            setMessageSuccess(true);
        } catch (err) {
            setMessageText('Error updating operation.');
            setMessageSuccess(false);
        } finally {
            setEditingId(null); // Exit edit mode
            setMessageModalOpen(true); // Open message modal
            setLoading(false); // Hide loader
        }
    };

    const openDeleteModal = (operationId: number) => {
        setDeletingId(operationId);
        setDeleteModalOpen(true);
    };

    const openEditMode = (operationId: number, description: string) => {
        setEditingId(operationId);
        setEditDescription(description);
    };

    const closeDeleteModal = () => {
        setDeleteModalOpen(false);
    };

    const closeMessageModal = () => {
        setMessageModalOpen(false);
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    if (error) {
        return (
            <div className="text-center py-12">
                <AlertTriangle className="mx-auto text-red-500 w-12 h-12 mb-4" />
                <p className="text-center text-red-500">{error}</p>
            </div>
        );
    }

    if (!intervention) {
        return (
            <div className="text-center py-12">
                <List className="mx-auto text-gray-500 w-12 h-12 mb-4" />
                <p className="text-center text-gray-500">No intervention data found.</p>
            </div>
        );
    }

    return (
        <div className="flex justify-center py-12 bg-white min-h-screen">
            <div className="bg-white shadow-lg rounded-xl p-10 max-w-lg w-full border border-gray-200">
                <h1 className="text-3xl font-bold text-center text-gray-900 mb-6">
                    {intervention.name}
                </h1>
                <h2 className="text-lg font-semibold text-gray-700 mb-4">Operations:</h2>
                <ul className="space-y-6">
                    {intervention.operations.map((operation) => (
                        <li key={operation.id} className="bg-gray-100 border border-gray-300 p-5 rounded-lg shadow-md flex items-start space-x-3">
                            <CheckCircle className="w-6 h-6 text-green-500 mt-1" />
                            <div className="flex-1">
                                <div className="text-gray-800 font-semibold">
                                    Operation {operation.id}
                                </div>
                                <textarea
                                    className="w-full p-2 mt-2 border border-gray-300 rounded-md bg-gray-50 text-gray-600 focus:outline-none resize-none"
                                    disabled={editingId !== operation.id} // Enable only if editing
                                    rows={2}
                                    value={editingId === operation.id ? editDescription : operation.description}
                                    onChange={(e) => setEditDescription(e.target.value)}
                                />
                            </div>
                            <div className="ml-4 flex space-x-2">
                                {editingId === operation.id ? (
                                    <>
                                        <button
                                            onClick={handleEdit}
                                            className="text-blue-500 hover:text-blue-700"
                                        >
                                            Save
                                        </button>
                                        <button
                                            onClick={() => setEditingId(null)}
                                            className="text-gray-500 hover:text-gray-700"
                                        >
                                            Cancel
                                        </button>
                                    </>
                                ) : (
                                    <>
                                        <button
                                            onClick={() => openEditMode(operation.id, operation.description)}
                                            className="text-yellow-500 hover:text-yellow-700"
                                        >
                                            <Edit className="w-6 h-6" />
                                        </button>
                                        <button
                                            onClick={() => openDeleteModal(operation.id)}
                                            className="text-red-500 hover:text-red-700"
                                        >
                                            <Trash className="w-6 h-6" />
                                        </button>
                                    </>
                                )}
                            </div>
                        </li>
                    ))}
                </ul>
            </div>

            <DeleteModal
                isOpen={deleteModalOpen}
                onClose={closeDeleteModal}
                onDelete={handleDelete}
            />

            <MessageModal
                LeftButtonLabel="OK"
                text={messageText}
                visible={messageModalOpen}
                success={messageSuccess}
                onPressEvent={closeMessageModal}
            />
        </div>
    );
};

export default InterventionShow;
