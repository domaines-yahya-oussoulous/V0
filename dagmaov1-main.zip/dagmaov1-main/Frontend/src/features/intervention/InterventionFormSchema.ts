import * as z from 'zod';

// Schema for an individual operation
const operationSchema = z.object({
    description: z.string().min(1, "Description is required.") // Description must be non-empty if the field is present
});

// Schema for the intervention form
export const interventionFormSchema = z.object({
    name: z.string().nonempty("Name is required."), // Name is always required
    operations: z.array(operationSchema).optional() // Operations can be empty initially, but will be validated if present
        .refine(data => data.length > 0 || data.every(op => op.description.trim().length > 0), {
            message: "At least one operation with a description is required."
        })
});

// Default values for the form
export const interventionDefaultValues = {
    name: "",
    operations: [] // Initialize with an empty array
};
