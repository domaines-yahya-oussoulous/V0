import axios from 'axios';
import {InterventionType} from "@/types/InterventionType.ts";

export const createIntervention = async (data: InterventionType) => {
    try {
        const response = await axios.post(`intervention/add`, data, {
            headers: {
                'Content-Type': 'application/ld+json',
            },
        });
        return response.data;
    } catch (error) {
        // Handle error accordingly
        throw error;
    }
};
