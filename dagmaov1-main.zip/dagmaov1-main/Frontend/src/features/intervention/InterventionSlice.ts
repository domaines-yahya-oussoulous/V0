import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import { InterventionType } from "@/types/InterventionType.ts";
import { handleAxiosError } from "@/utils/handlers/handleAxiosError.ts";

interface InterventionState {
    interventions: InterventionType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: InterventionState = {
    interventions: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const interventionSlice = createSlice({
    name: 'interventions',
    initialState,
    reducers: {
        fetchInterventionsStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchInterventionsSuccess(state, action: PayloadAction<{ interventions: InterventionType[], total: number }>) {
            state.loading = false;
            state.interventions = action.payload.interventions;
            state.total = action.payload.total;
        },
        fetchInterventionsFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deleteInterventionStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deleteInterventionSuccess(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = null;
            state.interventions = state.interventions.filter(intervention => intervention.id !== action.payload);
        },
        deleteInterventionFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchInterventionsStart,
    fetchInterventionsSuccess,
    fetchInterventionsFailure,
    setPage,
    setSearchTerm,
    deleteInterventionStart,
    deleteInterventionSuccess,
    deleteInterventionFailure,
} = interventionSlice.actions;

export const fetchInterventions = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchInterventionsStart());

        // Construct the URL based on the presence of searchTerm
        let url = `interventions?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&name=${searchTerm}`;
        }
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const interventions = response.data['hydra:member'];
        dispatch(fetchInterventionsSuccess({ interventions, total: totalItems }));
    } catch (error) {
        dispatch(fetchInterventionsFailure(handleAxiosError(error)));
    }
};

export const deleteIntervention = (id: string): AppThunk => async (dispatch) => {
    try {
        dispatch(deleteInterventionStart());
        await axios.delete(`interventions/${id}`);
        dispatch(deleteInterventionSuccess(id));
    } catch (error) {
        dispatch(deleteInterventionFailure(handleAxiosError(error)));
    }
};

export default interventionSlice.reducer;
