import React, { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button.tsx';
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage
} from '@/components/ui/form.tsx';
import { Toaster } from '@/components/ui/toaster.tsx';
import { Input } from '@/components/ui/input.tsx';
import MessageModal from '@/components/messagemodal/MessageModal.tsx';
import { useNavigate } from 'react-router-dom';
import Loader from '@/components/loader/Loader.tsx';
import {
    interventionDefaultValues,
    interventionFormSchema,
} from '@/features/intervention/InterventionFormSchema.ts';
import { createIntervention } from '@/features/intervention/InterventionAPI.ts';
import { Textarea } from '@/components/ui/textarea.tsx';

const InterventionAdd: React.FC = () => {
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [modalMessage, setModalMessage] = useState('');
    const [modalSuccess, setModalSuccess] = useState(false);
    const navigate = useNavigate();

    const form = useForm<z.infer<typeof interventionFormSchema>>({
        resolver: zodResolver(interventionFormSchema),
        defaultValues: interventionDefaultValues
    });

    const { control, handleSubmit, reset } = form;
    const { fields, append, remove } = useFieldArray({
        control,
        name: 'operations'
    });

    const handleSubmitForm = async (data: z.infer<typeof interventionFormSchema>) => {
        setLoading(true);
        const requestData = {
            name: data.name,
            operations: data.operations
        };

        try {
            await createIntervention(requestData);
            setModalSuccess(true);
            setModalMessage('Intervention has been created successfully.');
            setModalVisible(true);
            reset();
        } catch (error) {
            console.error('Error adding intervention:', error);
            setModalSuccess(false);
            setModalMessage(error.response?.data?.detail || 'An unknown error occurred');
            setModalVisible(true);
        } finally {
            setLoading(false);
        }
    };

    const handleModalClose = () => {
        setModalVisible(false);
        if (modalSuccess) {
            navigate('/intervention');
        }
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    return (
        <>
            <div className={`mt-12 sm:mt-24 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
                <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Add Intervention</h2>
                <Form {...form}>
                    <form className="m-4 sm:m-12" onSubmit={handleSubmit(handleSubmitForm)}>
                        <div className="max-w-7xl mx-auto p-4 sm:flex sm:justify-between sm:space-x-8">
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2 mb-4 sm:mb-0 mx-auto">
                                <FormField
                                    control={form.control}
                                    name="name"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Name</FormLabel>
                                            <FormControl>
                                                <Input
                                                    placeholder="Intervention name"
                                                    {...field}
                                                />
                                            </FormControl>
                                            <FormDescription>
                                                This is the name of the intervention.
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />

                                {fields.map((field, index) => (
                                    <FormField
                                        key={field.id}
                                        control={form.control}
                                        name={`operations.${index}.description`}
                                        render={({ field: { value, onChange, ...fieldProps } }) => (
                                            <FormItem>
                                                <FormLabel>Description</FormLabel>
                                                <FormControl>
                                                    <Textarea
                                                        placeholder="Operation description"
                                                        className="resize-none"
                                                        {...fieldProps}
                                                        value={value}
                                                        onChange={(event) =>
                                                            onChange(event.target.value)
                                                        }
                                                    />
                                                </FormControl>
                                                <FormDescription>
                                                    Description of the operation.
                                                </FormDescription>
                                                <FormMessage />
                                                <Button
                                                    variant="destructive"
                                                    onClick={() => remove(index)}
                                                >
                                                    Remove
                                                </Button>
                                            </FormItem>
                                        )}
                                    />
                                ))}
                                <Button
                                    type="button"
                                    onClick={() => append({ description: '' })}
                                    className="mt-4"
                                >
                                    Add Operation
                                </Button>
                            </div>
                        </div>
                        <div className="flex justify-center mt-6">
                            <Button type="submit" className="w-full sm:w-auto px-6 py-3 text-lg">Submit</Button>
                        </div>
                    </form>
                </Form>
            </div>
            <Toaster />
            <MessageModal
                visible={modalVisible}
                text={modalMessage}
                success={modalSuccess}
                onPressEvent={handleModalClose}
                LeftButtonLabel={"ok"}
            />
        </>
    );
};

export default InterventionAdd;
