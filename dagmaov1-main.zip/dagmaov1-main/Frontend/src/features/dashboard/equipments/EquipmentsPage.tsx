import React from 'react';
import {Tractor} from 'lucide-react';

const EquipmentsPage: React.FC = () => {
    return (
        <div className="p-6">
            <div className="flex items-center mb-6">
                <Tractor className="w-8 h-8 text-blue-600 mr-3" />
                <h1 className="text-3xl font-bold text-gray-900">Equipments</h1>
            </div>
            <div className="bg-yellow-100 p-4 rounded-lg shadow-md">
                <div className="flex items-center text-yellow-700">
                    <svg className="w-6 h-6 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h1m0-4h-1V6h1m7 6H4a1 1 0 00-1 1v8a1 1 0 001 1h16a1 1 0 001-1v-8a1 1 0 00-1-1z"></path>
                    </svg>
                    <p className="text-base font-medium">
                        This page is not ready yet and is still in development.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default EquipmentsPage;
