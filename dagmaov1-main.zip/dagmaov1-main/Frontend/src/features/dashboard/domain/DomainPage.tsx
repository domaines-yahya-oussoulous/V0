import React, { useState, useEffect } from 'react';
import axios from 'axios';
import DashboardCard from "@/components/dashboardcard/DashboardCard.tsx";
import images from "@/assets/images";
import Loader from "@/components/loader/Loader.tsx";
import { Toaster } from "@/components/ui/toaster.tsx";
import { toast } from "@/components/ui/use-toast.ts";

interface DomainPageProps {
    farmsId: number[];
}

interface EquipmentCategory {
    categoryId: number;
    categoryName: string;
    categoryImage: string | null;
    totalEquipments: number;
    equipmentsInMaintenance: string;
    availableEquipments: string;
}

interface MaintenanceCount {
    state: string;
    count: number;
}

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + "equipment-category-images/";

const DomainPage: React.FC<DomainPageProps> = ({ farmsId }) => {
    const [equipmentCategories, setEquipmentCategories] = useState<EquipmentCategory[]>([]);
    const [interventionCounts, setInterventionCounts] = useState<Record<string, number>>({});
    const [loading, setLoading] = useState<boolean>(true);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const ids = farmsId.join(',');

                // Fetching equipment categories and all intervention counts in parallel
                const [categoriesResponse, correctiveMaintenanceResponse, preventiveMaintenanceResponse] = await Promise.all([
                    axios.get(`maintenance-ratio-by-category/${ids}`),
                    axios.get(`count-corrective-maintenances-by-farm/${ids}`),
                    axios.get(`count-preventive-maintenances-by-farm/${ids}`)
                ]);

                // Process corrective and preventive maintenance counts
                const correctiveMaintenanceCounts: MaintenanceCount[] = correctiveMaintenanceResponse.data['hydra:member'];
                const preventiveMaintenanceCounts: MaintenanceCount[] = preventiveMaintenanceResponse.data['hydra:member'];

                const aggregateInterventionCounts = (counts: MaintenanceCount[], prefix: string) =>
                    counts.reduce((acc, { state, count }) => {
                        acc[`${prefix}_${state}`] = count;
                        return acc;
                    }, {} as Record<string, number>);

                // Combine counts for both preventive and corrective interventions
                const correctiveCounts = aggregateInterventionCounts(correctiveMaintenanceCounts, "corrective");
                const preventiveCounts = aggregateInterventionCounts(preventiveMaintenanceCounts, "preventive");

                setEquipmentCategories(categoriesResponse.data['hydra:member']);
                setInterventionCounts({ ...correctiveCounts, ...preventiveCounts });
            } catch (error) {
                toast({
                    title: "Error",
                    description: 'Failed to fetch dashboard elements.',
                    variant: "destructive",
                });
                console.error('Error fetching data:', error);
            } finally {
                setLoading(false);
            }
        };

        if (farmsId.length > 0) {
            fetchData();
        } else {
            setLoading(false);
        }
    }, [farmsId]);

    const calculateProgress = (totalEquipments: number, availableEquipments: number) => {
        return totalEquipments === 0 ? 0 : Math.round((availableEquipments / totalEquipments) * 100);
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    return (
        <>
            <div className="p-4">
                <h1 className="mb-6 text-2xl font-extrabold text-gray-900 dark:text-white text-center">
                    <span className="text-transparent bg-clip-text bg-gradient-to-r to-yellow-600 from-yellow-500">
                        Domains Overview
                    </span>
                </h1>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Equipment Categories Section */}
                    <div>
                        <h2 className="mb-3 text-lg font-extrabold text-gray-900 dark:text-white md:text-xl lg:text-xl text-center">
                            <span className="text-transparent bg-clip-text bg-gradient-to-r to-green-800 from-blue-900">
                                Equipment Categories
                            </span>
                        </h2>
                        <div className="grid grid-cols-1 gap-4">
                            {equipmentCategories.length > 0 ? (
                                equipmentCategories.map((category) => (
                                    <DashboardCard
                                        key={category.categoryId}
                                        imageSrc={category.categoryImage ? `${IMAGE_BASE_URL}${category.categoryImage}` : images.excavatorLogo}
                                        title={category.categoryName}
                                        progress={calculateProgress(category.totalEquipments, parseInt(category.availableEquipments))}
                                        badgeValue={`${category.availableEquipments}/${category.totalEquipments}`}
                                    />
                                ))
                            ) : (
                                <div className="bg-white shadow-sm rounded-lg p-4 text-center">
                                    <p className="text-sm font-semibold text-gray-500">No Equipment Categories Available</p>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Interventions Section */}
                    <div>
                        <h2 className="mb-3 text-lg font-extrabold text-gray-900 dark:text-white md:text-xl lg:text-xl text-center">
                            <span className="text-transparent bg-clip-text bg-gradient-to-r to-green-800 from-blue-900">
                                Interventions
                            </span>
                        </h2>
                        <div className="grid grid-cols-1 gap-4">
                            <DashboardCard
                                imageSrc={images.plannedPreventiveInterventions}
                                title={"Planned preventive interventions"}
                                badgeValue={`${interventionCounts.preventive_PLANNED || 0}`}
                            />
                            <DashboardCard
                                imageSrc={images.inProgressPreventiveMaintenanceInterventions}
                                title={"Preventive interventions in progress"}
                                badgeValue={`${interventionCounts.preventive_IN_PROGRESS || 0}`}
                            />
                            <DashboardCard
                                imageSrc={images.completedPreventiveMaintenanceInterventions}
                                title={"Completed preventive interventions"}
                                badgeValue={`${interventionCounts.preventive_COMPLETED || 0}`}
                            />
                            <DashboardCard
                                imageSrc={images.inProgressCorrectiveMaintenanceInterventions}
                                title={"Corrective interventions in progress"}
                                badgeValue={`${interventionCounts.corrective_IN_PROGRESS || 0}`}
                            />
                            <DashboardCard
                                imageSrc={images.availabilityRate}
                                title={"Availability rate"}
                                badgeValue={`?`}
                            />
                            <DashboardCard
                                imageSrc={images.costOfMaterialsAndConsumables}
                                title={"Cost of materials and consumables"}
                                badgeValue={`?`}
                            />
                        </div>
                    </div>
                </div>
            </div>
            <Toaster />
        </>
    );
};

export default DomainPage;
