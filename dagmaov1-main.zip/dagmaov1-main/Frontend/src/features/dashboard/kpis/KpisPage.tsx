import React from 'react';
import DashboardCard from "@/components/dashboardcard/DashboardCard.tsx";
import {Bar, BarChart, CartesianGrid, XAxis} from "recharts"
import {ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent} from "@/components/ui/chart"

const kpiData = [
    {
        title: 'Planned Interventions',
        progress: 50,
        badgeValue: '3/6'
    },
    {
        title: 'In_progress Interventions',
        progress: 83,
        badgeValue: '5/6'
    },
    {
        title: 'Completed Interventions',
        progress: 100,
        badgeValue: '6/6'
    },
    {
        title: 'Non_validated Interventions',
        progress: 17,
        badgeValue: '1/6'
    },
    {
        title: 'Waiting_for_validation Interventions',
        progress: 67,
        badgeValue: '4/6'
    },
    {
        title: 'Planned Interventions',
        progress: 33,
        badgeValue: '2/6'
    },
    {
        title: 'In_progress Interventions',
        progress: 83,
        badgeValue: '5/6'
    },
    {
        title: 'Waiting_for_validation Interventions',
        progress: 67,
        badgeValue: '4/6'
    },
    {
        title: 'Non_validated Interventions',
        progress: 50,
        badgeValue: '3/6'
    }
];
const chartData = [
    { month: "January", desktop: 186, mobile: 80 },
    { month: "February", desktop: 305, mobile: 200 },
    { month: "March", desktop: 237, mobile: 120 },
    { month: "April", desktop: 73, mobile: 190 },
    { month: "May", desktop: 209, mobile: 130 },
    { month: "June", desktop: 214, mobile: 140 },
]

const chartConfig = {
    desktop: {
        label: "Desktop",
        color: "#2563eb",
    },
    mobile: {
        label: "Mobile",
        color: "#60a5fa",
    },
} satisfies ChartConfig

const KpisPage: React.FC = () => {
    return (
        <div className="p-4">
            <h1 className="mb-6 text-2xl font-extrabold text-gray-900 dark:text-white text-center">
    <span className="text-transparent bg-clip-text bg-gradient-to-r to-yellow-600 from-yellow-500">
        Kpis Overview
    </span>
            </h1>
            <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {kpiData.map((kpi, index) => (
                    <DashboardCard
                        key={index}
                        title={kpi.title}
                        progress={kpi.progress}
                        badgeValue={kpi.badgeValue}
                    />
                ))}
            </div>
            <div className="mt-12">
                <h1 className="mb-6 text-2xl font-extrabold text-gray-900 dark:text-white text-center">
    <span className="text-transparent bg-clip-text bg-gradient-to-r to-blue-600 from-blue-900">
        Charts
    </span>
                </h1>
                <div className="flex flex-col md:flex-row justify-around">
                    <div>
                        <ChartContainer config={chartConfig} className="h-[200px] w-full">
                            <BarChart accessibilityLayer data={chartData}>
                                <CartesianGrid vertical={false}/>
                                <XAxis
                                    dataKey="month"
                                    tickLine={false}
                                    tickMargin={10}
                                    axisLine={false}
                                    tickFormatter={(value) => value.slice(0, 3)}
                                />
                                <ChartTooltip content={<ChartTooltipContent/>}/>
                                <Bar dataKey="desktop" fill="var(--color-desktop)" radius={4}/>
                                <Bar dataKey="mobile" fill="var(--color-mobile)" radius={4}/>
                            </BarChart>
                        </ChartContainer>
                    </div>
                    <div>
                        <ChartContainer config={chartConfig} className="h-[200px] w-full">
                            <BarChart accessibilityLayer data={chartData}>
                                <CartesianGrid vertical={false}/>
                                <XAxis
                                    dataKey="month"
                                    tickLine={false}
                                    tickMargin={10}
                                    axisLine={false}
                                    tickFormatter={(value) => value.slice(0, 3)}
                                />
                                <ChartTooltip content={<ChartTooltipContent/>}/>
                                <Bar dataKey="desktop" fill="var(--color-desktop)" radius={4}/>
                                <Bar dataKey="mobile" fill="var(--color-mobile)" radius={4}/>
                            </BarChart>
                        </ChartContainer>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default KpisPage;
