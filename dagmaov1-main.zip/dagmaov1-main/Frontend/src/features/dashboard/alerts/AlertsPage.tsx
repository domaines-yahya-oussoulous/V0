import React from 'react';
import { AlertCircle, Info, CheckCircle, Bell, Lightbulb, Siren } from 'lucide-react';

type CardColor = 'red' | 'yellow' | 'blue';

const Card: React.FC<{ color: CardColor; text: string; icon: React.ReactNode }> = ({ color, text, icon }) => {
    const colorClasses: Record<CardColor, string> = {
        red: 'bg-gradient-to-r from-red-400 via-red-500 to-red-600 text-white',
        yellow: 'bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 text-white',
        blue: 'bg-gradient-to-r from-blue-400 via-blue-500 to-blue-600 text-white',
    };

    return (
        <div className={`p-4 mb-4 rounded-lg shadow-md flex items-center space-x-3 ${colorClasses[color]} transform hover:scale-105 transition-transform duration-200`}>
            <div className="text-xl">{icon}</div>
            <p className="text-base font-medium">{text}</p>
        </div>
    );
};

// AlertsPage Component
const AlertsPage: React.FC = () => {
    return (
        <div className="p-6">
            <div className="flex flex-col md:flex-row space-y-6 md:space-y-0 md:space-x-6">
                {/* Alerts Column */}
                <div className="flex-1 text-center border-b md:border-r border-gray-300 md:pr-6 md:border-b-0">
                    <h1 className="text-2xl font-extrabold mb-4 flex items-center justify-center text-red-600">
                        <Siren className="w-6 h-6 mr-2 animate-bounce" />
                        Alerts
                    </h1>
                    <Card color="red" text="This is an urgent alert." icon={<AlertCircle className="w-5 h-5" />} />
                    <Card color="yellow" text="This is a warning alert." icon={<Bell className="w-5 h-5" />} />
                </div>

                {/* Information Column */}
                <div className="flex-1 text-center md:pl-6">
                    <h1 className="text-2xl font-extrabold mb-4 flex items-center justify-center text-blue-600">
                        <Info className="w-6 h-6 mr-2 animate-bounce" />
                        Information
                    </h1>
                    <Card color="blue" text="This is some informational text." icon={<Lightbulb className="w-5 h-5" />} />
                    <Card color="blue" text="Another piece of information." icon={<CheckCircle className="w-5 h-5" />} />
                </div>
            </div>
        </div>
    );
};

export default AlertsPage;
