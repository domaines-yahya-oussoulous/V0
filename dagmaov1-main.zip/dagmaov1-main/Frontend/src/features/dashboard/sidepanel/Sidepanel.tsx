// src/features/dashboard/sidepanel/Sidepanel.tsx
import React from 'react';
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Label } from "@/components/ui/label.tsx";
import { citiesExample } from "@/data/cities.ts";

type SidePanelProps = {};

const Sidepanel: React.FC<SidePanelProps> = () => {
    return (
        <div className="bg-muted overflow-auto flex flex-col w-full max-w-[300px]"> {/* Ensure width is correct */}
            <Input
                type="text"
                placeholder="Rechercher"
                className="mt-2 w-56 rounded-2xl self-center"
            />
            <div className="p-5 flex flex-col space-y-4">
                <div className="flex py-2 pr-12 items-center space-x-2 bg-white">
                    <Checkbox id="select-all" />
                    <Label htmlFor="select-all" className="font-bold">Sélectionner tous</Label>
                </div>
                {citiesExample.map((item) => (
                    <div key={item.id} className="flex py-2 pr-12 items-center space-x-2 bg-white">
                        <Checkbox id={item.id} />
                        <Label htmlFor={item.id}>{item.label}</Label>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Sidepanel;
