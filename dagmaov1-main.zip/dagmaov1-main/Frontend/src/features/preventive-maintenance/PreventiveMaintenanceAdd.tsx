import React, {useEffect, useState} from 'react';
import {useForm, useFieldArray} from "react-hook-form";
import {zodResolver} from "@hookform/resolvers/zod";
import {toast} from "@/components/ui/use-toast.ts";
import {Button} from "@/components/ui/button.tsx";
import * as z from 'zod';
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage
} from "@/components/ui/form.tsx";
import {Toaster} from "@/components/ui/toaster.tsx";
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from "@/components/ui/select.tsx";
import MessageModal from "@/components/messagemodal/MessageModal.tsx";
import {useNavigate} from "react-router-dom";
import {
    preventiveMaintenanceDefaultValues,
    preventiveMaintenanceFormSchema
} from "@/features/preventive-maintenance/PreventiveMaintenanceFormSchema.ts";
import {
    fetchFarms,
    fetchEquipmentByFarm,
    fetchSparePartsByFarm,
    createPreventiveMaintenance, fetchTechniciansByFarm, fetchInterventionsByEquipment
} from "@/features/preventive-maintenance/PreventiveMaintenanceApi.ts";
import Loader from "@/components/loader/Loader.tsx";
import {Dropzone, FileMosaic} from "@dropzone-ui/react";
import MultipleSelector from "@/components/multipleselector/MultipleSelector.tsx";
import FormParameterField from "@/components/formparameterfield/FormParameterField.tsx";

const PreventiveMaintenanceAdd: React.FC = () => {
    const [farmList, setFarmList] = useState([]);
    const [equipmentList, setEquipmentList] = useState([]);
    const [sparePartsList, setSparePartsList] = useState([]);
    const [techniciansList, setTechniciansList] = useState([]);
    const [filteredEquipmentList, setFilteredEquipmentList] = useState([]);
    const [interventionsList, setInterventionsList] = useState([]);
    const [filteredSparePartsList, setFilteredSparePartsList] = useState([]);
    const [modalVisible, setModalVisible] = useState(false);
    const [modalMessage, setModalMessage] = useState('');
    const [modalSuccess, setModalSuccess] = useState(false);
    const [selectedFarm, setSelectedFarm] = useState(null);
    const [loading, setLoading] = useState(false);
    const [files, setFiles] = useState([]);

    const navigate = useNavigate();
    const form = useForm<z.infer<typeof preventiveMaintenanceFormSchema>>({
        resolver: zodResolver(preventiveMaintenanceFormSchema),
        defaultValues: preventiveMaintenanceDefaultValues
    });

    const {fields, append, remove} = useFieldArray({
        control: form.control,
        name: "sparePartPreventiveMaintenanceQuantities"
    });

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const farms = await fetchFarms();
                setFarmList(farms);
            } catch (error) {
                console.error("Error fetching farms:", error);
                toast({
                    title: "Error",
                    description: 'Failed to fetch farms.',
                    variant: "destructive",
                });
            } finally {
                setLoading(false); // End loading
            }
        };

        fetchData();
    }, []);

    const handleFarmChange = async (farmId: string) => {
        setSelectedFarm(farmId);
        form.setValue('intervention', ''); // Clear the intervention field
        form.setValue('equipmentToMaintain', ''); // Clear the equipment field
        form.setValue('sparePartPreventiveMaintenanceQuantities', [])
        setInterventionsList([]); // Clear the interventions list
        setFilteredEquipmentList([]); // Clear the equipment list
        try {
            const [equipment, spareParts, technicians] = await Promise.all([
                fetchEquipmentByFarm(farmId),
                fetchSparePartsByFarm(farmId),
                fetchTechniciansByFarm(farmId)
            ]);
            setFilteredEquipmentList(equipment);
            setFilteredSparePartsList(spareParts);
            setTechniciansList(technicians);
        } catch (error) {
            console.error("Error fetching equipment, spare parts, or technicians by farm:", error);
            toast({
                title: "Error",
                description: 'Failed to fetch equipment, spare parts, or technicians by farm.',
                variant: "destructive",
            });
        }
    };
    const handleEquipmentChange = async (equipmentId: string) => {
        form.setValue('intervention', ''); // Clear the intervention field

        try {
            const interventions = await fetchInterventionsByEquipment(equipmentId);
            setInterventionsList(interventions); // Update the interventions list based on the selected equipment
        } catch (error) {
            console.error("Error fetching interventions:", error);
            toast({
                title: "Error",
                description: 'Failed to fetch interventions.',
                variant: "destructive",
            });
        }
    };
    const handleSubmit = async (data: z.infer<typeof preventiveMaintenanceFormSchema>) => {
        setLoading(true);
        const formData = new FormData();
        console.warn(data.intervention)
        formData.append('intervention', data.intervention);
        formData.append('interventionDate', data.interventionDate);
        formData.append('interventionEstimatedDuration', data.interventionEstimatedDuration.toString());
        formData.append('interventionEstimatedDurationUnit', data.interventionEstimatedDurationUnit);
        formData.append('maintenanceFrequency', data.maintenanceFrequency);
        formData.append('maintenanceFrequencyCount', data.maintenanceFrequencyCount);
        const personnelInChargevalues = data.PersonnelInCharge.map(item => item.value);
        const personnelInChargeJson = JSON.stringify(personnelInChargevalues);
        //console.log(personnelInChargevalues)
        formData.append("PersonnelInCharge", personnelInChargeJson);

        if (data.equipmentToMaintain) {
            formData.append('equipmentToMaintain', data.equipmentToMaintain);
        }

        const sparePartsQuantities = data.sparePartPreventiveMaintenanceQuantities.map(item => ({
            SparePart: item.SparePart,
            quantity: item.quantity
        }));
        formData.append('sparePartPreventiveMaintenanceQuantities', JSON.stringify(sparePartsQuantities));

        files.forEach(file => {
            formData.append('imageFiles[]', file.file);
        });

        try {
            await createPreventiveMaintenance(formData);
            setModalSuccess(true);
            setModalMessage('Preventive maintenance has been created successfully.');
            setModalVisible(true);
            form.reset();
            setFiles([]);
        } catch (error) {
            console.error("Error adding preventive maintenance:", error);
            setModalSuccess(false);
            setModalMessage(error.response?.data?.detail || 'An unknown error occurred');
            setModalVisible(true);
        } finally {
            setLoading(false);
        }
    };

    const handleModalClose = () => {
        setModalVisible(false);
        if (modalSuccess) {
            navigate('/preventive-maintenance');
        }
    };

    if (loading) {
        return <Loader loading={loading}/>;
    }

    return (
        <>
            <div className={`mt-12 sm:mt-24 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
                <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Add Preventive
                    Maintenance</h2>
                <Form {...form}>
                    <form className="m-4 sm:m-12" onSubmit={form.handleSubmit(handleSubmit)}>
                        <div className="max-w-7xl mx-auto p-4 sm:flex sm:justify-between sm:space-x-8">
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2 mb-4 sm:mb-0">
                                <FormField
                                    control={form.control}
                                    name="farm"
                                    render={({field}) => (
                                        <FormItem>
                                            <FormLabel required>Farm</FormLabel>
                                            <FormControl>
                                                <Select onValueChange={value => {
                                                    field.onChange(value);
                                                    handleFarmChange(value);
                                                }} defaultValue={field.value}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select farm"/>
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {farmList.map(farm => (
                                                            <SelectItem key={farm.id} value={farm.id.toString()}>
                                                                {farm.name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                            <FormDescription>
                                                Select the farm to see the equipment and spare parts.
                                            </FormDescription>
                                            <FormMessage/>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="equipmentToMaintain"
                                    render={({field}) => (
                                        <FormItem>
                                            <FormLabel required>Equipment to Maintain</FormLabel>
                                            <FormControl>
                                                <Select onValueChange={value => {
                                                    const equipmentId = value.split('/').pop();
                                                    field.onChange(value);
                                                    handleEquipmentChange(equipmentId);
                                                }} defaultValue={field.value}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select equipment"/>
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {filteredEquipmentList.map(equipment => (
                                                            <SelectItem key={equipment["@id"]} value={equipment["@id"]}>
                                                                {equipment.name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                            <FormDescription>
                                                Select the equipment to be maintained.
                                            </FormDescription>
                                            <FormMessage/>
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="intervention"
                                    render={({field}) => (
                                        <FormItem>
                                            <FormLabel required>Interventions</FormLabel>
                                            <FormControl>
                                                <Select
                                                    onValueChange={value => {
                                                        //const formattedValue = `api/interventions/${value}`;
                                                        field.onChange(value);
                                                    }}
                                                    //onValueChange={field.onChange}
                                                    defaultValue={field.value}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select intervention"/>
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {interventionsList.map(intervention => (
                                                            <SelectItem key={intervention.id}
                                                                        value={intervention.apiId}>
                                                                {intervention.name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                            <FormDescription>
                                                Select intervention type.
                                            </FormDescription>
                                            <FormMessage/>
                                        </FormItem>
                                    )}
                                />
                                <div className={"flex justify-between"}>
                                    <div className={"w-6/12"}>
                                        <FormField
                                            control={form.control}
                                            name="maintenanceFrequency"
                                            render={({field}) => (
                                                <FormItem>
                                                    <FormLabel required>Maintenance Frequency</FormLabel>
                                                    <FormControl>
                                                        <Select onValueChange={field.onChange}
                                                                defaultValue={field.value}>
                                                            <SelectTrigger>
                                                                <SelectValue placeholder="Select frequency"/>
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="Daily">Daily</SelectItem>
                                                                <SelectItem value="Weekly">Weekly</SelectItem>
                                                                <SelectItem value="Monthly">Monthly</SelectItem>
                                                                <SelectItem value="Quarterly">Quarterly</SelectItem>
                                                                <SelectItem value="Annually">Annually</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    </FormControl>
                                                    <FormDescription>
                                                        Select Maintenance Frequency.
                                                    </FormDescription>
                                                    <FormMessage/>
                                                </FormItem>
                                            )}
                                        />
                                    </div>
                                    <div className={"w-5/12"}>
                                        <FormParameterField
                                            control={form.control}
                                            name="maintenanceFrequencyCount"
                                            label="Maintenance Frequency Count"
                                            placeholder="Maintenance Frequency Count"
                                            type="number"
                                            description="Select Maintenance Frequency Count."
                                            required
                                        />
                                    </div>
                                </div>
                                <FormField
                                    control={form.control}
                                    name="imageFiles"
                                    render={({field}) => (
                                        <FormItem>
                                            <FormLabel>Images</FormLabel>
                                            <FormControl>
                                                <Dropzone onChange={setFiles} value={files} accept="image/*"
                                                          label="drop your images here" maxFiles={20}>
                                                    {files.map((file, index) => (
                                                        <FileMosaic key={file.file?.name || index} {...file} preview/>
                                                    ))}
                                                </Dropzone>
                                            </FormControl>
                                            <FormMessage>
                                                {form.formState.errors?.imageFiles && (
                                                    <span>{form.formState.errors.imageFiles.message}</span>
                                                )}
                                            </FormMessage>
                                        </FormItem>
                                    )}
                                />
                            </div>
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2">

                                <div className="flex flex-col space-y-4">
                                    <FormParameterField
                                        control={form.control}
                                        name="interventionDate"
                                        label="Intervention Date"
                                        placeholder="Intervention date"
                                        type="date"
                                        description="Date of the intervention."
                                        required
                                    />
                                    <div className={"flex justify-between"}>
                                        <div className={"w-6/12"}>
                                            <FormParameterField
                                                control={form.control}
                                                name="interventionEstimatedDuration"
                                                label="Estimated Duration"
                                                placeholder="Estimated duration"
                                                type="number"
                                                description="Estimated duration of the intervention."
                                                required
                                            />
                                        </div>
                                        <div className={"w-5/12"}>
                                            <FormField
                                                control={form.control}
                                                name="interventionEstimatedDurationUnit"
                                                render={({field}) => (
                                                    <FormItem>
                                                        <FormLabel required>Estimated Duration Unit</FormLabel>
                                                        <FormControl>
                                                            <Select onValueChange={field.onChange}
                                                                    defaultValue={field.value}>
                                                                <SelectTrigger>
                                                                    <SelectValue placeholder="Select unit"/>
                                                                </SelectTrigger>
                                                                <SelectContent>
                                                                    <SelectItem value="hours">Hours</SelectItem>
                                                                    <SelectItem value="days">Days</SelectItem>
                                                                    <SelectItem value="months">Months</SelectItem>
                                                                </SelectContent>
                                                            </Select>
                                                        </FormControl>
                                                        <FormDescription>Select Estimated Duration Unit.</FormDescription>
                                                        <FormMessage/>
                                                    </FormItem>
                                                )}
                                            />
                                        </div>
                                    </div>
                                    <FormLabel>Spare Parts Quantities</FormLabel>
                                    {fields.map((item, index) => (
                                        <div key={item.id} className="flex space-x-4">
                                            <div className="w-8/12">
                                                <FormField
                                                    control={form.control}
                                                    name={`sparePartPreventiveMaintenanceQuantities.${index}.SparePart`}
                                                    render={({field}) => (
                                                        <FormItem>
                                                            <FormControl>
                                                                <Select onValueChange={field.onChange}
                                                                        defaultValue={field.value}>
                                                                    <SelectTrigger>
                                                                        <SelectValue placeholder="Select spare part"/>
                                                                    </SelectTrigger>
                                                                    <SelectContent>
                                                                        {filteredSparePartsList.map(sparePart => (
                                                                            <SelectItem key={sparePart["@id"]}
                                                                                        value={sparePart["@id"]}>
                                                                                {sparePart.name}
                                                                            </SelectItem>
                                                                        ))}
                                                                    </SelectContent>
                                                                </Select>
                                                            </FormControl>
                                                            <FormDescription>
                                                                Select Spare Part.
                                                            </FormDescription>
                                                            <FormMessage/>
                                                        </FormItem>
                                                    )}
                                                />
                                            </div>
                                            <div className="3/12">
                                                <FormParameterField
                                                    control={form.control}
                                                    name={`sparePartPreventiveMaintenanceQuantities.${index}.quantity`}
                                                    placeholder="Quantity"
                                                    type="number"
                                                    description="Select Spare Part Quantity."
                                                />
                                            </div>
                                            <div className="w-12/12">
                                                <Button type="button" variant={"destructive"}
                                                        onClick={() => remove(index)}>Remove</Button>
                                            </div>
                                        </div>
                                    ))}
                                    <Button type="button" onClick={() => append({SparePart: "", quantity: 0})}>Add Spare
                                        Part</Button>
                                </div>
                                <FormField
                                    control={form.control}
                                    name="PersonnelInCharge"
                                    render={({field}) => (
                                        <FormItem>
                                            <FormLabel>Technicians</FormLabel>
                                            <FormControl>
                                                <MultipleSelector
                                                    {...field}
                                                    options={techniciansList.map((technician) => ({
                                                        value: `api/users/${technician.id}`,
                                                        label: `${technician.firstName} ${technician.lastName}`,
                                                    }))}
                                                    placeholder="Select techncians."
                                                    //onChange={(val)=> {console.log(val)}}
                                                    hideClearAllButton={true}
                                                    emptyIndicator={
                                                        <p className="text-center text-lg leading-10 text-gray-600 dark:text-gray-400">
                                                            no results found.
                                                        </p>
                                                    }
                                                />
                                            </FormControl>
                                            <FormDescription>Select technicians.</FormDescription>
                                            <FormMessage/>
                                        </FormItem>
                                    )}
                                />
                            </div>
                        </div>
                        <div className="flex justify-center mt-6">
                            <Button type="submit" className="w-full sm:w-auto px-6 py-3 text-lg">Submit</Button>
                        </div>
                    </form>
                </Form>
            </div>
            <Toaster/>
            <MessageModal
                visible={modalVisible}
                text={modalMessage}
                success={modalSuccess}
                onPressEvent={handleModalClose}
                LeftButtonLabel={"ok"}
            />
        </>
    );
};

export default PreventiveMaintenanceAdd;
