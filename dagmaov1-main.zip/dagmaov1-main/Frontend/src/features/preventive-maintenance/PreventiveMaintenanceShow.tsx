// PreventiveMaintenanceShow.tsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.tsx';
import { Toaster } from '@/components/ui/toaster.tsx';
import { PreventiveMaintenanceType } from '@/types/PreventiveMaintenanceType.ts';
import { Input } from '@/components/ui/input.tsx';
import MaintenanceStates from '@/components/maintenancestates/MaintenanceStates.tsx';
import { Button } from '@/components/ui/button.tsx';
import ConfirmationModal from "@/components/confirmationmodal/ConfirmationModal.tsx";
import DeleteModal from "@/components/deletemodal/DeleteModal.tsx";
import Loader from "@/components/loader/Loader.tsx";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { Badge } from "@/components/ui/badge.tsx";
import TasksModal from "@/components/tasksmodal/TasksModal.tsx";
import { format } from 'date-fns';

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + 'preventive-maintenance/';

const PreventiveMaintenanceShow: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const [preventiveMaintenance, setPreventiveMaintenance] = useState<PreventiveMaintenanceType | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [showModal, setShowModal] = useState<boolean>(false);
    const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
    const [showTasksModal, setShowTasksModal] = useState<boolean>(false);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchPreventiveMaintenance = async () => {
            try {
                const response = await axios.get(`/preventive-maintenance/${id}`);
                setPreventiveMaintenance(response.data);
                //console.log(response.data)
            } catch (error) {
                console.error('Error fetching preventive maintenance:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchPreventiveMaintenance();
    }, [id]);

    const handleDelete = async (e) => {
        setLoading(true)
        e.preventDefault();
        try {
            await axios.delete(`/preventive_maintenances/${id}`);
            navigate('/preventive-maintenance');
            // Optionally: Redirect to a different page or show a success message
        } catch (error) {
            console.error('Error deleting preventive maintenance:', error);
            // Optionally: Show an error message to the user
        } finally {
            setLoading(false);
        }
    };

    const handleTransition = async (newState: string, selectedTasks: string[] = [], description: string = '') => {
        try {
            setShowModal(false);
            setLoading(true);

            // Déterminer l'URL de changement d'état en fonction du nouvel état
            let stateChangeUrl = '';
            switch (newState) {
                case 'PLANNED':
                    stateChangeUrl = `/preventive-maintenances/${id}/validate`;
                    break;
                case 'IN_PROGRESS':
                    stateChangeUrl = `/preventive-maintenances/${id}/mark-as-in-progress`;
                    break;
                case 'COMPLETED':
                    stateChangeUrl = `/preventive-maintenances/${id}/mark-as-completed`;
                    break;
                case 'NON_VALIDATED':
                    stateChangeUrl = `/preventive-maintenances/${id}/invalidate`;
                    break;
                default:
                    throw new Error('Invalid state transition');
            }

            // Formater les tâches sélectionnées
            const formattedTasks = selectedTasks.map(taskId => `/api/operations/${taskId}`);

            // Si l'état est "IN_PROGRESS", envoyer la requête PATCH pour ajouter les tâches
            if (newState === 'IN_PROGRESS') {
                const response = await axios.patch(
                    `preventive-maintenances/${preventiveMaintenance?.id}/operations`,
                    { "operations": formattedTasks, tasksDescription: description },
                    {
                        headers: {
                            'Content-Type': 'application/merge-patch+json',
                        },
                    }
                );

                // Si l'ajout des tâches échoue, lever une erreur
                if (!(response.status >= 200 && response.status < 300)) {
                    throw new Error('Failed to add tasks');
                }
            }

            // Envoyer la requête PATCH pour changer l'état
            await axios.patch(
                stateChangeUrl,
                {},
                {
                    headers: {
                        'Content-Type': 'application/merge-patch+json',
                    },
                }
            );

            // Mettre à jour les données de maintenance préventive après le changement d'état
            const res = await axios.get(`/preventive-maintenance/${id}`);
            setPreventiveMaintenance(res.data);

            // Fermer le modal des tâches
            closeTasksModal();

        } catch (error) {
            console.error(`Error transitioning preventive maintenance to ${newState}:`, error);
            // Afficher un message d'erreur à l'utilisateur si nécessaire
        } finally {
            setLoading(false);
        }
    };

    const openModal = () => {
        setShowModal(true);
    };

    const closeModal = () => {
        setShowModal(false);
    };

    const openDeleteModal = (e) => {
        e.preventDefault();
        setShowDeleteModal(true);
    };

    const closeDeleteModal = () => {
        setShowDeleteModal(false);
    };
    const openTasksModal = () => {
        setShowTasksModal(true);
    };

    const closeTasksModal = () => {
        setShowTasksModal(false);
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    if (!preventiveMaintenance) {
        return <div>No preventive maintenance details available.</div>;
    }

    let additionalButton = null;
    let cancelButton = null;

    switch (preventiveMaintenance.state) {
        case 'WAITING_FOR_VALIDATION':
            additionalButton = (
                <Button onClick={(e) => { e.preventDefault(); openModal(); }} className="px-6 py-3">Mark as Planned</Button>
            );
            cancelButton = (
                <Button onClick={(e) => { e.preventDefault(); handleTransition('NON_VALIDATED'); }} className="px-6 py-3 ml-4 bg-red-600 text-white">Cancel</Button>
            );
            break;
        case 'PLANNED':
            additionalButton = (
                <Button onClick={(e) => { e.preventDefault(); openTasksModal(); }} className="px-6 py-3">Mark as In Progress</Button>
            );
            break;
        case 'IN_PROGRESS':
            additionalButton = (
                <Button onClick={(e) => { e.preventDefault(); openModal(); }} className="px-6 py-3">Mark as Completed</Button>
            );
            break;
        case 'COMPLETED':
            // No additional button needed
            break;
        default:
            break;
    }
    //console.log(preventiveMaintenance)
    return (
        <div className="mt-12 sm:mt-24">
            <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Preventive Maintenance Details</h2>
            <Card className="max-w-screen-xl mx-auto">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle>{preventiveMaintenance?.interventionDetails?.name}</CardTitle>
                        </div>
                        <div>
                            <Badge variant="secondary"><MaintenanceStates state={preventiveMaintenance.state} /></Badge>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <form className="m-4 sm:m-12">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:space-x-24">
                            <div className="flex flex-col justify-center items-center">
                                <label className="block text-sm font-medium text-gray-700">Intervention Date:</label>
                                <Input
                                    type="text"
                                    value={new Date(preventiveMaintenance.interventionDate).toLocaleDateString() || ''}
                                    className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                    readOnly
                                    disabled
                                />
                                <label className="block text-sm font-medium text-gray-700 mt-4">Estimated Duration:</label>
                                <Input
                                    type="text"
                                    value={`${preventiveMaintenance.interventionEstimatedDuration} ${preventiveMaintenance.interventionEstimatedDurationUnit}` || ''}
                                    className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                    readOnly
                                    disabled
                                />
                                <label className="block text-sm font-medium text-gray-700 mt-4">Maintenance Frequency:</label>
                                <Input
                                    type="text"
                                    value={preventiveMaintenance.maintenanceFrequency || ''}
                                    className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                    readOnly
                                    disabled
                                />
                                <label className="block text-sm font-medium text-gray-700 mt-4">Equipment to Maintain:</label>
                                <Input
                                    type="text"
                                    value={preventiveMaintenance.equipmentToMaintain.name || ''}
                                    className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                    readOnly
                                    disabled
                                />
                            </div>
                            <div className="flex flex-col justify-center items-center">
                                <div className="flex flex-col justify-center items-center">
                                    {/* ... other details */}
                                    <h3 className="font-bold mt-4">Personnel in Charge</h3>
                                    <ul className="mt-2">
                                        {preventiveMaintenance.PersonnelInCharge.map((person, index) => (
                                            <li key={index}>{`${person.firstName} ${person.lastName} - ${person.email}`}</li>
                                        ))}
                                    </ul>
                                </div>
                                {preventiveMaintenance.sparePartPreventiveMaintenanceQuantities.length > 0 && (
                                <>
                                    <h3 className="font-bold mt-2 sm:mt-0">Spare Parts Quantities</h3>
                                    <ul className="mt-2">
                                        {preventiveMaintenance.sparePartPreventiveMaintenanceQuantities.map((sparePart, index) => (
                                            <li key={index}>{`${sparePart.sparePartName}: ${sparePart.quantity}`}</li>
                                        ))}
                                    </ul>
                                </>
                                )}
                                {preventiveMaintenance.operationsDetails.length > 0 && (
                                    <>
                                        <h3 className="font-bold mt-4">Tasks</h3>
                                        <ul className="mt-2">
                                            {preventiveMaintenance.operationsDetails.map((task, index) => (
                                                <li key={index}>{task}</li>
                                            ))}
                                        </ul>
                                    </>
                                )}
                                {preventiveMaintenance.tasksDescription && (
                                    <div>
                                        <h3 className="font-bold mt-4">Description</h3>
                                        <p>{preventiveMaintenance.tasksDescription}</p>
                                    </div>
                                )}
                                {preventiveMaintenance.completionDate && (
                                    <div>
                                        <h3 className="font-bold mt-4">Completion Date</h3>
                                        <p>{format(new Date(preventiveMaintenance.completionDate), 'MMMM do, yyyy h:mm a')}</p>
                                    </div>
                                )}
                                {preventiveMaintenance.images.length > 0 && (
                                    <>
                                        <h3 className="font-bold mt-4">Images</h3>
                                        <div className="mt-2">
                                            <Carousel className="w-full max-w-xs">
                                                <CarouselContent>
                                                    {preventiveMaintenance.images.map((image, index) => (
                                                        <CarouselItem key={index}>
                                                            <div className="p-1">
                                                                <Card>
                                                                    <CardContent
                                                                        className="flex aspect-square items-center justify-center p-6">
                                                                        <img src={`${IMAGE_BASE_URL}${image.imageName}`}
                                                                             alt={`Maintenance Image ${index + 1}`}
                                                                             className="w-full h-auto"/>
                                                                    </CardContent>
                                                                </Card>
                                                            </div>
                                                        </CarouselItem>
                                                    ))}
                                                </CarouselContent>
                                                <CarouselPrevious type="button"/>
                                                <CarouselNext type="button"/>
                                            </Carousel>
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>
                        <div className="mt-4 sm:mt-10 flex justify-center">
                            {additionalButton}
                            {cancelButton}
                            <Button onClick={openDeleteModal} className="px-6 py-3 ml-4 bg-red-600 text-white">Delete</Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
            <Toaster />
            <ConfirmationModal
                isOpen={showModal}
                onClose={closeModal}
                onConfirm={() => {
                    const newState = preventiveMaintenance.state === 'WAITING_FOR_VALIDATION'
                        ? 'PLANNED'
                        : preventiveMaintenance.state === 'PLANNED'
                            ? 'IN_PROGRESS'
                            : preventiveMaintenance.state === 'IN_PROGRESS'
                                ? 'COMPLETED'
                                : '';
                    handleTransition(newState);
                }}
                text={`Are you sure you want to mark this preventive maintenance as ${
                    preventiveMaintenance.state === 'WAITING_FOR_VALIDATION'
                        ? 'Planned'
                        : preventiveMaintenance.state === 'PLANNED'
                            ? 'In Progress'
                            : preventiveMaintenance.state === 'IN_PROGRESS'
                                ? 'Completed'
                                : ''
                }?`}
            />
            <TasksModal
                interventionId={preventiveMaintenance?.interventionDetails?.id}
                isOpen={showTasksModal}
                onClose={closeTasksModal}
                onConfirm={(selectedTasks: string[], description: string) => {
                    handleTransition('IN_PROGRESS', selectedTasks, description);
                }}
            />
            <DeleteModal
                isOpen={showDeleteModal}
                onClose={closeDeleteModal}
                onDelete={handleDelete}
            />
        </div>
    );
};

export default PreventiveMaintenanceShow;
