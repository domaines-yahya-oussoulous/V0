import * as z from 'zod';

export const MAX_FILE_SIZE = 5000000;
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
const optionSchema = z.object({
    label: z.string(),
    value: z.string(),
    disable: z.boolean().optional(),
});
export const preventiveMaintenanceFormSchema = z.object({
    farm : z.string().nonempty("Farm is required"),
    intervention: z.string().nonempty("Intervention is required"),
    interventionDate: z.string()
        .nonempty({ message: "Intervention Date is required" })
        .refine(
            (value) => {
                const today = new Date();
                const inputDate = new Date(value);
                return inputDate >= new Date(today.setHours(0, 0, 0, 0)); // Allows today or future dates
            },
            { message: "Intervention Date must be today or in the future" }
        ),
    interventionEstimatedDuration: z.coerce.number().min(0, "Duration must be a positive number"),
    interventionEstimatedDurationUnit: z.string().nonempty("Duration unit is required"),
    maintenanceFrequency: z.string().nonempty("Maintenance frequency is required"),
    maintenanceFrequencyCount: z.coerce.number().min(0, "Maintenance frequency count must be a positive number"),
    equipmentToMaintain: z.string().nonempty("Equipment is required"),
    sparePartPreventiveMaintenanceQuantities: z.array(
        z.object({
            SparePart: z.string().nonempty("Spare part is required"),
            quantity: z.coerce.number().min(1, "Quantity must be at least 1")
        })
    ).optional(),
    imageFiles: z
        .array(
            z.object({
                file: z.instanceof(File).refine(
                    file => ACCEPTED_IMAGE_TYPES.includes(file.type),
                    "Invalid file type. Only JPEG, JPG, PNG, and WEBP are accepted."
                ).refine(
                    file => file.size <= MAX_FILE_SIZE,
                    "Max file size allowed is 5MB."
                )
            })
        )
        .optional()
        .nullable(),
    PersonnelInCharge: z.array(optionSchema).min(0),
});

export const preventiveMaintenanceDefaultValues = {
    farm: "",
    intervention: "",
    interventionDate: "",
    interventionEstimatedDuration: 0,
    interventionEstimatedDurationUnit: "",
    maintenanceFrequency: "",
    maintenanceFrequencyCount: 0,
    equipmentToMaintain: "",
    sparePartPreventiveMaintenanceQuantities: [],
    imageFiles: null,
    PersonnelInCharge: []
};
