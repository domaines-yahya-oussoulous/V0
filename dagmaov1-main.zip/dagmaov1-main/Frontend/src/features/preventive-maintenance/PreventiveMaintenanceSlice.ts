// store/preventiveMaintenanceSlice.ts

import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import { PreventiveMaintenanceType } from "@/types/PreventiveMaintenanceType.ts";
import {handleAxiosError} from "@/utils/handlers/handleAxiosError.ts";

interface PreventiveMaintenanceState {
    maintenanceData: PreventiveMaintenanceType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: PreventiveMaintenanceState = {
    maintenanceData: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const preventiveMaintenanceSlice = createSlice({
    name: 'preventiveMaintenance',
    initialState,
    reducers: {
        fetchPreventiveMaintenanceStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchPreventiveMaintenanceSuccess(state, action: PayloadAction<{ maintenanceData: PreventiveMaintenanceType[], total: number }>) {
            state.loading = false;
            state.maintenanceData = action.payload.maintenanceData;
            state.total = action.payload.total;
        },
        fetchPreventiveMaintenanceFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deletePreventiveMaintenanceStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deletePreventiveMaintenanceSuccess(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.maintenanceData = state.maintenanceData.filter(maintenance => maintenance.id !== action.payload);
        },
        deletePreventiveMaintenanceFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchPreventiveMaintenanceStart,
    fetchPreventiveMaintenanceSuccess,
    fetchPreventiveMaintenanceFailure,
    setPage,
    setSearchTerm,
    deletePreventiveMaintenanceStart,
    deletePreventiveMaintenanceSuccess,
    deletePreventiveMaintenanceFailure,
} = preventiveMaintenanceSlice.actions;

export const fetchPreventiveMaintenance = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchPreventiveMaintenanceStart());

        // Construire l'URL en fonction de la présence de searchTerm
        let url = `preventive_maintenances?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&equipmentName=${searchTerm}`;
        }
        // Ajouter order[id] à la fin de l'URL
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const maintenanceData = response.data['hydra:member'];
        dispatch(fetchPreventiveMaintenanceSuccess({ maintenanceData, total: totalItems }));
    } catch (error) {
        dispatch(fetchPreventiveMaintenanceFailure(handleAxiosError(error)));
    }
};

export const deletePreventiveMaintenance = (id: string): AppThunk => async (dispatch) => {
    try {
        dispatch(deletePreventiveMaintenanceStart());
        await axios.delete(`preventive_maintenances/${id}`);
        dispatch(deletePreventiveMaintenanceSuccess(id));
    } catch (error) {
        dispatch(deletePreventiveMaintenanceFailure(handleAxiosError(error)));
    }
};

export const createPreventiveMaintenance = (formData: FormData): AppThunk => async () => {
    try {
        const response = await axios.post(`preventive_maintenances/add`, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('Preventive maintenance created:', response.data);
        // Optionally handle response if needed
        // You might dispatch an action if creation modifies state
    } catch (error) {
        console.error('Failed to create preventive maintenance:', error);
        // Handle error if needed
    }
};

export default preventiveMaintenanceSlice.reducer;
