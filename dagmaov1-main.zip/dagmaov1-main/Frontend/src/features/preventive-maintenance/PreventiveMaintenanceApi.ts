// PreventiveMaintenanceApi.ts
import axios from 'axios';

export const createPreventiveMaintenance = async (data: FormData) => {
    try {
        const response = await axios.post('preventive-maintenance/add', data, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log(response.data);
        return response.data;
    } catch (error) {
        throw error;
    }
};
// Function to fetch farms
export const fetchFarms = async () => {
    const response = await axios.get(`farms`);
    return response.data["hydra:member"];
};

// Function to fetch equipment by farm ID
export const fetchEquipmentByFarm = async (farmId: string) => {
    const response = await axios.get(`equipments-by-farm/${farmId}`);
    return response.data.equipment;
};

// Function to fetch spare parts by farm ID
export const fetchSparePartsByFarm = async (farmId: string) => {
    const response = await axios.get(`spare-parts-by-farm/${farmId}`);
    return response.data.spareParts;
};

// PreventiveMaintenanceApi.ts
export const fetchTechniciansByFarm = async (farmId: string) => {
    const response = await axios.get(`technicians-by-farm/${farmId}`);
    return response.data["hydra:member"];
};

export const fetchInterventionsByEquipment = async (equipmentId: string) => {
        const response = await axios.get(`equipment/${equipmentId}/interventions`);
        return response.data.interventions;
};