// store/userSlice.ts

import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import { UserType } from "@/types/UserType.ts";

interface UserState {
    users: UserType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: UserState = {
    users: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const userSlice = createSlice({
    name: 'users',
    initialState,
    reducers: {
        fetchUsersStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchUsersSuccess(state, action: PayloadAction<{ users: UserType[], total: number }>) {
            state.loading = false;
            state.users = action.payload.users;
            state.total = action.payload.total;
        },
        fetchUsersFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deleteUserStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deleteUserSuccess(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.users = state.users.filter(user => user.id !== action.payload);
        },
        deleteUserFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchUsersStart,
    fetchUsersSuccess,
    fetchUsersFailure,
    setPage,
    setSearchTerm,
    deleteUserStart,
    deleteUserSuccess,
    deleteUserFailure,
} = userSlice.actions;

export const fetchUsers = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchUsersStart());

        // Construire l'URL en fonction de la présence de searchTerm
        let url = `users?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&lastName=${searchTerm}`;
        }
        // Ajouter order[id] à la fin de l'URL
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const users = response.data['hydra:member'];
        dispatch(fetchUsersSuccess({ users, total: totalItems }));
    } catch (error) {
        dispatch(fetchUsersFailure(error.toString()));
    }
};

export const deleteUser = (id: string): AppThunk => async (dispatch) => {
    try {
        dispatch(deleteUserStart());
        await axios.delete(`users/${id}`);
        dispatch(deleteUserSuccess(id));
    } catch (error) {
        dispatch(deleteUserFailure(error.toString()));
    }
};

export default userSlice.reducer;
