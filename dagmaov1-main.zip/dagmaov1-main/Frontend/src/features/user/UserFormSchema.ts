import * as z from 'zod';

export const userFormSchema = z.object({
    email: z.string().email(),
    firstName: z.string().nonempty("First name is required"),
    lastName: z.string().nonempty("Last name is required"),
    password: z.string()
        .min(8, "Password must be at least 8 characters long")
        .regex(/[a-z]/, "Password must contain at least one lowercase letter")
        .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
        .regex(/[0-9]/, "Password must contain at least one number"),
    confirmPassword: z.string().min(1, "Confirmation password is required"),
    farm: z.string().optional(),
    type: z.enum(["admin", "director", "maintenance_manager", "technician"])
}).refine(data => {
    if (data.type !== "admin") {
        return !!data.farm;
    }
    return true;
}, {
    message: "Farm is required",
    path: ["farm"]
}).refine(data => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
});

export const userDefaultValues = {
    email: "",
    firstName: "",
    lastName: "",
    password: "",
    confirmPassword: "",
    farm: "",
    type: ""
};
