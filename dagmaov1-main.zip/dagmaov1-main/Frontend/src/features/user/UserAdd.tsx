import React, { useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button.tsx";
import {
    Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form.tsx";
import { Toaster } from "@/components/ui/toaster.tsx";
import MessageModal from "@/components/messagemodal/MessageModal.tsx";
import { useNavigate } from "react-router-dom";
import Loader from "@/components/loader/Loader.tsx";
import axios from 'axios';
import FormParameterField from "@/components/formparameterfield/FormParameterField.tsx";
import { userDefaultValues, userFormSchema } from "@/features/user/UserFormSchema.ts";
import { toast } from "@/components/ui/use-toast.ts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";

const UserAdd: React.FC = () => {
    const [loading, setLoading] = useState(false); // Loading state
    const [modalVisible, setModalVisible] = useState(false); // Modal visibility state
    const [modalMessage, setModalMessage] = useState(''); // Modal message state
    const [modalSuccess, setModalSuccess] = useState(false); // Modal success state
    const [farms, setFarms] = useState([]);
    const [userType, setUserType] = useState(''); // State to track user type
    const navigate = useNavigate();
    const form = useForm<z.infer<typeof userFormSchema>>({
        resolver: zodResolver(userFormSchema),
        defaultValues: userDefaultValues
    });

    const handleSubmit = async (data: z.infer<typeof userFormSchema>) => {
        setLoading(true); // Start loading state

        try {
            // Conditionally remove the farm field if the user type is admin
            const payload = { ...data };
            if (payload.type === 'admin') {
                delete payload.farm;
            }

            // Replace with your API endpoint
            const response = await axios.post('users', payload, {
                headers: {
                    'Content-Type': 'application/ld+json'
                }
            });

            // Handle success
            setModalMessage('User added successfully.');
            setModalSuccess(true);
            setModalVisible(true);
        } catch (error) {
            // Handle error
            setModalMessage(error.response?.data?.detail || 'An unknown error occurred');
            setModalSuccess(false);
            setModalVisible(true);
        } finally {
            setLoading(false); // End loading state
        }
    };

    useEffect(() => {
        setLoading(true);
        const fetchFarms = async () => {
            try {
                const response = await axios.get('farms');
                setFarms(response.data["hydra:member"]);
            } catch (error) {
                console.error("Error fetching farms:", error);
                toast({
                    title: "Error",
                    description: 'Failed to fetch farms.',
                    variant: "destructive",
                });
            } finally {
                setLoading(false); // End loading
            }
        };
        fetchFarms();
    }, []);

    const handleModalClose = () => {
        setModalVisible(false);
        if (modalSuccess) {
            navigate('/user'); // Navigate to user list after successful update
        }
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    return (
        <>
            <div className={`mt-12 sm:mt-24 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
                <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Add User</h2>
                <Form {...form}>
                    <form className="m-4 sm:m-12" onSubmit={form.handleSubmit(handleSubmit)}>
                        <div className="max-w-7xl mx-auto p-4 sm:flex sm:justify-between sm:space-x-8">
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2 mb-4 sm:mb-0 mx-auto">
                                <FormParameterField
                                    control={form.control}
                                    name="email"
                                    label="Email"
                                    placeholder="Email"
                                    type="text"
                                    description="Email of the user"
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="firstName"
                                    label="First Name"
                                    placeholder="First Name"
                                    type="text"
                                    description="FirstName of the user"
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="lastName"
                                    label="Last Name"
                                    placeholder="Last Name"
                                    type="text"
                                    description="LastName of the user"
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="password"
                                    label="Password"
                                    placeholder="Password"
                                    type="password"
                                    description="Password of the user"
                                />
                                <FormParameterField
                                    control={form.control}
                                    name="confirmPassword"
                                    label="Confirm Password"
                                    placeholder="Confirm Password"
                                    type="password"
                                    description="Re-enter the password for confirmation"
                                />
                                <FormField
                                    control={form.control}
                                    name="type"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>User Type</FormLabel>
                                            <FormControl>
                                                <Select
                                                    onValueChange={(value) => {
                                                        field.onChange(value);
                                                        setUserType(value); // Update user type state
                                                    }}
                                                    defaultValue={field.value}>
                                                    <SelectTrigger>
                                                        <SelectValue placeholder="Select user type" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="admin">Administrator</SelectItem>
                                                        <SelectItem value="director">Director</SelectItem>
                                                        <SelectItem value="maintenance_manager">Maintenance Manager</SelectItem>
                                                        <SelectItem value="technician">Technician</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </FormControl>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                {userType !== 'admin' && (
                                    <FormField
                                        control={form.control}
                                        name="farm"
                                        render={({ field }) => (
                                            <FormItem>
                                                <FormLabel>Farm</FormLabel>
                                                <FormControl>
                                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select a farm" />
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            {farms.map((farm) => (
                                                                <SelectItem key={farm.id} value={`/api/farms/${farm.id}`}>
                                                                    {farm.name}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                </FormControl>
                                                <FormDescription>
                                                    Select farm of user,
                                                </FormDescription>
                                                <FormMessage />
                                            </FormItem>
                                        )}
                                    />
                                )}
                            </div>
                        </div>
                        <div className="flex justify-center mt-6">
                            <Button type="submit" className="w-full sm:w-auto px-6 py-3 text-lg" disabled={loading}>
                                Submit
                            </Button>
                        </div>
                    </form>
                </Form>
            </div>
            <Toaster />
            <MessageModal
                visible={modalVisible}
                text={modalMessage}
                success={modalSuccess}
                onPressEvent={handleModalClose}
                LeftButtonLabel={"OK"}
            />
        </>
    );
};

export default UserAdd;
