import { useState } from "react";
import { ColumnDef } from "@tanstack/react-table";
import { MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {useDispatch, useSelector} from "react-redux";

import DeleteModal from "@/components/deletemodal/DeleteModal.tsx";
import {deleteUser} from "@/features/user/UserSlice.ts";
import {RootState} from "@/store";
import {UserType} from "@/types/UserType.ts";
import {Badge} from "@/components/ui/badge.tsx"; // Adjust path if necessary

//const { user } = useSelector((state: RootState) => state.users);

export const UserColumns: ColumnDef<UserType>[] = [
    {
        accessorKey: "id",
        header: "Id",
        cell: ({ row }) => {
            const currentUser = useSelector((state: RootState) => state.users.user); // Adjust path if necessary
            const userId = row.original.id;

            return (
                <div className="flex items-center space-x-2">
                    {currentUser && currentUser.id === userId ? (
                        <Badge variant="outline">{userId}</Badge>
                    ) : (
                        <span>{userId}</span>
                    )}
                </div>
            );
        },
    },
    {
        accessorKey: "email",
        header: "Email",
    },
    {
        accessorKey: "type",
        header: "Type",
    },
    {
        accessorKey: "firstName",
        header: "First Name",
    },
    {
        accessorKey: "lastName",
        header: "Last Name",
    },
    {
        accessorKey: "farm.name",
        header: "Farm",
        cell: ({ row }) => {
            const farmName = row.original.farm ? row.original.farm.name : null;
            return (
                <div>
                    {farmName && (
                        <span>
                        {farmName}
                    </span>
                    )}
                </div>
            );
        },
    },
    {
        id: "actions",
        cell: ({ row }) => {
            const dispatch = useDispatch();
            const user = row.original;

            const [isModalOpen, setIsModalOpen] = useState(false);

            const toggleModal = () => {
                setIsModalOpen(!isModalOpen);
            };

            const handleDelete = () => {
                dispatch(deleteUser(user.id));
                setIsModalOpen(false); // Close modal after dispatching delete action
            };

            return (
                <>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={toggleModal}>Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                    <DeleteModal
                        isOpen={isModalOpen}
                        onClose={toggleModal}
                        onDelete={handleDelete}
                        deleteMessage="Are you sure you want to delete this user?"
                    />
                </>
            );
        },
    },
];

