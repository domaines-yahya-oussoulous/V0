import React, { useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from 'zod';
import axios from 'axios';
import { createEquipment } from "@/features/equipment/EquipmentAPI.ts";
import { toast } from "@/components/ui/use-toast.ts";
import { Button } from "@/components/ui/button.tsx";
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage
} from "@/components/ui/form.tsx";
import { Toaster } from "@/components/ui/toaster.tsx";
import { Input } from "@/components/ui/input.tsx";
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from "@/components/ui/select.tsx";
import MessageModal from "@/components/messagemodal/MessageModal.tsx";
import {useNavigate} from "react-router-dom";
import Loader from "@/components/loader/Loader.tsx";
import {equipmentDefaultValues, equipmentFormSchema} from "@/features/equipment/EquipmentFormSchema.ts";
import FormParameterField from "@/components/formparameterfield/FormParameterField.tsx";
import {Checkbox} from "@/components/ui/checkbox.tsx";
import MoneyInput from "@/components/ui/MoneyInput.tsx";

const EquipmentAdd: React.FC = () => {
    const [farms, setFarms] = useState([]);
    const [modalVisible, setModalVisible] = useState(false); // Modal visibility state
    const [modalMessage, setModalMessage] = useState(''); // Modal message state
    const [modalSuccess, setModalSuccess] = useState(false); // Modal message state
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const form = useForm<z.infer<typeof equipmentFormSchema>>({
        resolver: zodResolver(equipmentFormSchema),
        defaultValues: equipmentDefaultValues
    });

    useEffect(() => {
        setLoading(true);
        const fetchFarms = async () => {
            try {
                const response = await axios.get('farms');
                setFarms(response.data["hydra:member"]);
            } catch (error) {
                console.error("Error fetching farms:", error);
                toast({
                    title: "Error",
                    description: 'Failed to fetch farms.',
                    variant: "destructive",
                });
            } finally {
                setLoading(false); // End loading
            }
        };

        const fetchCategories = async () => {
            try {
                const response = await axios.get('equipment-categories-brief');
                setCategories(response.data["hydra:member"]);
            } catch (error) {
                console.error("Error fetching categories:", error);
                toast({
                    title: "Error",
                    description: 'Failed to fetch categories.',
                    variant: "destructive",
                });
            } finally {
                setLoading(false); // End loading
            }
        };


        fetchFarms();
        fetchCategories();
    }, []);

    const handleSubmit = async (data: z.infer<typeof equipmentFormSchema>) => {
        setLoading(true);
        console.log("Form Data Submitted:", data);
        const { latitude, longitude, ...formData } = data;

        try {
            let requestData = { ...formData };

            // Check if both latitude and longitude are filled
            if (latitude && longitude) {
                const gpsData = {
                    latitude: parseFloat(latitude),
                    longitude: parseFloat(longitude)
                };
                requestData = {
                    ...formData,
                    gpsData: JSON.stringify(gpsData) // Convert GPS data to JSON string
                };
            }
            await createEquipment(requestData);
            setModalSuccess(true)
            setModalMessage('Equipment has been created successfully.');
            setModalVisible(true);
            form.reset();
        } catch (error) {
            console.error("Error adding equipment:", error);
            setModalSuccess(false)
            setModalMessage(error.response?.data?.detail || 'An unknown error occurred');
            setModalVisible(true);
        }finally {
            setLoading(false);
        }
    };

    const handleModalClose = () => {
        setModalVisible(false);
        if (modalSuccess) {
            navigate('/equipment'); // Navigate to equipment list after successful update
        }
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    return (
        <>
            <div className={`mt-12 sm:mt-24 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
                <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Add Equipment</h2>
                <Form {...form}>
                    <form className="m-4 sm:m-12" onSubmit={form.handleSubmit(handleSubmit)}>
                        <div className="max-w-7xl mx-auto p-4 sm:flex sm:justify-between sm:space-x-8">
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2 mb-4 sm:mb-0">
                                <fieldset className="border border-gray-200 p-4 mb-4">
                                    <legend className="text-lg font-medium text-gray-900 mb-2">Basic Informations
                                    </legend>
                                    <FormField
                                        control={form.control}
                                        name="farm"
                                        render={({field}) => (
                                            <FormItem>
                                                <FormLabel required>Farm</FormLabel>
                                                <FormControl>
                                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select a farm"/>
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            {farms.map((farm) => (
                                                                <SelectItem key={farm.id}
                                                                            value={`/api/farms/${farm.id}`}>
                                                                    {farm.name}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                </FormControl>
                                                <FormDescription>
                                                    Select the farm where the equipment is located.
                                                </FormDescription>
                                                <FormMessage/>
                                            </FormItem>
                                        )}
                                    />
                                    <FormField
                                        control={form.control}
                                        name="equipmentCategory"
                                        render={({field}) => (
                                            <FormItem>
                                                <FormLabel required>Category</FormLabel>
                                                <FormControl>
                                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                                        <SelectTrigger>
                                                            <SelectValue placeholder="Select a category"/>
                                                        </SelectTrigger>
                                                        <SelectContent>
                                                            {categories.map((category) => (
                                                                <SelectItem key={category.id}
                                                                            value={`/api/equipment_categories/${category.id.toString()}`}>
                                                                    {category.name}
                                                                </SelectItem>
                                                            ))}
                                                        </SelectContent>
                                                    </Select>
                                                </FormControl>
                                                <FormDescription>
                                                    Select the category of the Equipment.
                                                </FormDescription>
                                                <FormMessage/>
                                            </FormItem>
                                        )}
                                    />
                                    <FormParameterField
                                        control={form.control}
                                        name="name"
                                        label="Name"
                                        placeholder="Equipment name"
                                        description="This is the name of the equipment"
                                        required
                                    />
                                    <FormParameterField
                                        control={form.control}
                                        name="reference"
                                        label="Reference"
                                        placeholder="Equipment reference"
                                        description="This is the reference of the equipment"
                                        required
                                    />
                                    <FormParameterField
                                        control={form.control}
                                        name="brand"
                                        label="Brand"
                                        placeholder="Brand"
                                        description="Brand of the equipment"
                                    />
                                    <FormParameterField
                                        control={form.control}
                                        name="family"
                                        label="Family"
                                        placeholder="Family"
                                        description="Family of the equipment"
                                    />
                                    <FormParameterField
                                        control={form.control}
                                        name="inventoryCode"
                                        label="Inventory Code"
                                        placeholder="Inventory code"
                                        description="This is the inventory code of the equipment"
                                        required
                                    />
                                    <FormParameterField
                                        control={form.control}
                                        name="qrCode"
                                        label="QR Code"
                                        placeholder="QR Code"
                                        description="QR code of the equipment"
                                    />
                                    <FormField
                                        control={form.control}
                                        name="underWarranty"
                                        render={({field}) => (
                                            <FormItem
                                                className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4 mt-6 mb-6">
                                                <FormControl>
                                                    <Checkbox
                                                        checked={field.value}
                                                        onCheckedChange={field.onChange}
                                                    />
                                                </FormControl>
                                                <div className="space-y-1 leading-none">
                                                    <FormLabel>
                                                        Under Warranty
                                                    </FormLabel>
                                                    <FormDescription>
                                                        Is the equipment under warranty?
                                                    </FormDescription>
                                                </div>
                                            </FormItem>
                                        )}
                                    />
                                            <FormParameterField
                                                control={form.control}
                                                name="useHoursNumber"
                                                label="Use Hours Number"
                                                placeholder="Use Hours Number"
                                                type="number"
                                                description="Number of use hours"
                                            />
                                            <FormField
                                                control={form.control}
                                                name="imageFile"
                                                render={({field: {value, onChange, ...fieldProps}}) => (
                                                    <FormItem>
                                                        <FormLabel>Image</FormLabel>
                                                        <FormControl>
                                                            <Input
                                                                {...fieldProps}
                                                                type="file"
                                                                onChange={(event) =>
                                                                    onChange(event.target.files && event.target.files[0])
                                                                }
                                                            />
                                                        </FormControl>
                                                        <FormDescription/>
                                                        <FormMessage/>
                                                    </FormItem>
                                                )}
                                            />
                                    <FormField
                                        control={form.control}
                                        name="technicalSpecificationFile"
                                        render={({field: {value, onChange, ...fieldProps}}) => (
                                            <FormItem>
                                                <FormLabel>Technical Specification</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...fieldProps}
                                                        type="file"
                                                        onChange={(event) =>
                                                            onChange(event.target.files && event.target.files[0])
                                                        }
                                                    />
                                                </FormControl>
                                                <FormDescription/>
                                                <FormMessage/>
                                            </FormItem>
                                        )}
                                    />
                                </fieldset>
                            </div>
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2">
                                <fieldset className="border border-gray-200 p-4 mb-4">
                                    <legend className="text-lg font-medium text-gray-900 mb-2">Maintenance Informations
                                    </legend>
                                    <FormField
                                        control={form.control}
                                        name="maintenanceRangeFile"
                                        render={({field: {value, onChange, ...fieldProps}}) => (
                                            <FormItem>
                                                <FormLabel>Maintenance Range</FormLabel>
                                                <FormControl>
                                                    <Input
                                                        {...fieldProps}
                                                        type="file"
                                                        onChange={(event) =>
                                                            onChange(event.target.files && event.target.files[0])
                                                        }
                                                    />
                                                </FormControl>
                                                <FormDescription/>
                                                <FormMessage/>
                                            </FormItem>
                                        )}
                                    />
                                    <FormParameterField
                                        control={form.control}
                                        name="nextMaintenanceDate"
                                        label="Next Maintenance Date"
                                        placeholder="Next maintenance date"
                                        type="date"
                                    />
                                    <FormParameterField
                                        control={form.control}
                                        name="lastMaintenanceDate"
                                        label="Last Maintenance Date"
                                        placeholder="Last maintenance date"
                                        type="date"
                                    />
                                </fieldset>
                                <fieldset className="border border-gray-200 p-4 mb-4">
                                    <legend className="text-lg font-medium text-gray-900 mb-2">Breakdown Informations
                                    </legend>
                                    <div className="flex justify-between gap-4">
                                        <div className="w-1/2">
                                            <FormParameterField
                                                control={form.control}
                                                name="lastBreakdownCause"
                                                label="Last Breakdown Cause"
                                                placeholder="Last Breakdown Cause"
                                                description="Cause of the last breakdown"
                                            />
                                        </div>
                                        <div className="w-1/2">
                                            <FormParameterField
                                                control={form.control}
                                                name="lastBreakdownDate"
                                                label="Last Breakdown Date"
                                                placeholder="Last breakdown date"
                                                type="date"
                                            />
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset className="border border-gray-200 p-4 mb-4">
                                    <legend className="text-lg font-medium text-gray-900 mb-2">Acquisition Informations
                                    </legend>
                                    <div className="flex justify-between gap-4">
                                        <div className="w-1/2">
                                            <MoneyInput
                                                form={form}
                                                label="Acquisition Cost"
                                                name="acquisitionCost"
                                                placeholder="Acquisition Cost"
                                            />
                                        </div>
                                        <div className="w-1/2">
                                            <FormParameterField
                                                control={form.control}
                                                name="acquisitionDate"
                                                label="Acquisition Date"
                                                placeholder="Date of acquisition"
                                                type="date"
                                            />
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset className="border border-gray-200 p-4 mb-4">
                                    <legend className="text-lg font-medium text-gray-900 mb-2">GPS Data</legend>
                                    <div className="flex justify-between gap-4">
                                        <div className="w-1/2">
                                            <FormParameterField
                                                control={form.control}
                                                name="longitude"
                                                label="Longitude"
                                                placeholder="Longitude"
                                                description="Longitude of the equipment"
                                            />
                                        </div>
                                        <div className="w-1/2">
                                            <FormParameterField
                                                control={form.control}
                                                name="latitude"
                                                label="Latitude"
                                                placeholder="Latitude"
                                                description="Latitude of the equipment"
                                            />
                                        </div>
                                    </div>
                                </fieldset>
                                <fieldset className="border border-gray-200 p-4 mb-4">
                                    <legend className="text-lg font-medium text-gray-900 mb-2">Counter</legend>
                                    <div className="flex justify-between gap-4">
                                        <div className="w-1/2">
                                            <FormParameterField
                                                control={form.control}
                                                name="countingUnit"
                                                label="Counting Unit"
                                                placeholder="Counting Unit"
                                                description="Counting unit of the equipment"
                                            />
                                        </div>
                                        <div className="w-1/2">
                                            <FormParameterField
                                                control={form.control}
                                                type="number"
                                                name="counter"
                                                label="Counter"
                                                placeholder="Counter"
                                                description="Counter of the equipment"
                                            />
                                        </div>
                                    </div>
                                </fieldset>
                            </div>
                        </div>
                        <div className="flex justify-center mt-6">
                            <Button type="submit" className="w-full sm:w-auto px-6 py-3 text-lg">Submit</Button>
                        </div>
                    </form>
                </Form>
            </div>
            <Toaster/>
            <MessageModal
                visible={modalVisible}
                text={modalMessage}
                success={modalSuccess}
                onPressEvent={handleModalClose}
                LeftButtonLabel={"ok"}
            />
        </>
    );
};

export default EquipmentAdd;