import { useState } from "react";
import { ColumnDef } from "@tanstack/react-table";
import {MoreHorizontal, ArrowUpDown, Image} from "lucide-react";
import { Link } from "react-router-dom";
import { useDispatch } from "react-redux"; // Import useDispatch


import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { EquipmentType } from "@/types/EquipmentType.ts";
import {deleteEquipment} from "@/features/equipment/EquipmentSlice.ts";
import DeleteModal from "@/components/deletemodal/DeleteModal.tsx";

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + "equipments/";

export const EquipmentColumns: ColumnDef<EquipmentType>[] = [
    {
        accessorKey: "id",
        header: "Id",
    },
    {
        accessorKey: "name",
        header: "Name",
    },
    {
        accessorKey: "reference",
        header: "Reference",
    },
    {
        accessorKey: "inventoryCode",
        header: "Inventory Code",
    },
    {
        accessorKey: "image",
        header: "Image",
        cell: ({ row }) => {
            const imageUrl = `${IMAGE_BASE_URL}${row.original.image}`;
            return (
                <div className="flex items-center justify-center">
                    {row.original.image ? (
                        <img src={imageUrl} alt="Equipment" className="h-10 w-10 object-cover" />
                    ) : (
                        <Image />
                    )}
                </div>
            );
        },
    },
    {
        accessorKey: "qrCode",
        header: "QR Code",
    },
    {
        accessorKey: "family",
        header: "Family",
    },
    {
        accessorKey: "categoryName",
        header: "Category",
    },
    {
        accessorKey: "brand",
        header: "Brand",
    },
    {
        accessorKey: "acquisitionCost",
        header: "Acquisition Cost",
        cell: ({ row }) => {
            const acquisitionCost = row.original.acquisitionCost;
            return (
                <div>
                    {acquisitionCost > 0 && (
                        <span>
                        {acquisitionCost} MAD
                    </span>
                    )}
                </div>
            );
        },
    },
    {
        accessorKey: "underWarranty",
        header: "Under Warranty",
        cell: ({ row }) => (row.original.underWarranty ? "Yes" : "No"),
    },
    {
        accessorKey: "gpsData",
        header: "GPS Data",
        cell: ({ row }) => {
            const gpsData = row.original.gpsData;
            const latitude = gpsData?.latitude;
            const longitude = gpsData?.longitude;
            return (
                <div>
                    {latitude && longitude && (
                        <span>
                            Lat: {latitude}<br />Long: {longitude}
                        </span>
                    )}
                </div>
            );
        },
    },
    {
        header: "Counter : Unit",
        cell: ({ row }) => {
            const countingUnit = row.original.countingUnit;
            const counter = row.original.counter;

            if (counter === 0 || !countingUnit) {
                return null; // Or return a different placeholder if you prefer
            }

            return `${counter}: ${countingUnit}`;
        },
    },
    {
        accessorKey: "useHoursNumber",
        header: "Use Hours Number",
        cell: ({ row }) => {
            const useHoursNumber = row.original.useHoursNumber;
            return `${useHoursNumber} hours`;
        },
    },

    {
        accessorKey: "lastBreakdownCause",
        header: "Last Breakdown Cause",
    },
    {
        accessorKey: "technicalSpecification",
        header: "Technical Specification",
    },
    {
        accessorKey: "acquisitionDate",
        header: "Acquisition Date",
        cell: ({ row }) => {
            const dateValue = row.getValue("acquisitionDate");
            const date = dateValue ? new Date(dateValue) : null;
            const formatted = date && !isNaN(date.getTime()) ? date.toLocaleDateString() : "";
            return <div className="font-medium">{formatted}</div>;
        },
    },
    {
        accessorKey: "nextMaintenanceDate",
        header: "Next Maintenance Date",
        cell: ({ row }) => {
            const dateValue = row.getValue("nextMaintenanceDate");
            const date = dateValue ? new Date(dateValue) : null;
            const formatted = date && !isNaN(date.getTime()) ? date.toLocaleDateString() : "";
            return <div className="font-medium">{formatted}</div>;
        },
    },
    {
        accessorKey: "lastBreakdownDate",
        header: "Last Breakdown Date",
        cell: ({ row }) => {
            const dateValue = row.getValue("lastBreakdownDate");
            const date = dateValue ? new Date(dateValue) : null;
            const formatted = date && !isNaN(date.getTime()) ? date.toLocaleDateString() : "";
            return <div className="font-medium">{formatted}</div>;
        },
    },
    {
        accessorKey: "lastMaintenanceDate",
        header: "Last Maintenance Date",
        cell: ({ row }) => {
            const dateValue = row.getValue("lastMaintenanceDate");
            const date = dateValue ? new Date(dateValue) : null;
            const formatted = date && !isNaN(date.getTime()) ? date.toLocaleDateString() : "";
            return <div className="font-medium">{formatted}</div>;
        },
    },
    {
        id: "actions",
        cell: ({ row }) => {
            const dispatch = useDispatch(); // Initialize useDispatch hook
            const equipment = row.original;

            const [isModalOpen, setIsModalOpen] = useState(false);

            const toggleModal = () => {
                setIsModalOpen(!isModalOpen);
            };

            const handleDelete = () => {
                dispatch(deleteEquipment(equipment.id)); // Dispatch deleteEquipment action
                setIsModalOpen(false); // Close modal after deletion
            };

            return (
                <>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                                <Link to={`/equipment/${equipment.id}`}>Show</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                                <Link to={`/equipment/${equipment.id}/edit`}>Edit</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={toggleModal}>Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                    <DeleteModal
                        isOpen={isModalOpen}
                        onClose={toggleModal}
                        onDelete={handleDelete}
                        deleteMessage="Are you sure you want to delete this equipment?"
                    />
                </>
            );
        },
    },
];

export default EquipmentColumns;
