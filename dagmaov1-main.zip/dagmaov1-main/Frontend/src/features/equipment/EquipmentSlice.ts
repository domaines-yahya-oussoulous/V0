import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import { EquipmentType } from "@/types/EquipmentType.ts";
import {handleAxiosError} from "@/utils/handlers/handleAxiosError.ts";

interface EquipmentState {
    equipments: EquipmentType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: EquipmentState = {
    equipments: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const equipmentSlice = createSlice({
    name: 'equipment',
    initialState,
    reducers: {
        fetchEquipmentsStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchEquipmentsSuccess(state, action: PayloadAction<{ equipments: EquipmentType[], total: number }>) {
            state.loading = false;
            state.equipments = action.payload.equipments;
            state.total = action.payload.total;
        },
        fetchEquipmentsFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deleteEquipmentStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deleteEquipmentSuccess(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = null;
            state.equipments = state.equipments.filter(equipment => equipment.id !== action.payload);
        },
        deleteEquipmentFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchEquipmentsStart,
    fetchEquipmentsSuccess,
    fetchEquipmentsFailure,
    setPage,
    setSearchTerm,
    deleteEquipmentStart,
    deleteEquipmentSuccess,
    deleteEquipmentFailure,
} = equipmentSlice.actions;

export const fetchEquipments = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchEquipmentsStart());

        // Construire l'URL en fonction de la présence de searchTerm
        let url = `equipment?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&name=${searchTerm}`;
        }
        // Ajouter order[id] à la fin de l'URL
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const equipments = response.data['hydra:member'];
        dispatch(fetchEquipmentsSuccess({ equipments, total: totalItems }));
    } catch (error) {
        dispatch(fetchEquipmentsFailure(handleAxiosError(error)));
    }
};

export const deleteEquipment = (id: string): AppThunk => async (dispatch) => {
    try {
        dispatch(deleteEquipmentStart());
        await axios.delete(`equipment/${id}`);
        dispatch(deleteEquipmentSuccess(id));
    } catch (error) {
        dispatch(deleteEquipmentFailure(handleAxiosError(error)));
    }
};


export default equipmentSlice.reducer;