
import  { useState } from 'react';
import { ColumnDef } from "@tanstack/react-table";
import { MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useDispatch } from "react-redux";
import DeleteModal from "@/components/deletemodal/DeleteModal.tsx";
import {deleteEquipmentCategory} from "@/features/equipment/category/EquipmentCategorySlice.ts";
import {Link} from "react-router-dom";
import {EquipmentCategoryType} from "@/types/EquipmentCategoryType.ts";
import {AppDispatch} from "@/store";

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + "equipment-category-images/";
const EquipmentCategoryColumns: ColumnDef<EquipmentCategoryType>[] = [
    {
        accessorKey: "id",
        header: "Id",
    },
    {
        accessorKey: "name",
        header: "Name",
    },
    {
        accessorKey: "image",
        header: "Image",
        cell: ({ row }) => {
            const imageUrl = `${IMAGE_BASE_URL}${row.original.image}`;
            return (
                <div className="flex items-center justify-center">
                    {row.original.image ? (
                        <img src={imageUrl} alt="Equipment" className="h-10 w-10 object-cover" />
                    ) : (
                        <span>No Image</span>
                    )}
                </div>
            );
        },
    },

    {
        id: "actions",
        cell: ({ row }) => {
            const dispatch:AppDispatch = useDispatch();
            const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
            const equipmentCategory = row.original;

            const handleDelete = () => {
                dispatch(deleteEquipmentCategory(equipmentCategory.id));
                setIsDeleteModalOpen(false);
            };

            const handleOpenDeleteModal = () => {
                setIsDeleteModalOpen(true);
            };

            const handleCloseDeleteModal = () => {
                setIsDeleteModalOpen(false);
            };

            return (
                <>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                                <Link to={`/equipment/category/${equipmentCategory.id}/show`}>Show</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                                <Link to={`/equipment/category/${equipmentCategory.id}/edit`}>Edit</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={handleOpenDeleteModal}>Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                    <DeleteModal
                        isOpen={isDeleteModalOpen}
                        onClose={handleCloseDeleteModal}
                        onDelete={handleDelete}
                        deleteMessage={`Are you sure you want to delete ${equipmentCategory.name}?`}
                    />
                </>
            );
        },
    },
];

export default EquipmentCategoryColumns;
