// store/equipmentCategorySlice.ts

import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import {EquipmentCategoryType} from "@/types/EquipmentCategoryType.ts";
import {handleAxiosError} from "@/utils/handlers/handleAxiosError.ts";

interface EquipmentCategoryState {
    equipmentCategories: EquipmentCategoryType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: EquipmentCategoryState = {
    equipmentCategories: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const equipmentCategorySlice = createSlice({
    name: 'equipmentCategories',
    initialState,
    reducers: {
        fetchEquipmentCategoryStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchEquipmentCategorySuccess(state, action: PayloadAction<{ equipmentCategories: EquipmentCategoryType[], total: number }>) {
            state.loading = false;
            state.equipmentCategories = action.payload.equipmentCategories;
            state.total = action.payload.total;
        },
        fetchEquipmentCategoryFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deleteEquipmentCategoryStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deleteEquipmentCategorySuccess(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.equipmentCategories = state.equipmentCategories.filter(category => category.id !== action.payload);
        },
        deleteEquipmentCategoryFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchEquipmentCategoryStart,
    fetchEquipmentCategorySuccess,
    fetchEquipmentCategoryFailure,
    setPage,
    setSearchTerm,
    deleteEquipmentCategoryStart,
    deleteEquipmentCategorySuccess,
    deleteEquipmentCategoryFailure,
} = equipmentCategorySlice.actions;

export const fetchEquipmentCategories = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchEquipmentCategoryStart());

        // Construire l'URL en fonction de la présence de searchTerm
        let url = `equipment_categories?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&name=${searchTerm}`;
        }
        // Ajouter order[id] à la fin de l'URL
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const equipmentCategories = response.data['hydra:member'];
        dispatch(fetchEquipmentCategorySuccess({ equipmentCategories, total: totalItems }));
    } catch (error) {
        dispatch(fetchEquipmentCategoryFailure(handleAxiosError(error)));
    }
};

export const deleteEquipmentCategory = (id: string): AppThunk => async (dispatch) => {
    try {
        dispatch(deleteEquipmentCategoryStart());
        await axios.delete(`equipment_categories/${id}`);
        dispatch(deleteEquipmentCategorySuccess(id));
    } catch (error) {
        dispatch(deleteEquipmentCategoryFailure(handleAxiosError(error)));
    }
};

export default equipmentCategorySlice.reducer;
