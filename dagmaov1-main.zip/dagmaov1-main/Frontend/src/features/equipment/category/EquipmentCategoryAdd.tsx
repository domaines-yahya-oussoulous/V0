import React, { useState } from 'react';
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from 'zod';
import { Button } from "@/components/ui/button.tsx";
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage
} from "@/components/ui/form.tsx";
import { Toaster } from "@/components/ui/toaster.tsx";
import { Input } from "@/components/ui/input.tsx";
import MessageModal from "@/components/messagemodal/MessageModal.tsx";
import { useNavigate } from "react-router-dom";
import Loader from "@/components/loader/Loader.tsx";
import {
    equipmentCategoryDefaultValues,
    equipmentCategoryFormSchema,
} from "@/features/equipment/category/EquipmentCategoryFormSchema.ts";
import {createEquipmentCategory} from "@/features/equipment/category/EquipmentCategoryAPI.ts";
import {Textarea} from "@/components/ui/textarea.tsx";
import FormParameterField from "@/components/formparameterfield/FormParameterField.tsx";

const EquipmentCategoryAdd: React.FC = () => {
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false); // Modal visibility state
    const [modalMessage, setModalMessage] = useState(''); // Modal message state
    const [modalSuccess, setModalSuccess] = useState(false); // Modal message state
    const navigate = useNavigate();
    const form = useForm<z.infer<typeof equipmentCategoryFormSchema>>({
        resolver: zodResolver(equipmentCategoryFormSchema),
        defaultValues: equipmentCategoryDefaultValues
    });

    const handleSubmit = async (data: z.infer<typeof equipmentCategoryFormSchema>) => {
        setLoading(true);
        console.log("Form Data Submitted:", data);
        try {
            await createEquipmentCategory(data);
            setModalSuccess(true);
            setModalMessage('Equipment Category has been created successfully.');
            setModalVisible(true);
            form.reset();
        } catch (error) {
            console.error("Error adding equipment category:", error);
            setModalSuccess(false);
            setModalMessage(error.response?.data?.detail || 'An unknown error occurred');
            setModalVisible(true);
        } finally {
            setLoading(false);
        }
    };

    const handleModalClose = () => {
        setModalVisible(false);
        if (modalSuccess) {
            navigate('/equipment/category'); // Navigate to equipment category list after successful update
        }
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    return (
        <>
            <div className={`mt-12 sm:mt-24 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
                <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Add Equipment Category</h2>
                <Form {...form}>
                    <form className="m-4 sm:m-12" onSubmit={form.handleSubmit(handleSubmit)}>
                        <div className="max-w-7xl mx-auto p-4 sm:flex sm:justify-between sm:space-x-8">
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2 mb-4 sm:mb-0 mx-auto">
                                <FormParameterField
                                    control={form.control}
                                    name="name"
                                    label="Name"
                                    placeholder="Category name"
                                    description="This is the name of the category"
                                />
                                <FormField
                                    control={form.control}
                                    name="description"
                                    render={({ field }) => (
                                        <FormItem>
                                            <FormLabel>Description</FormLabel>
                                            <FormControl>
                                                <Textarea
                                                    placeholder="Category description"
                                                    className="resize-none"
                                                    {...field}
                                                />
                                            </FormControl>
                                            <FormDescription>
                                                This is the description of the categor
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                                <FormField
                                    control={form.control}
                                    name="imageFile"
                                    render={({ field: { value, onChange, ...fieldProps } }) => (
                                        <FormItem>
                                            <FormLabel>Image</FormLabel>
                                            <FormControl>
                                                <Input
                                                    {...fieldProps}
                                                    type="file"
                                                    onChange={(event) =>
                                                        onChange(event.target.files && event.target.files[0])
                                                    }
                                                />
                                            </FormControl>
                                            <FormDescription>
                                                Upload an image representing the category.
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )}
                                />
                            </div>
                        </div>
                        <div className="flex justify-center mt-6">
                            <Button type="submit" className="w-full sm:w-auto px-6 py-3 text-lg">Submit</Button>
                        </div>
                    </form>
                </Form>
            </div>
            <Toaster />
            <MessageModal
                visible={modalVisible}
                text={modalMessage}
                success={modalSuccess}
                onPressEvent={handleModalClose}
                LeftButtonLabel={"ok"}
            />
        </>
    );
};

export default EquipmentCategoryAdd;
