import axios from "axios";

export const createEquipmentCategory = async (formData: FormData) => {
    try {
        const response = await axios.post('equipment-categories/add', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('Equipment category created:', response.data);
        return response.data; // Return the response data if needed
    } catch (error) {
        console.error('Failed to create equipment category:', error);
        throw error; // Re-throw the error to propagate it further
    }
};

export const updateEquipmentCategory = async (id: string, data: any) => {
    try {
        const response = await axios.post(`equipment-categories/${id}/update`, data, {
            headers: {
                'Content-Type': 'multipart/form-data'
            },
        });
        return response.data;
    } catch (error) {
        throw error;
    }
};


export const getEquipmentCategory = async (id: string) => {
    const url = `equipment_categories/${id}`;

    try {
        const response = await axios.get(url);
        return response.data; // Assuming your API returns the equipment category data
    } catch (error) {
        throw error; // Handle error as per your application's error handling strategy
    }
};

export const deleteEquipmentCategory = async (categoryId: string) => {
    const url = `equipment-categories/${categoryId}`; // Assurez-vous que l'URL correspond à votre API

    try {
        const response = await axios.delete(url);
        return response.data; // Retourne la réponse si nécessaire
    } catch (error) {
        throw new Error(`Failed to delete equipment category: ${error.message}`);
    }
};