import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.tsx';
import MessageModal from "@/components/messagemodal/MessageModal.tsx"; // Adjust import path as necessary
import Loader from "@/components/loader/Loader.tsx"; // Adjust import path as necessary
import { Checkbox } from '@/components/ui/checkbox.tsx';
import {Button} from "@/components/ui/button.tsx"; // Adjust import path as necessary

const EquipmentCategoryInterventions: React.FC = () => {
    const [categories, setCategories] = useState<any[]>([]);
    const [interventions, setInterventions] = useState<any[]>([]);
    const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
    const [categoryInterventions, setCategoryInterventions] = useState<Set<number>>(new Set());
    const [modalVisible, setModalVisible] = useState<boolean>(false);
    const [modalMessage, setModalMessage] = useState<string>('');
    const [modalSuccess, setModalSuccess] = useState<boolean>(true);
    const [loading, setLoading] = useState<boolean>(false); // New loading state for fetching
    const [saving, setSaving] = useState<boolean>(false); // New saving state for patch request

    // Fetch all categories and interventions on component mount
    useEffect(() => {
        const fetchCategoriesAndInterventions = async () => {
            setLoading(true);
            try {
                // Fetch all categories
                const categoriesResponse = await axios.get('equipment_categories');
                setCategories(categoriesResponse.data['hydra:member']);

                // Fetch all interventions
                const interventionsResponse = await axios.get('interventions');
                setInterventions(interventionsResponse.data['hydra:member']);
            } catch (error) {
                console.error('Error fetching data:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchCategoriesAndInterventions();
    }, []);

    // Fetch and update checked interventions when category changes
    useEffect(() => {
        const fetchCategoryInterventions = async () => {
            if (selectedCategory !== null) {
                setLoading(true);
                try {
                    const response = await axios.get(`equipment-category/${selectedCategory}/interventions`);
                    const categoryInterventions = response.data.interventions.map((i: any) => i.id);
                    setCategoryInterventions(new Set(categoryInterventions));
                } catch (error) {
                    console.error('Error fetching category interventions:', error);
                } finally {
                    setLoading(false);
                }
            }
        };

        fetchCategoryInterventions();
    }, [selectedCategory]);

    const handleCategoryChange = (value: string) => {
        setSelectedCategory(Number(value));
    };

    const handleInterventionChange = (interventionId: number) => {
        setCategoryInterventions(prev => {
            const newChecked = new Set(prev);
            if (newChecked.has(interventionId)) {
                newChecked.delete(interventionId);
            } else {
                newChecked.add(interventionId);
            }
            return newChecked;
        });
    };

    const handleSave = () => {
        if (selectedCategory !== null) {
            setSaving(true);
            axios.patch(
                `equipment-category-intervention/${selectedCategory}/edit`,
                {
                    interventions: Array.from(categoryInterventions).map(id => `api/interventions/${id}`)
                },
                {
                    headers: {
                        'Content-Type': 'application/merge-patch+json'
                    }
                }
            )
                .then(response => {
                    setModalMessage('Interventions updated successfully.');
                    setModalSuccess(true);
                })
                .catch(error => {
                    setModalMessage('Error updating interventions.');
                    setModalSuccess(false);
                })
                .finally(() => {
                    setSaving(false);
                    setModalVisible(true);
                });
        }
    };

    const handleCloseModal = () => {
        setModalVisible(false);
    };

    if (loading || saving) {
        return <Loader loading={loading || saving} />;
    }

    return (
        <div className="flex justify-center p-6">
            <div className="w-full max-w-3xl px-4">
                <h1 className="text-3xl font-bold mb-6 text-gray-900">Equipment Category Interventions</h1>

                <div className="mb-6">
                    <label htmlFor="category" className="block text-lg font-medium text-gray-700 mb-2">Select Category</label>
                    <Select onValueChange={handleCategoryChange} value={selectedCategory?.toString() || ''}>
                        <SelectTrigger className="w-full max-w-md">
                            <SelectValue placeholder="Select a category" />
                        </SelectTrigger>
                        <SelectContent>
                            {categories.map(category => (
                                <SelectItem key={category.id} value={category.id.toString()}>
                                    {category.name}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>

                <div>
                    <h2 className="text-2xl font-semibold mb-4 text-gray-800">Available Interventions</h2>
                    <div className="space-y-4">
                        {interventions.map(intervention => (
                            <div key={intervention.id} className="flex items-center space-x-2">
                                <Checkbox
                                    id={`intervention-${intervention.id}`}
                                    checked={categoryInterventions.has(intervention.id)}
                                    onCheckedChange={() => handleInterventionChange(intervention.id)}
                                />
                                <label
                                    htmlFor={`intervention-${intervention.id}`}
                                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                >
                                    {intervention.name}
                                </label>
                            </div>
                        ))}
                    </div>
                    <Button
                        onClick={handleSave}
                        className="mt-6"
                        variant="default"
                    >
                        Save Changes
                    </Button>
                </div>
            </div>

            {/* Message Modal */}
            <MessageModal
                LeftButtonLabel="Close"
                text={modalMessage}
                visible={modalVisible}
                success={modalSuccess}
                onPressEvent={handleCloseModal}
            />
        </div>
    );
};

export default EquipmentCategoryInterventions;
