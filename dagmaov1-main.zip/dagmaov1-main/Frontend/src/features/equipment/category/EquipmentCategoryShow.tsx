import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import Loader from '@/components/loader/Loader.tsx';
import MessageModal from '@/components/messagemodal/MessageModal.tsx';
import { getEquipmentCategory, deleteEquipmentCategory } from '@/features/equipment/category/EquipmentCategoryAPI.ts';
import { EquipmentCategoryType } from "@/types/EquipmentCategoryType.ts";
import DeleteModal from "@/components/deletemodal/DeleteModal.tsx";
import { Button } from "@/components/ui/button.tsx";
import axios from "axios"; // Adjust path as needed

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + "equipment-category-images/";

const EquipmentCategoryShow: React.FC = () => {
    const [loading, setLoading] = useState(false);
    const [category, setCategory] = useState<EquipmentCategoryType>(null); // Adjust type as per your API response structure
    const [error, setError] = useState<string | null>(null);
    const [deleteModalOpen, setDeleteModalOpen] = useState(false);
    const { id } = useParams(); // Assuming you're using React Router to get the ID from URL params
    const navigate = useNavigate();

    useEffect(() => {
        const fetchCategory = async () => {
            setLoading(true);
            try {
                const fetchedCategory = await getEquipmentCategory(id);
                setCategory(fetchedCategory);
            } catch (error) {
                setError(error.message || 'An unknown error occurred');
            } finally {
                setLoading(false);
            }
        };

        fetchCategory();
    }, [id]);

    const handleDelete = async (e) => {
        setLoading(true)
        e.preventDefault();
        try {
            await axios.delete(`equipment_categories/${id}`);
            navigate('/equipment/category');
        } catch (error) {
            console.error('Error deleting equipment category:', error);
        } finally {
            setLoading(false);
        }
    };

    const openDeleteModal = () => {
        setDeleteModalOpen(true);
    };

    const closeDeleteModal = () => {
        setDeleteModalOpen(false);
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    if (error) {
        return (
            <MessageModal
                visible={true}
                text={error}
                success={false}
                onPressEvent={() => setError(null)}
                LeftButtonLabel={'Ok'}
            />
        );
    }

    if (!category) {
        return <Loader loading={true} />;
    }

    return (
        <div className="max-w-4xl mx-auto mt-8 p-6 border border-gray-300 rounded-lg shadow-md">
            <h1 className="text-3xl font-bold mb-4">{category.name}</h1>
            <p className="text-lg mb-4">{category.description}</p>
            {category.image ? (
                <div className="mt-4">
                    <p className="text-sm text-gray-600 mb-2">Image</p>
                    <img
                        src={`${IMAGE_BASE_URL}/${category.image}`}
                        alt={category.name}
                        className="rounded-lg shadow-md max-w-xs"
                    />
                </div>
            ) : (
                <p className="text-sm text-gray-600 mb-2">No image available</p>
            )}

            {/* Delete and Edit Buttons */}
            <div className="mt-6 flex justify-end">
                <Button
                    type="button"
                    className="px-4 py-2 bg-red-600 text-white rounded-md mr-4"
                    onClick={openDeleteModal}
                >
                    Delete
                </Button>
                <Button
                    type="button"
                    className="px-4 py-2 bg-blue-600 text-white rounded-md"
                    onClick={() => navigate(`/equipment/category/${id}/edit`)}
                >
                    Edit
                </Button>
            </div>

            {/* Delete Confirmation Modal */}
            <DeleteModal
                isOpen={deleteModalOpen}
                onClose={closeDeleteModal}
                onDelete={handleDelete}
                deleteMessage={`Are you sure you want to delete ${category.name}?`}
            />
        </div>
    );
};

export default EquipmentCategoryShow;
