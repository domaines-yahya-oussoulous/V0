import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { EquipmentType } from '@/types/EquipmentType.ts';
import {Button} from "@/components/ui/button.tsx";
import Loader from "@/components/loader/Loader.tsx";

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + "equipments/";
const MAINTENANCE_RANGE_URL = import.meta.env.VITE_PDF_BASE_URL + "maintenance-range/";
const TECHNICAL_SPECIFICATION_URL = import.meta.env.VITE_PDF_BASE_URL + "technical-specification/";
const EquipmentShow: React.FC = () => {
    const { id } = useParams<{ id: string }>(); // Get id from route params
    const navigate = useNavigate(); // Use useNavigate hook for navigation
    const [equipment, setEquipment] = useState<EquipmentType | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [showModal, setShowModal] = useState<boolean>(false); // State to control modal visibility

    useEffect(() => {
        const fetchEquipment = async () => {
            try {
                const response = await axios.get<EquipmentType>(`equipment/${id}`);
                setEquipment(response.data);
            } catch (error) {
                console.error('Error fetching equipment:', error);
                setError('Failed to fetch equipment. Please try again later.');
            } finally {
                setLoading(false);
            }
        };

        fetchEquipment();
    }, [id]);

    const handleDelete = async () => {
        try {
            await axios.delete(`equipment/${id}`);
            navigate('/equipment'); // Navigate to equipment list after successful deletion
        } catch (error) {
            console.error('Error deleting equipment:', error);
            // Handle error as needed
        }
    };

    const toggleModal = () => {
        setShowModal(!showModal); // Toggle modal visibility
    };
    const handleTechnicalSpecificationDownload = () => {
        if (equipment?.technicalSpecificationName) {
            window.open(`${TECHNICAL_SPECIFICATION_URL}${equipment.technicalSpecificationName}`, '_blank');
        }
    };
    const handleMaintenanceRangeDownload = () => {
        if (equipment?.maintenanceRangeName) {
            window.open(`${MAINTENANCE_RANGE_URL}${equipment.maintenanceRangeName}`, '_blank');
        }
    };

    if (loading) {
        return <Loader loading={loading} />;
    }

    if (error) {
        return <div className="container mx-auto px-4 py-8 text-red-500">{error}</div>;
    }

    if (!equipment) {
        return <div className="container mx-auto px-4 py-8">No equipment found.</div>;
    }

    return (
        <div className="container mx-auto px-4 py-8">
            <div className="bg-white shadow-md rounded-lg overflow-hidden">
                <div className="p-4">
                    <h2 className="text-xl font-bold mb-4">Equipment Details</h2>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <p className="text-sm text-gray-600">ID</p>
                            <p className="font-semibold">{equipment.id}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Farm</p>
                            <p className="font-semibold">{equipment.farm.name}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Name</p>
                            <p className="font-semibold">{equipment.name}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Reference</p>
                            <p className="font-semibold">{equipment.reference}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Inventory Code</p>
                            <p className="font-semibold">{equipment.inventoryCode}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">QR Code</p>
                            <p className="font-semibold">{equipment.qrCode}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Family</p>
                            <p className="font-semibold">{equipment.family}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Category</p>
                            <p className="font-semibold">{equipment.categoryName}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Brand</p>
                            <p className="font-semibold">{equipment.brand}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Acquisition Date</p>
                            <p className="font-semibold">{equipment.acquisitionDate}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Acquisition Cost</p>
                            <p className="font-semibold">{equipment.acquisitionCost}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Under Warranty</p>
                            <p className="font-semibold">{equipment.underWarranty ? 'Yes' : 'No'}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Counting Unit</p>
                            <p className="font-semibold">{equipment.countingUnit}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Counter</p>
                            <p className="font-semibold">{equipment.counter}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Use Hours Number</p>
                            <p className="font-semibold">{equipment.useHoursNumber}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Last Maintenance Date</p>
                            <p className="font-semibold">{equipment.lastMaintenanceDate}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Maintenance Frequency</p>
                            <p className="font-semibold">{equipment.maintenanceFrequency}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Period</p>
                            <p className="font-semibold">{equipment.period}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Next Maintenance Date</p>
                            <p className="font-semibold">{equipment.nextMaintenanceDate}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Last Breakdown Date</p>
                            <p className="font-semibold">{equipment.lastBreakdownDate}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Last Breakdown Cause</p>
                            <p className="font-semibold">{equipment.lastBreakdownCause}</p>
                        </div>
                        <div>
                            <p className="text-sm text-gray-600">Technical Specification</p>
                            <p className="font-semibold">{equipment.technicalSpecification}</p>
                        </div>
                        {equipment.technicalSpecificationName && (
                            <div className="mt-4">
                                <Button onClick={handleTechnicalSpecificationDownload} className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded">
                                    Download Technical Specification
                                </Button>
                            </div>
                        )}
                        {equipment.maintenanceRangeName && (
                            <div className="mt-4">
                                <Button onClick={handleMaintenanceRangeDownload} className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded">
                                    Download Maintenance Range
                                </Button>
                            </div>
                        )}
                    </div>
                    {equipment.image && (
                        <div className="mt-4">
                            <p className="text-sm text-gray-600">Image</p>
                            <img src={`${IMAGE_BASE_URL}${equipment.image}`} alt={equipment.name} className="mt-2 rounded-lg shadow-md" />
                        </div>
                    )}
                    <div className="mt-4">
                        <button onClick={toggleModal} className="bg-red-500 hover:bg-red-600 text-white py-2 px-4 rounded">
                            Delete Equipment
                        </button>
                    </div>
                    {/* Additional details can be added here */}

                    {/* Modal component for confirmation */}
                    {showModal && (
                        <div className="fixed inset-0 flex items-center justify-center z-50">
                            <div className="absolute inset-0 bg-gray-900 opacity-50"></div>
                            <div className="bg-white p-4 rounded-lg shadow-lg z-10">
                                <p className="text-lg font-semibold mb-4">Are you sure you want to delete this equipment?</p>
                                <div className="flex justify-end">
                                    <button onClick={toggleModal} className="bg-gray-300 hover:bg-gray-400 text-gray-800 py-2 px-4 rounded mr-2">
                                        Cancel
                                    </button>
                                    <button onClick={handleDelete} className="bg-red-500 hover:bg-red-600 text-white py-2 px-4 rounded">
                                        Delete
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default EquipmentShow;
