import axios from 'axios';


export const createEquipment = async (formData: FormData) => {
    try {
        const response = await axios.post(`equipments/add`, formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('Equipment created:', response.data);
        return response.data; // Return the response data if needed
    } catch (error) {
        console.error('Failed to create equipment:', error);
        throw error; // Re-throw the error to propagate it further
    }
};