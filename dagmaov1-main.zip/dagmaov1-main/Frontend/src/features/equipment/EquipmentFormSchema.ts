import * as z from 'zod';

export const MAX_FILE_SIZE = 5000000;
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
export const ACCEPTED_PDF_TYPE = "application/pdf";
export const equipmentFormSchema = z.object({
    name: z.string().nonempty("Name is required."),
    reference: z.string().nonempty("Reference is required."),
    inventoryCode: z.string().nonempty("Inventory code is required."),
    imageFile: z.any().optional().nullable()
        .refine(file => file?.length === 1 ? ACCEPTED_IMAGE_TYPES.includes(file?.[0]?.type) : true, 'Invalid file type. Choose either JPEG, JPG, PNG, or WEBP image.')
        .refine(file => file?.length === 1 ? file[0]?.size <= MAX_FILE_SIZE : true, 'Max file size allowed is 5MB.'),
    technicalSpecificationFile: z.any().optional().nullable()
        .refine(file => file?.length === 1 ? file[0]?.type === ACCEPTED_PDF_TYPE : true, 'Invalid file type. Choose a PDF file.')
        .refine(file => file?.length === 1 ? file[0]?.size <= MAX_FILE_SIZE : true, 'Max file size allowed is 5MB.'),
    qrCode: z.string().optional(),
    family: z.string().optional(),
    equipmentCategory: z.string().nonempty("category is required."),
    brand: z.string().optional(),
    acquisitionDate: z.string().optional().nullable()
        .refine(date => date ? !isNaN(Date.parse(date)) : true, "Invalid date format."),
    acquisitionCost: z.coerce.number().min(0, "Acquisition cost cannot be negative.").optional(),
    underWarranty: z.boolean().optional(),
    longitude: z.coerce.number().optional(),
    latitude: z.coerce.number().optional(),
    countingUnit: z.string().optional(),
    counter: z.coerce.number().optional(),
    useHoursNumber: z.coerce.number().optional(),
    maintenanceRangeFile: z.any().optional().nullable()
        .refine(file => file?.length === 1 ? file[0]?.type === ACCEPTED_PDF_TYPE : true, 'Invalid file type. Choose a PDF file.')
        .refine(file => file?.length === 1 ? file[0]?.size <= MAX_FILE_SIZE : true, 'Max file size allowed is 5MB.'),
    lastMaintenanceDate: z.string().optional().nullable()
        .refine(date => date ? !isNaN(Date.parse(date)) : true, "Invalid date format."),
    nextMaintenanceDate: z.string().optional().nullable()
        .refine(date => date ? !isNaN(Date.parse(date)) : true, "Invalid date format."),
    lastBreakdownDate: z.string().optional().nullable()
        .refine(date => date ? !isNaN(Date.parse(date)) : true, "Invalid date format."),
    lastBreakdownCause: z.string().optional(),
    farm: z.string().nonempty("farm is required."),
}).refine(data => {
    const { latitude, longitude } = data;

    // Check if one of them is 0 while the other is not
    if ((latitude === 0 && longitude !== 0) || (latitude !== 0 && longitude === 0)) {
        // If latitude is 0 and longitude is not, set the error path to latitude
        if (latitude === 0) {
            return false;
        }
        // If longitude is 0 and latitude is not, set the error path to longitude
        if (longitude === 0) {
            return false;
        }
    }

    return true;
}, {
    message: "Both latitude and longitude must be filled together.",
    path: ["latitude", "longitude"], // Set the error path to both initially
});

export const equipmentDefaultValues = {
    name: "",
    reference: "",
    inventoryCode: "",
    imageFile: null,
    technicalSpecificationFile: null,
    qrCode: "",
    family: "",
    equipmentCategory: "",
    brand: "",
    acquisitionDate: "",
    acquisitionCost: 0,
    underWarranty: false,
    longitude: "",
    latitude: "",
    gpsData: "",
    countingUnit: "",
    counter: 0,
    useHoursNumber: 0,
    maintenanceRangeFile: null,
    lastMaintenanceDate: "",
    nextMaintenanceDate: "",
    lastBreakdownDate: "",
    lastBreakdownCause: "",
    farm: "",
};
