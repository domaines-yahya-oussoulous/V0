import React, {useEffect, useState} from 'react';
import axios from 'axios';
import {useNavigate, useParams} from 'react-router-dom';
import {Card, CardContent, CardHeader, CardTitle} from '@/components/ui/card.tsx';
import {Toaster} from '@/components/ui/toaster.tsx';
import {Input} from '@/components/ui/input.tsx';
import MaintenanceStates from '@/components/maintenancestates/MaintenanceStates.tsx';
import {Button} from '@/components/ui/button.tsx';
import ConfirmationModal from "@/components/confirmationmodal/ConfirmationModal.tsx";
import DeleteModal from "@/components/deletemodal/DeleteModal.tsx";
import Loader from "@/components/loader/Loader.tsx";
import {Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious} from "@/components/ui/carousel";
import {Badge} from "@/components/ui/badge.tsx";
import TasksModal from "@/components/tasksmodal/TasksModal.tsx";
import {CorrectiveMaintenanceType} from "@/types/CorrectiveMaintenanceType.ts";
import CorrectiveMaintenanceDurationsModal
    from "@/components/correctivemaintenancedurationsmodal/CorrectiveMaintenanceDurationsModal.tsx";

const IMAGE_BASE_URL = import.meta.env.VITE_IMAGE_BASE_URL + 'corrective-maintenance/';

const CorrectiveMaintenanceShow: React.FC = () => {
    const {id} = useParams<{ id: string }>();
    const [correctiveMaintenance, setCorrectiveMaintenance] = useState<CorrectiveMaintenanceType | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [showModal, setShowModal] = useState<boolean>(false);
    const [showDeleteModal, setShowDeleteModal] = useState<boolean>(false);
    const [showTasksModal, setShowTasksModal] = useState<boolean>(false);
    const [showCompleteModal, setShowCompleteModal] = useState<boolean>(false);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchCorrectiveMaintenance = async () => {
            try {
                const response = await axios.get(`/corrective-maintenance/${id}`);
                setCorrectiveMaintenance(response.data);
            } catch (error) {
                console.error('Error fetching corrective maintenance:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchCorrectiveMaintenance();
    }, [id]);

    const handleDelete = async (e) => {
        setLoading(true);
        e.preventDefault();
        try {
            await axios.delete(`/corrective_maintenances/${id}`);
            navigate('/corrective-maintenance');
        } catch (error) {
            console.error('Error deleting corrective maintenance:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleTransition = async (newState: string, selectedTasks: string[] = [], description: string = '', realDownTime?: string, realDownTimeUnit?: string, interventionRealDuration?: string, interventionRealDurationUnit?: string) => {
        try {
            setShowModal(false);
            setLoading(true);

            let stateChangeUrl = '';
            switch (newState) {
                case 'PLANNED':
                    stateChangeUrl = `/corrective-maintenances/${id}/validate`;
                    break;
                case 'IN_PROGRESS':
                    stateChangeUrl = `/corrective-maintenances/${id}/mark-as-in-progress`;
                    break;
                case 'COMPLETED':
                    stateChangeUrl = `/corrective-maintenances/${id}/mark-as-completed`;
                    break;
                case 'NON_VALIDATED':
                    stateChangeUrl = `/corrective-maintenances/${id}/invalidate`;
                    break;
                default:
                    throw new Error('Invalid state transition');
            }

            const formattedTasks = selectedTasks.map(taskId => `/api/operations/${taskId}`);

            if (newState === 'IN_PROGRESS') {
                const response = await axios.patch(
                    `corrective-maintenances/${correctiveMaintenance?.id}/operations`,
                    {"operations": formattedTasks, tasksDescription: description},
                    {
                        headers: {
                            'Content-Type': 'application/merge-patch+json',
                        },
                    }
                );

                if (!(response.status >= 200 && response.status < 300)) {
                    throw new Error('Failed to add tasks');
                }
            }

            if (newState === 'COMPLETED') {
                console.warn(realDownTime)
                await axios.patch(
                    stateChangeUrl,
                    {realDownTime, realDownTimeUnit, interventionRealDuration, interventionRealDurationUnit},
                    {
                        headers: {
                            'Content-Type': 'application/merge-patch+json',
                        },
                    }
                );
                closeCompleteModal()
            } else {
                await axios.patch(
                    stateChangeUrl,
                    {},
                    {
                        headers: {
                            'Content-Type': 'application/merge-patch+json',
                        },
                    }
                );
            }

            const res = await axios.get(`/corrective-maintenance/${id}`);
            setCorrectiveMaintenance(res.data);
            closeTasksModal();

        } catch (error) {
            console.error(`Error transitioning corrective maintenance to ${newState}:`, error);
        } finally {
            setLoading(false);
        }
    };

    const openModal = () => setShowModal(true);
    const closeModal = () => setShowModal(false);
    const openDeleteModal = (e) => {
        e.preventDefault();
        setShowDeleteModal(true);
    };
    const closeDeleteModal = () => setShowDeleteModal(false);
    const openTasksModal = () => setShowTasksModal(true);
    const closeTasksModal = () => setShowTasksModal(false);
    const openCompleteModal = () => setShowCompleteModal(true);
    const closeCompleteModal = () => setShowCompleteModal(false);

    if (loading) {
        return <Loader loading={loading}/>;
    }

    if (!correctiveMaintenance) {
        return <div>No corrective maintenance details available.</div>;
    }

    let additionalButton = null;
    let cancelButton = null;

    switch (correctiveMaintenance.state) {
        case 'WAITING_FOR_VALIDATION':
            additionalButton = (
                <Button onClick={(e) => {
                    e.preventDefault();
                    openModal();
                }} className="px-6 py-3">Mark as Planned</Button>
            );
            cancelButton = (
                <Button onClick={(e) => {
                    e.preventDefault();
                    handleTransition('NON_VALIDATED');
                }} className="px-6 py-3 ml-4 bg-red-600 text-white">Cancel</Button>
            );
            break;
        case 'PLANNED':
            additionalButton = (
                <Button onClick={(e) => {
                    e.preventDefault();
                    openTasksModal();
                }} className="px-6 py-3">Mark as In Progress</Button>
            );
            break;
        case 'IN_PROGRESS':
            additionalButton = (
                <Button onClick={(e) => {
                    e.preventDefault();
                    openCompleteModal();
                }} className="px-6 py-3">Mark as Completed</Button>
            );
            break;
        case 'COMPLETED':
            break;
        default:
            break;
    }

    return (
        <div className="mt-12 sm:mt-24">
            <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Corrective Maintenance
                Details</h2>
            <Card className="max-w-screen-xl mx-auto">
                <CardHeader>
                    <div className="flex justify-between items-center">
                        <div>
                            <CardTitle>{correctiveMaintenance?.interventionDetails?.name}</CardTitle>
                        </div>
                        <div>
                            <Badge variant="secondary"><MaintenanceStates state={correctiveMaintenance.state}/></Badge>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <form className="m-4 sm:m-12">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:space-x-24">
                            <div className="flex flex-col justify-center items-center">
                                <label className="block text-sm font-medium text-gray-700">Estimated Intervention
                                    Date:</label>
                                <Input
                                    type="text"
                                    value={new Date(correctiveMaintenance.estimatedInterventionDate).toLocaleDateString() || ''}
                                    className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                    readOnly
                                    disabled
                                />
                                <label className="block text-sm font-medium text-gray-700 mt-4">Urgency Level:</label>
                                <Input
                                    type="text"
                                    value={correctiveMaintenance.urgencyLevel || ''}
                                    className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                    readOnly
                                    disabled
                                />
                                <label className="block text-sm font-medium text-gray-700 mt-4">Estimated
                                    Duration:</label>
                                <Input
                                    type="text"
                                    value={`${correctiveMaintenance.interventionEstimatedDuration} ${correctiveMaintenance.interventionEstimatedDurationUnit}` || ''}
                                    className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                    readOnly
                                    disabled
                                />
                                <label className="block text-sm font-medium text-gray-700 mt-4">Equipment to
                                    Maintain:</label>
                                <Input
                                    type="text"
                                    value={correctiveMaintenance.equipmentToMaintain.name || ''}
                                    className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                    readOnly
                                    disabled
                                />
                                {correctiveMaintenance.interventionRealDuration && correctiveMaintenance.interventionRealDurationUnit && (
                                    <>
                                        <label className="block text-sm font-medium text-gray-700 mt-4">Real Intervention
                                            Duration:</label>
                                        <Input
                                            type="text"
                                            value={`${correctiveMaintenance.interventionRealDuration} ${correctiveMaintenance.interventionRealDurationUnit}` || ''}
                                            className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                            readOnly
                                            disabled
                                        />
                                    </>
                                )}
                                {correctiveMaintenance.realDownTime && correctiveMaintenance.realDownTimeUnit && (
                                    <>
                                        <label className="block text-sm font-medium text-gray-700 mt-4">Real
                                            DownTime Duration:</label>
                                        <Input
                                            type="text"
                                            value={`${correctiveMaintenance.realDownTime} ${correctiveMaintenance.realDownTimeUnit}` || ''}
                                            className="mt-1 p-2 w-full bg-gray-100 cursor-not-allowed"
                                            readOnly
                                            disabled
                                        />
                                    </>
                                )}
                            </div>
                            <div className="flex flex-col justify-center items-center">
                                <div className="flex flex-col justify-center items-center">
                                    <h3 className="font-bold mt-4">Personnel in Charge</h3>
                                    <ul className="mt-2">
                                        {correctiveMaintenance.PersonnelInCharge.map((person, index) => (
                                            <li key={index}>{`${person.firstName} ${person.lastName} - ${person.email}`}</li>
                                        ))}
                                    </ul>
                                </div>
                                {correctiveMaintenance.sparePartCorrectiveMaintenanceQuantities.length > 0 && (
                                    <>
                                        <h3 className="font-bold mt-2 sm:mt-0">Spare Parts Quantities</h3>
                                        <ul className="mt-2">
                                            {correctiveMaintenance.sparePartCorrectiveMaintenanceQuantities.map((sparePart, index) => (
                                                <li key={index}>{`${sparePart.sparePartName}: ${sparePart.quantity}`}</li>
                                            ))}
                                        </ul>
                                    </>
                                )}
                                {correctiveMaintenance.operationsDetails.length > 0 && (
                                    <>
                                        <h3 className="font-bold mt-4">Tasks</h3>
                                        <ul className="mt-2">
                                            {correctiveMaintenance.operationsDetails.map((task, index) => (
                                                <li key={index}>{task}</li>
                                            ))}
                                        </ul>
                                    </>
                                )}
                                {correctiveMaintenance.tasksDescription && (
                                    <div>
                                        <h3 className="font-bold mt-4">Description</h3>
                                        <p>{correctiveMaintenance.tasksDescription}</p>
                                    </div>
                                )}
                                {correctiveMaintenance.images.length > 0 && (
                                    <>
                                        <h3 className="font-bold mt-4">Images</h3>
                                        <div className="mt-2">
                                            <Carousel className="w-full max-w-xs">
                                                <CarouselContent>
                                                    {correctiveMaintenance.images.map((image, index) => (
                                                        <CarouselItem key={index}>
                                                            <div className="p-1">
                                                                <Card>
                                                                    <CardContent
                                                                        className="flex aspect-square items-center justify-center p-6">
                                                                        <img src={`${IMAGE_BASE_URL}${image.imageName}`}
                                                                             alt={`Maintenance Image ${index + 1}`}
                                                                             className="w-full h-auto"/>
                                                                    </CardContent>
                                                                </Card>
                                                            </div>
                                                        </CarouselItem>
                                                    ))}
                                                </CarouselContent>
                                                <CarouselPrevious type="button"/>
                                                <CarouselNext type="button"/>
                                            </Carousel>
                                        </div>
                                    </>
                                )}
                            </div>
                        </div>
                        <div className="mt-4 sm:mt-10 flex justify-center">
                            {additionalButton}
                            {cancelButton}
                            <Button onClick={openDeleteModal}
                                    className="px-6 py-3 ml-4 bg-red-600 text-white">Delete</Button>
                        </div>
                    </form>
                </CardContent>
            </Card>
            <Toaster/>
            <ConfirmationModal
                isOpen={showModal}
                onClose={closeModal}
                onConfirm={() => {
                    const newState = correctiveMaintenance.state === 'WAITING_FOR_VALIDATION'
                        ? 'PLANNED'
                        : correctiveMaintenance.state === 'PLANNED'
                            ? 'IN_PROGRESS'
                            : correctiveMaintenance.state === 'IN_PROGRESS'
                                ? 'COMPLETED'
                                : '';
                    handleTransition(newState);
                }}
                text={`Are you sure you want to mark this corrective maintenance as ${
                    correctiveMaintenance.state === 'WAITING_FOR_VALIDATION'
                        ? 'Planned'
                        : correctiveMaintenance.state === 'PLANNED'
                            ? 'In Progress'
                            : correctiveMaintenance.state === 'IN_PROGRESS'
                                ? 'Completed'
                                : ''
                }?`}
            />
            <TasksModal
                interventionId={correctiveMaintenance?.interventionDetails?.id}
                isOpen={showTasksModal}
                onClose={closeTasksModal}
                onConfirm={(selectedTasks: string[], description: string) => {
                    handleTransition('IN_PROGRESS', selectedTasks, description);
                }}
            />
            <CorrectiveMaintenanceDurationsModal
                isOpen={showCompleteModal}
                onClose={closeCompleteModal}
                onConfirm={(realDownTime, realDownTimeUnit, interventionRealDuration, interventionRealDurationUnit) => {
                    handleTransition('COMPLETED', [], '', realDownTime, realDownTimeUnit, interventionRealDuration, interventionRealDurationUnit);
                }}
            />
            <DeleteModal
                isOpen={showDeleteModal}
                onClose={closeDeleteModal}
                onDelete={handleDelete}
            />
        </div>
    );
};

export default CorrectiveMaintenanceShow;
