// store/correctiveMaintenanceSlice.ts

import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import { CorrectiveMaintenanceType } from "@/types/CorrectiveMaintenanceType.ts";
import {handleAxiosError} from "@/utils/handlers/handleAxiosError.ts";

interface CorrectiveMaintenanceState {
    maintenanceData: CorrectiveMaintenanceType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: CorrectiveMaintenanceState = {
    maintenanceData: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const correctiveMaintenanceSlice = createSlice({
    name: 'correctiveMaintenance',
    initialState,
    reducers: {
        fetchCorrectiveMaintenanceStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchCorrectiveMaintenanceSuccess(state, action: PayloadAction<{ maintenanceData: CorrectiveMaintenanceType[], total: number }>) {
            state.loading = false;
            state.maintenanceData = action.payload.maintenanceData;
            state.total = action.payload.total;
        },
        fetchCorrectiveMaintenanceFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deleteCorrectiveMaintenanceStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deleteCorrectiveMaintenanceSuccess(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.maintenanceData = state.maintenanceData.filter(maintenance => maintenance.id !== action.payload);
        },
        deleteCorrectiveMaintenanceFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchCorrectiveMaintenanceStart,
    fetchCorrectiveMaintenanceSuccess,
    fetchCorrectiveMaintenanceFailure,
    setPage,
    setSearchTerm,
    deleteCorrectiveMaintenanceStart,
    deleteCorrectiveMaintenanceSuccess,
    deleteCorrectiveMaintenanceFailure,
} = correctiveMaintenanceSlice.actions;

export const fetchCorrectiveMaintenance = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchCorrectiveMaintenanceStart());

        // Construire l'URL en fonction de la présence de searchTerm
        let url = `corrective_maintenances?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&equipmentName=${searchTerm}`;
        }

        // Ajouter order[id] à la fin de l'URL
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const maintenanceData = response.data['hydra:member'];
        dispatch(fetchCorrectiveMaintenanceSuccess({ maintenanceData, total: totalItems }));
    } catch (error) {
        dispatch(fetchCorrectiveMaintenanceFailure(handleAxiosError(error)));
    }
}
export const deleteCorrectiveMaintenance = (id: string): AppThunk => async (dispatch) => {
    try {
        dispatch(deleteCorrectiveMaintenanceStart());
        await axios.delete(`corrective_maintenances/${id}`);
        dispatch(deleteCorrectiveMaintenanceSuccess(id));
    } catch (error) {
        dispatch(deleteCorrectiveMaintenanceFailure(handleAxiosError(error)));
    }
};



export default correctiveMaintenanceSlice.reducer;
