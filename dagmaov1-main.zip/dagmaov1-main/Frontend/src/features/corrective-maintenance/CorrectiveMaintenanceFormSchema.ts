import * as z from 'zod';

export const MAX_FILE_SIZE = 5000000;
export const ACCEPTED_IMAGE_TYPES = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
const optionSchema = z.object({
    label: z.string(),
    value: z.string(),
    disable: z.boolean().optional(),
});

export const correctiveMaintenanceFormSchema = z.object({
    farm : z.string().nonempty("Farm is required"),
    intervention: z.string().nonempty("Intervention is required"),
    urgencyLevel: z.string().nonempty("urgency level is required"),
    failureType: z.string().nonempty({ message: "Failure Type is required" }),
    failureDescription: z.string().nonempty({ message: "Failure Description is required" }),
    breakdownTime: z.string()
        .optional()
        .refine(
            (value) => {
                if (!value) return true; // Optional field, no need to validate if empty
                const today = new Date();
                const inputDate = new Date(value);
                return inputDate <= new Date(today.setHours(23, 59, 59, 999)); // Allows today or past dates
            },
            { message: "Breakdown Time must be today or in the past" }
        ),
    breakdownSite: z.string().optional(),
    estimatedInterventionDate: z.string()
        .nonempty({ message: "Estimated Intervention Date is required" })
        .refine(
            (value) => {
                const today = new Date();
                const inputDate = new Date(value);
                return inputDate >= new Date(today.setHours(0, 0, 0, 0)); // Allows today or future dates
            },
            { message: "Estimated Intervention Date must be today or in the future" }
        ),
    interventionEstimatedDuration: z.coerce.number().min(1, "Duration must be superior than 0"),
    interventionEstimatedDurationUnit: z.string().nonempty("Estimated duration unit is required"),
    //interventionEstimatedDurationUnit: z.enum(['hours', 'days', 'months']),
    downtimeEstimatedDuration: z.coerce.number().min(1, "DownTime Duration must be superior than 0"),
    estimatedDownTimeUnit: z.string().nonempty("Estimated down time unit is required"),
    //estimatedDownTimeUnit: z.enum(['hours', 'days', 'months']),
    breakdownProbableCause: z.string().nonempty({ message: "Breakdown Probable Cause is required" }),
    personnelType: z.string().nonempty("Personnel Type is required"),
    //personnelType: z.enum(['INTERNAL', 'EXTERNAL']),
    PersonnelInCharge: z.array(optionSchema).min(0),
    equipmentToMaintain: z.string().nonempty("Equipment is required"),
    sparePartCorrectiveMaintenanceQuantities: z.array(
        z.object({
            SparePart: z.string().nonempty("Spare part is required"),
            quantity: z.coerce.number().min(1, "Quantity must be at least 1")
        })
    ).optional(),
    imageFiles: z
        .array(
            z.object({
                file: z.instanceof(File).refine(
                    file => ACCEPTED_IMAGE_TYPES.includes(file.type),
                    "Invalid file type. Only JPEG, JPG, PNG, and WEBP are accepted."
                ).refine(
                    file => file.size <= MAX_FILE_SIZE,
                    "Max file size allowed is 5MB."
                )
            })
        )
        .optional()
        .nullable(),
});

export const correctiveMaintenanceDefaultValues = {
    farm: "",
    intervention: "",
    urgencyLevel: '',
    failureType: '',
    failureDescription: '',
    breakdownTime: '',
    breakdownSite: '',
    estimatedInterventionDate: '',
    interventionEstimatedDuration: 0,
    interventionEstimatedDurationUnit: '',
    downtimeEstimatedDuration: 0,
    estimatedDownTimeUnit: '',
    breakdownProbableCause: '',
    personnelType: '',
    PersonnelInCharge: [],
    equipmentToMaintain: '',
    sparePartCorrectiveMaintenanceQuantities: [],
    imageFiles: null
};
