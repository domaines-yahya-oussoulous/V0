import { ColumnDef } from "@tanstack/react-table";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, MoreHorizontal } from "lucide-react";
import { useState } from "react";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger
} from "@/components/ui/dropdown-menu.tsx";
import { Link } from "react-router-dom";
import { useDispatch } from 'react-redux';
import { deleteCorrectiveMaintenance } from "@/features/corrective-maintenance/CorrectiveMaintenanceSlice.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { CorrectiveMaintenanceType } from "@/types/CorrectiveMaintenanceType.ts";

export const CorrectiveMaintenanceColumns: ColumnDef<CorrectiveMaintenanceType>[] = [
    {
        accessorKey: "id",
        header: "Id",
    },
    {
        accessorKey: "equipmentName",
        header: "Equipment",
    },
    {
        accessorKey: "interventionDetails.name",
        header: "Intervention Type",
    },
    {
        accessorKey: "failureType",
        header: "Failure Type",
    },
    {
        accessorKey: "breakdownTime",
        header: ({ column }) => (
            <Button
                variant="ghost"
                onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
            >
                Breakdown Time
                <ArrowUpDown className="ml-2 h-4 w-4" />
            </Button>
        ),
        cell: ({ row }) => {
            const breakdownTime = new Date(row.original.breakdownTime);
            return isNaN(breakdownTime.getTime()) ? "" : breakdownTime.toLocaleDateString();
        },
    },
    {
        accessorKey: "breakdownSite",
        header: "Breakdown Site",
    },
    {
        accessorKey: "breakdownProbableCause",
        header: "Probable Cause",
    },
    {
        //accessorKey: "interventionEstimatedDuration",
        header: "Estimated DownTime",
        cell: ({ row }) => {
            const duration = row.original.estimatedDownTime;
            const unit = row.original.estimatedDownTimeUnit;
            return `${duration} ${unit}`;
        },
    },
    {
        //accessorKey: "interventionEstimatedDuration",
        header: "Intervention Estimate Duration",
        cell: ({ row }) => {
            const duration = row.original.interventionEstimatedDuration;
            const unit = row.original.interventionEstimatedDurationUnit;
            return `${duration} ${unit}`;
        },
    },
    {
        accessorKey: "personnelType",
        header: "Personnel Type",
    },
    {
        accessorKey: "sparePartPreventiveMaintenanceQuantities",
        header: "Spare Parts (Name: Quantity)",
        cell: ({ row }) =>
            row.original.sparePartCorrectiveMaintenanceQuantities
                .map((sparePart) => `${sparePart.sparePartName}: ${sparePart.quantity}`)
                .join(", "),
    },
    {
        accessorKey: "state",
        header: "State",
        cell: ({ row }) => {
            const state = row.original.state;
            let stateClass = "";
            let stateText = "";

            switch (state) {
                case "VALIDATED":
                    stateClass = "text-blue-600 font-bold";
                    stateText = "Validated";
                    break;
                case "IN_PROGRESS":
                    stateClass = "text-yellow-600 font-bold";
                    stateText = "In Progress";
                    break;
                case "COMPLETED":
                    stateClass = "text-green-600 font-bold";
                    stateText = "Completed";
                    break;
                case "NON_VALIDATED":
                    stateClass = "text-red-600 font-bold";
                    stateText = "Non-Validated";
                    break;
                case "WAITING_FOR_VALIDATION":
                    stateClass = "text-orange-600 font-bold";
                    stateText = "Waiting for Validation";
                    break;
                default:
                    stateClass = "text-gray-600 font-bold";
                    stateText = state;
                    break;
            }

            return (
                stateText && (
                    <Badge variant={"secondary"}>
                        <span className={stateClass}>{stateText}</span>
                    </Badge>
                )
            );
        },
    },
    {
        id: "actions",
        cell: ({ row }) => {
            const correctiveMaintenance = row.original;
            const dispatch = useDispatch();

            const [isModalOpen, setIsModalOpen] = useState(false);

            const toggleModal = () => {
                setIsModalOpen(!isModalOpen);
            };

            const handleDelete = () => {
                dispatch(deleteCorrectiveMaintenance(correctiveMaintenance.id));
                setIsModalOpen(false);
            };

            return (
                <>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem>
                                <Link to={`/corrective-maintenance/${correctiveMaintenance.id}`}>View</Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={toggleModal}>Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>

                    {isModalOpen && (
                        <div className="fixed inset-0 flex items-center justify-center z-50">
                            <div className="absolute inset-0 bg-gray-900 opacity-50"></div>
                            <div className="bg-white p-4 rounded-lg shadow-lg z-10">
                                <p className="text-lg font-semibold mb-4">Are you sure you want to delete this corrective maintenance?</p>
                                <div className="flex justify-end">
                                    <button onClick={toggleModal} className="bg-gray-300 hover:bg-gray-400 text-gray-800 py-2 px-4 rounded mr-2">
                                        Cancel
                                    </button>
                                    <button onClick={handleDelete} className="bg-red-500 hover:bg-red-600 text-white py-2 px-4 rounded">
                                        Delete
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </>
            );
        },
    },
];
