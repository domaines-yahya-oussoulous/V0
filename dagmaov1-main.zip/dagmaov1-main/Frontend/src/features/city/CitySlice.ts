// citySlice.ts
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import axios from "axios";
import { AppThunk } from "@/store";
import {CityType} from "@/types/CityType.ts";
import {handleAxiosError} from "@/utils/handlers/handleAxiosError.ts";


interface CityState {
    cities: CityType[];
    loading: boolean;
    error: string | null;
    currentPage: number;
    itemsPerPage: number;
    total: number;
    searchTerm: string;
    deleteLoading: boolean;
}

const initialState: CityState = {
    cities: [],
    loading: false,
    error: null,
    currentPage: 1,
    itemsPerPage: 10,
    total: 0,
    searchTerm: '',
    deleteLoading: false,
};

const citySlice = createSlice({
    name: 'cities',
    initialState,
    reducers: {
        fetchCitiesStart(state) {
            state.loading = true;
            state.error = null;
        },
        fetchCitiesSuccess(state, action: PayloadAction<{ cities: CityType[], total: number }>) {
            state.loading = false;
            state.cities = action.payload.cities;
            state.total = action.payload.total;
        },
        fetchCitiesFailure(state, action: PayloadAction<string>) {
            state.loading = false;
            state.error = action.payload;
        },
        setPage(state, action: PayloadAction<number>) {
            state.currentPage = action.payload;
        },
        setSearchTerm(state, action: PayloadAction<string>) {
            state.searchTerm = action.payload;
        },
        deleteCityStart(state) {
            state.deleteLoading = true;
            state.error = null;
        },
        deleteCitySuccess(state, action: PayloadAction<number>) {
            state.deleteLoading = false;
            state.error = null;
            state.cities = state.cities.filter(city => city.id !== action.payload);
        },
        deleteCityFailure(state, action: PayloadAction<string>) {
            state.deleteLoading = false;
            state.error = action.payload;
        },
    },
});

export const {
    fetchCitiesStart,
    fetchCitiesSuccess,
    fetchCitiesFailure,
    setPage,
    setSearchTerm,
    deleteCityStart,
    deleteCitySuccess,
    deleteCityFailure,
} = citySlice.actions;

export const fetchCities = (page: number, itemsPerPage: number, searchTerm: string): AppThunk => async (dispatch) => {
    try {
        dispatch(fetchCitiesStart());

        let url = `cities?itemsPerPage=${itemsPerPage}&page=${page}`;
        if (searchTerm) {
            url += `&name=${searchTerm}`;
        }
        url += '&order[id]';

        const response = await axios.get(url);
        const totalItems = response.data['hydra:totalItems'];
        const cities = response.data['hydra:member'];
        dispatch(fetchCitiesSuccess({ cities, total: totalItems }));
    } catch (error) {
        dispatch(fetchCitiesFailure(handleAxiosError(error)));
    }
};

export const deleteCity = (id: number): AppThunk => async (dispatch) => {
    try {
        dispatch(deleteCityStart());
        await axios.delete(`cities/${id}`);
        dispatch(deleteCitySuccess(id));
    } catch (error) {
        dispatch(deleteCityFailure(handleAxiosError(error)));
    }
};

export default citySlice.reducer;
