// CityAdd.tsx
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button.tsx';
import * as z from 'zod';
import { Toaster } from '@/components/ui/toaster.tsx';
import MessageModal from '@/components/messagemodal/MessageModal.tsx';
import { useNavigate } from 'react-router-dom';
import Loader from '@/components/loader/Loader.tsx';
import {Form} from "@/components/ui/form.tsx";
import axios from "axios";
import FormParameterField from "@/components/formparameterfield/FormParameterField.tsx";

const cityFormSchema = z.object({
    name: z.string().nonempty("City name is required"),
    // Add more fields here as needed
});

const defaultValues = {
    name: '',
    // Initialize other fields here
};

const CityAdd: React.FC = () => {
    const [loading, setLoading] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [modalMessage, setModalMessage] = useState('');
    const [modalSuccess, setModalSuccess] = useState(false);
    const navigate = useNavigate();

    const { handleSubmit, control, reset, formState: { errors } } = useForm({
        resolver: zodResolver(cityFormSchema),
        defaultValues,
    });

    const form = useForm<z.infer<typeof cityFormSchema>>({
        resolver: zodResolver(cityFormSchema),
        defaultValues: defaultValues
    });

    const onSubmit = async (data: z.infer<typeof cityFormSchema>) => {
        setLoading(true);
        try {
            // Example of sending data to create city
            const response = await axios.post('cities', data, {
                headers: {
                    'Content-Type': 'application/ld+json'
                }
            });
            setModalSuccess(true);
            setModalMessage('City has been created successfully.');
            setModalVisible(true);
            reset(); // Reset form after successful submission
        } catch (error) {
            console.error('Error adding city:', error);
            setModalSuccess(false);
            setModalMessage(
                error.response?.data?.detail || 'An unknown error occurred'
            );
            setModalVisible(true);
        } finally {
            setLoading(false);
        }
    };

    const handleModalClose = () => {
        setModalVisible(false);
        if (modalSuccess) {
            navigate('/city');
        }
    };

    return (
        <>
            {loading && <Loader loading={loading} />}
            <div className={`mt-12 sm:mt-24 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
                <h2 className="text-4xl font-bold text-center sm:text-5xl mb-4 text-gray-900">Add City</h2>
                <Form {...form}>
                    <form className="m-4 sm:m-12" onSubmit={form.handleSubmit(onSubmit)}>
                        <div className="max-w-7xl mx-auto p-4 sm:flex sm:justify-between sm:space-x-8">
                            <div className="flex flex-col space-y-4 w-full sm:w-1/2 mb-4 sm:mb-0">
                                <FormParameterField
                                    control={form.control}
                                    name="name"
                                    label="Name"
                                    placeholder="City name"
                                    description="Enter the name of the city"
                                />
                                {/* Add more fields as needed */}
                            </div>
                        </div>
                        <div className="flex justify-center mt-6">
                            <Button type="submit" className="w-full sm:w-auto px-6 py-3 text-lg" disabled={loading}>
                                Submit
                            </Button>
                        </div>
                    </form>
                </Form>
            </div>
            <Toaster />
            <MessageModal
                visible={modalVisible}
                text={modalMessage}
                success={modalSuccess}
                onPressEvent={handleModalClose}
                LeftButtonLabel="OK"
            />
        </>
    );
};

export default CityAdd;
