import React, { useState, useEffect, ReactNode } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { RootState } from '../store';
import Loader from "@/components/loader/Loader.tsx"; // adjust the path to your store

interface AuthGuardProps {
    roleCheck?: boolean;
    children: ReactNode;
}

const AuthGuard: React.FC<AuthGuardProps> = ({ roleCheck = false, children }) => {
    const [isAuth, setIsAuth] = useState(false);
    const users = useSelector((state: RootState) => state.users);
    const navigate = useNavigate();

    useEffect(() => {
        if (!users.auth) {
            navigate('/login');
        }else {
            setIsAuth(true);
        }
        /*else {
            if (roleCheck && users.data.role === 'user') {
                navigate('/');
            }
            else {
                setIsAuth(true);
            }
        }*/
    }, [navigate, users, roleCheck]);

    if (!isAuth) {
        return <Loader loading={true}/>;
    } else {
        return <>{children}</>;
    }
};

export default AuthGuard;
