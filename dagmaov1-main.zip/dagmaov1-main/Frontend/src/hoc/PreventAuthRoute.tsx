import React, { ReactNode } from 'react';
import { useSelector } from 'react-redux';
import {Navigate} from 'react-router-dom';
import { RootState } from '../store';

interface PreventAuthRouteProps {
    children: ReactNode;
}

const PreventAuthRoute: React.FC<PreventAuthRouteProps> = ({ children }) => {
    const auth = useSelector((state: RootState) => state.users.auth);

    return (
        <>
            {auth ? <Navigate to="/" /> : children}
        </>
    );
};

export default PreventAuthRoute;
