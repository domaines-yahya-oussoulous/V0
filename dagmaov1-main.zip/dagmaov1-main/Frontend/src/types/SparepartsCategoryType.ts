export type SparePartsCategoryType = {
    id: string;
    name: string;
    description: string;
    imageFile: string;
    image: string;
};
