export type CityType= {
    id: number;
    name: string;
}
