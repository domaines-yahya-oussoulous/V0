import {EquipmentType} from "@/types/EquipmentType.ts";
import {SparePartQuantityType} from "@/types/SparepartsType.ts";

export type PreventiveMaintenanceType = {
    id: string;
    interventionType: string;
    interventionDate: Date;
    interventionEstimatedDuration: number;
    interventionEstimatedDurationUnit: string,
    maintenanceFrequency: string;
    equipmentToMaintain: EquipmentType;
    sparePartPreventiveMaintenanceQuantities: SparePartQuantityType[];
    images: string[],
    PersonnelInCharge: string[],
    state: string
};