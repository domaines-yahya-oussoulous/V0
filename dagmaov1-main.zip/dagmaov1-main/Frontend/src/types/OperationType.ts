export type OperationType = {
    description: string;
};
