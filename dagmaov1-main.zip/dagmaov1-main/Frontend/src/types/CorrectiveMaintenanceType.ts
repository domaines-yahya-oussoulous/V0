import {EquipmentType} from "@/types/EquipmentType.ts";

export type CorrectiveMaintenanceType = {
    id: string;
    failureType: string;
    failureDescription: string;
    breakdownTime: string;
    breakdownSite: string;
    breakdownProbableCause: string;
    estimatedInterventionTime: number;
    personnelType: string;
    equipmentToMaintain: EquipmentType
};
