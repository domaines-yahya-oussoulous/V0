import {FarmType} from "@/types/FarmType.ts";

export type EquipmentType = {
    id: string
    name: string,
    reference: string
    inventoryCode: string,
    image: string,
    qrCode: string,
    family:string,
    category: string,
    brand: string,
    acquisitionDate?:Date,
    acquisitionCost:number,
    underWarranty: boolean,
    gpsData: string,
    countingUnit:string,
    counter:string,
    useHoursNumber: number,
    lastMaintenanceDate?: Date,
    maintenanceFrequency: string,
    period: string,
    nextMaintenanceDate?: Date,
    lastBreakdownDate?: Date,
    lastBreakdownCause: string,
    technicalSpecification: string,
    maintenanceRange: string,
    farm: FarmType
}