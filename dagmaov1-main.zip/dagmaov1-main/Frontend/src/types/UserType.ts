import {FarmType} from "@/types/FarmType.ts";

export interface UserType {
    id: number;
    email: string;
    roles: string[];
    firstName: string;
    lastName: string;
    type: string;
    farm: FarmType | null;
}
