import {CityType} from "@/types/CityType.ts";


export type FarmType = {
    id: string,
    name: string,
    reference: string,
    location: string
    city: CityType
}