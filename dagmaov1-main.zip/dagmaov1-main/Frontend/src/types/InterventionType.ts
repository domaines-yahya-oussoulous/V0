import {OperationType} from "@/types/OperationType.ts";

export type InterventionType = {
    id: number;
    name: string;
    operations: OperationType[];
};
