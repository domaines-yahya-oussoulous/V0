
export type EquipmentCategoryType = {
    id: string
    name: string,
    description: string,
    imageFile: string,
    image: string
}