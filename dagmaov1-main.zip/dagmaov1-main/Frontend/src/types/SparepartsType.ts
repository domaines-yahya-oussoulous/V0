import {FarmType} from "@/types/FarmType.ts";

export type SparepartsType = {
    id: string,
    name:string,
    inventoryCode: string;
    category: string;
    brand: string;
    unitsNumber: number;
    unitPrice: number;
    lastInventory: string;
    availability: boolean;
    quantity: number;
    orderDuration: string;
    image: string;
    farm: FarmType;

}
export type SparePartQuantityType = {
    id: string;
    quantity: number;
    sparePartName: string;
};