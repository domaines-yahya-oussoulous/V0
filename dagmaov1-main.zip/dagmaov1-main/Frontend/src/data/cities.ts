export const citiesExample = [
    {
        id: "casablanca",
        label: "Casablanca",
    },
    {
        id: "marrakech",
        label: "Marrakech",
    },
    {
        id: "fes",
        label: "Fes",
    },
    {
        id: "rabat",
        label: "Rabat",
    },
    {
        id: "tangier",
        label: "Tangier",
    },
    {
        id: "agadir",
        label: "Agadir",
    },
    {
        id: "meknes",
        label: "Meknes",
    },
    {
        id: "oujda",
        label: "Oujda",
    },
    {
        id: "kenitra",
        label: "Kenitra",
    },
    {
        id: "tetouan",
        label: "Tetouan",
    },
    {
        id: "safi",
        label: "Safi",
    },
    {
        id: "khouribga",
        label: "Khouribga",
    },
    {
        id: "el_jadida",
        label: "El Jadida",
    },
    {
        id: "beni_mellal",
        label: "Beni Mellal",
    },
    {
        id: "nador",
        label: "Nador",
    },
    {
        id: "taza",
        label: "Taza",
    },
    {
        id: "settat",
        label: "Settat",
    },
    {
        id: "sale",
        label: "Salé",
    },
    {
        id: "mohammedia",
        label: "Mohammedia",
    },
    {
        id: "laayoune",
        label: "Laayoune",
    },
    {
        id: "essaouira",
        label: "Essaouira",
    },
    {
        id: "errachidia",
        label: "Errachidia",
    },
    {
        id: "ifrane",
        label: "Ifrane",
    },
    {
        id: "larache",
        label: "Larache",
    },
    {
        id: "guercif",
        label: "Guercif",
    },
    {
        id: "khemisset",
        label: "Khemisset",
    },
    {
        id: "sidi_kacem",
        label: "Sidi Kacem",
    },
    {
        id: "guelmim",
        label: "Guelmim",
    },
    {
        id: "tan_tan",
        label: "Tan-Tan",
    },
    {
        id: "zagora",
        label: "Zagora",
    },
    {
        id: "tinghir",
        label: "Tinghir",
    },
    {
        id: "midelt",
        label: "Midelt",
    },
    {
        id: "taourirt",
        label: "Taourirt",
    },
    {
        id: "berkane",
        label: "Berkane",
    },
    {
        id: "taroudant",
        label: "Taroudant",
    },
] as const
