import companyLogo from './screens/company-logo.png';
import loginHero from './heros/login-hero.png';
import companyLogoGold  from './screens/company-logo-gold.png';
import tractorLogo  from './screens/tractor.png';
import excavatorLogo from './screens/excavator.png';
import availabilityRate from './screens/availability-rate.png';
import completedPreventiveMaintenanceInterventions from './screens/completed-preventive-maintenance-interventions.png';
import costOfMaterialsAndConsumables from './screens/cost-of-materials-and-consumables.png';
import inProgressCorrectiveMaintenanceInterventions from './screens/in-progress-corrective-maintenance-interventions.png';
import inProgressPreventiveMaintenanceInterventions from './screens/in-progress-preventive-maintenance-interventions.png';
import plannedPreventiveInterventions from './screens/planned-preventive-interventions.png';

const images = {
    companyLogo,
    companyLogoGold,
    loginHero,
    tractorLogo,
    excavatorLogo,
    availabilityRate,
    completedPreventiveMaintenanceInterventions,
    costOfMaterialsAndConsumables,
    inProgressCorrectiveMaintenanceInterventions,
    inProgressPreventiveMaintenanceInterventions,
    plannedPreventiveInterventions
};

export default images;