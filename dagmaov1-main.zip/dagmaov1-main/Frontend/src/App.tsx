import React, {useEffect, useState} from 'react';
import {Routes, Route, useLocation} from 'react-router-dom';
import axios from 'axios';
import Navbar from '@/components/navbar/Navbar';
import LoginPage from '@/pages/LoginPage';
import DashboardPage from "@/pages/DashboardPage";
import {
    EquipmentRoutes,
    SparepartsRoutes,
    PreventiveMaintenanceRoutes,
    CorrectiveMaintenanceRoutes,
    CityRoutes, FarmRoutes, UserRoutes, InterventionRoutes
} from '@/routes';
import Authguard from "@/hoc/AuthGuard.tsx";
import {useSelector} from "react-redux";
import {RootState} from "@/store";
import NotFoundPage from "@/pages/NotFoundPage.tsx";
import "@/utils/interceptors/responseInterceptor.ts";
import "@/utils/interceptors/requestInterceptor.ts";
import Loader from "@/components/loader/Loader.tsx";

const BASE_URL = import.meta.env.VITE_BASE_URL;
axios.defaults.baseURL = `${BASE_URL}api/`;

const App: React.FC = () => {
    const [loading,setLoading] = useState(true);
    const users = useSelector((state: RootState) => state.users);
    const location = useLocation();
    const renderNavbar = !location.pathname.startsWith('/login') && users.auth;
    useEffect(()=>{
        if(users.auth !== null){
            setLoading(false)
        }
    },[users]);

    if (loading) {
        return <Loader loading={loading}/>;
    }
    return (
        <>
            {renderNavbar && <Navbar />}
            <>
                <Routes>
                    <Route path='/login' element={<LoginPage />} />
                    <Route path='*' element={<NotFoundPage/>} />
                    <Route path='/' element={<Authguard><DashboardPage/></Authguard>} />
                    <Route path='/equipment/*' element={<Authguard><EquipmentRoutes /></Authguard>} />
                    <Route path='/spare-parts/*' element={<Authguard><SparepartsRoutes /></Authguard>} />
                    <Route path='/preventive-maintenance/*' element={<Authguard><PreventiveMaintenanceRoutes /></Authguard>} />
                    <Route path='/corrective-maintenance/*' element={<Authguard><CorrectiveMaintenanceRoutes /></Authguard>} />
                    <Route path='/city/*' element={<Authguard><CityRoutes /></Authguard>} />
                    <Route path='/farm/*' element={<Authguard><FarmRoutes /></Authguard>} />
                    <Route path='/user/*' element={<Authguard><UserRoutes /></Authguard>} />
                    <Route path='/intervention/*' element={<Authguard><InterventionRoutes /></Authguard>} />
                </Routes>
            </>
        </>
    );
};

export default App;