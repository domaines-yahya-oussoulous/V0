// components/fields/TextInputField.tsx
import React from 'react';
import { FormField, FormItem, FormLabel, FormControl, FormDescription, FormMessage } from '@/components/ui/form.tsx';
import { Input } from '@/components/ui/input.tsx';
import { Control } from 'react-hook-form';

interface FormParameterFieldProps {
    control: Control<any>;
    name: string;
    label?: string; // Make label optional
    placeholder: string;
    description?: string;
    type?: string;
    required?: boolean;
}

const FormParameterField: React.FC<FormParameterFieldProps> = ({ control, name, label, placeholder, description, type = "text" , required = false}) => (
    <FormField control={control} name={name} render={({ field }) => (
        <FormItem>
            {label && <FormLabel required={required}>{label}</FormLabel>}
            <FormControl>
                <Input placeholder={placeholder} type={type} {...field} className="w-full" />
            </FormControl>
            {description && <FormDescription>{description}</FormDescription>}
            <FormMessage />
        </FormItem>
    )} />
);

export default FormParameterField;
