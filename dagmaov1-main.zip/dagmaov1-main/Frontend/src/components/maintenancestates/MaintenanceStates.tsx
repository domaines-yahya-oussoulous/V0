// StateBadge.tsx

import React from 'react';

interface MaintenanceStatesProps {
    state: string;
}

const MaintenanceStates: React.FC<MaintenanceStatesProps> = ({ state }) => {
    let stateClass = "";
    let stateText = "";

    switch (state) {
        case "PLANNED":
            stateClass = "text-blue-600 font-bold";
            stateText = "Planned";
            break;
        case "IN_PROGRESS":
            stateClass = "text-yellow-600 font-bold";
            stateText = "In Progress";
            break;
        case "COMPLETED":
            stateClass = "text-green-600 font-bold";
            stateText = "Completed";
            break;
        default:
            stateClass = "text-gray-600 font-bold";
            stateText = state;
            break;
    }

    return <span className={stateClass}>{stateText}</span>;
};

export default MaintenanceStates;
