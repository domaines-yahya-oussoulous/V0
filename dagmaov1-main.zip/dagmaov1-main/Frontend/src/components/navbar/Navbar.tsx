import * as React from "react";
import { Link, NavLink } from "react-router-dom";
import { LogOut } from "lucide-react";
import images from "@/assets/images";
import {
    NavigationMenu,
    NavigationMenuContent,
    NavigationMenuItem,
    NavigationMenuList,
    NavigationMenuTrigger,
    navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu";
import { cn } from "@/lib/utils.ts";

// Import Lucide icons
import { Menu, X } from "lucide-react";
import { useDispatch } from "react-redux";
import { logout } from "@/features/login/loginSlice.ts";
import ConfirmationModal from "@/components/confirmationmodal/ConfirmationModal.tsx";
import { useState } from "react";

const Navbar: React.FC = () => {
    const dispatch = useDispatch();
    const [menuOpen, setMenuOpen] = React.useState(false);
    const [subMenuOpen, setSubMenuOpen] = useState<{ [key: string]: boolean }>({});
    const [logoutModalOpen, setLogoutModalOpen] = useState(false);

    const toggleMenu = () => {
        setMenuOpen(!menuOpen);
    };
    const toggleSubMenu = (menu: string) => {
        setSubMenuOpen(prev => ({ ...prev, [menu]: !prev[menu] }));
    };
    const handleLogoutConfirm = () => {
        dispatch(logout()); // Dispatch logout action
        setLogoutModalOpen(false); // Close the logout confirmation modal
    };

    return (
        <>
            <nav className="sticky inset-x-0 top-0 z-50 bg-[#9e8116] shadow-sm dark:bg-gray-950/90 text-white h-20">
                <div className="w-full max-w-7xl mx-auto px-4 h-full flex justify-between items-center">
                    <Link to="/">
                        <img
                            src={images.companyLogo}
                            alt="Company Logo"
                            className="h-24 w-24 object-contain"
                        />
                    </Link>
                    <div className="hidden md:flex space-x-4">
                        <NavigationMenu>
                            <NavigationMenuList>
                                <NavigationMenuItem>
                                    <NavLink to="/" className={navigationMenuTriggerStyle()}>
                                        Dashboard
                                    </NavLink>
                                </NavigationMenuItem>
                                <NavigationMenuItem>
                                    <NavigationMenuTrigger>Work Orders</NavigationMenuTrigger>
                                    <NavigationMenuContent>
                                        <ul className="grid gap-3 p-6 md:w-[400px]">
                                            <NavListItem
                                                to="preventive-maintenance/add"
                                                title="Preventive Maintenance"
                                            >
                                                Schedule preventive maintenance
                                            </NavListItem>
                                            <NavListItem to="corrective-maintenance/add" title="Corrective Maintenance">
                                                Manage corrective maintenance
                                            </NavListItem>
                                            <NavListItem
                                                to="preventive-maintenance"
                                                title="Preventive Maintenance Work Orders"
                                            >
                                                View your preventive maintenance work orders
                                            </NavListItem>
                                            <NavListItem
                                                to="corrective-maintenance"
                                                title="Corrective Maintenance Work Orders"
                                            >
                                                View your corrective maintenance work orders
                                            </NavListItem>
                                        </ul>
                                    </NavigationMenuContent>
                                </NavigationMenuItem>
                                <NavigationMenuItem>
                                    <NavigationMenuTrigger>Admin Settings</NavigationMenuTrigger>
                                    <NavigationMenuContent>
                                        <ul className="grid gap-3 p-6 md:w-[400px]">
                                            <NavListItem to="/equipment/category" title="Equipment Categories">
                                                Manage Equipment Categories
                                            </NavListItem>
                                            <NavListItem to="/spare-parts/category" title="Spare Parts Categories">
                                                Manage Spare Parts Categories
                                            </NavListItem>
                                            <NavListItem to="/farm" title="Farms">
                                                Manage Farms
                                            </NavListItem>
                                            <NavListItem to="/city" title="Cities">
                                                Manage cities
                                            </NavListItem>
                                            <NavListItem to="/user" title="Users">
                                                Manage users
                                            </NavListItem>
                                            <NavListItem to="/intervention" title="Interventions">
                                                Manage Interventions
                                            </NavListItem>
                                            <NavListItem to="/equipment/category/interventions" title="Intervention Assignments">
                                                Associate Interventions with Equipment Categories
                                            </NavListItem>
                                        </ul>
                                    </NavigationMenuContent>
                                </NavigationMenuItem>
                                <NavigationMenuItem>
                                    <NavLink to="/planning" className={navigationMenuTriggerStyle()}>
                                        Planning
                                    </NavLink>
                                </NavigationMenuItem>
                                <NavigationMenuItem>
                                    <NavLink to="/equipment" className={navigationMenuTriggerStyle()}>
                                        Equipment
                                    </NavLink>
                                </NavigationMenuItem>
                                <NavigationMenuItem>
                                    <NavLink to="/spare-parts" className={navigationMenuTriggerStyle()}>
                                        Stock
                                    </NavLink>
                                </NavigationMenuItem>
                            </NavigationMenuList>
                        </NavigationMenu>
                    </div>
                    <div className="flex items-center gap-4 text-black">
                        <LogOut
                            size="40px"
                            className="text-white cursor-pointer p-2 rounded-md transition duration-300 ease-in-out hover:bg-white hover:bg-opacity-10"
                            onClick={() => setLogoutModalOpen(true)}
                        />
                    </div>
                    <div className="md:hidden">
                        <button onClick={toggleMenu} className="focus:outline-none">
                            {menuOpen ? <X size={24}/> : <Menu size={24}/>}
                        </button>
                    </div>
                </div>
                {menuOpen && (
                    <div className="md:hidden bg-white shadow-sm dark:bg-gray-950/90">
                        <div className="px-4 pt-2 pb-4 space-y-1">
                            <NavLink to="/" className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                     onClick={toggleMenu}>Dashboard</NavLink>
                            <div>
                                <button
                                    className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100 w-full text-left"
                                    onClick={() => toggleSubMenu('adminsettings')}>
                                    admin settings
                                </button>
                                {subMenuOpen['adminsettings'] && (
                                    <div className="pl-4">
                                        <NavLink to="/equipment/category"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Equipment Categories</NavLink>
                                        <NavLink to="/spare-parts/category"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Spare Parts Categories</NavLink>
                                        <NavLink to="/farm"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Farms</NavLink>
                                        <NavLink to="/city"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Cities</NavLink>
                                        <NavLink to="/user"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Users</NavLink>
                                        <NavLink to="/intervention"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Interventions</NavLink>
                                        <NavLink to="/equipment/category/interventions"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Interventions Affectation</NavLink>
                                    </div>
                                )}
                            </div>
                            <div>
                                <button
                                    className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100 w-full text-left"
                                    onClick={() => toggleSubMenu('workorder')}>
                                    Work Orders
                                </button>
                                {subMenuOpen['workorder'] && (
                                    <div className="pl-4">
                                        <NavLink to="preventive-maintenance/add"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Preventive Maintenance</NavLink>
                                        <NavLink to="corrective-maintenance/add"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Corrective Maintenance</NavLink>
                                        <NavLink to="preventive-maintenance"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Preventive Maintenance Work Orders</NavLink>
                                        <NavLink to="corrective-maintenance"
                                                 className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                                 onClick={toggleMenu}>Corrective Maintenance Work Orders</NavLink>
                                    </div>
                                )}
                            </div>
                            <NavLink to="/planning" className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                     onClick={toggleMenu}>Planning</NavLink>
                            <NavLink to="/equipment" className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                     onClick={toggleMenu}>Equipment</NavLink>
                            <NavLink to="/spare-parts" className="block px-4 py-2 text-sm text-gray-800 hover:bg-gray-100"
                                     onClick={toggleMenu}>Stock</NavLink>
                        </div>
                    </div>
                )}
            </nav>
            <ConfirmationModal
                isOpen={logoutModalOpen}
                onClose={() => setLogoutModalOpen(false)}
                onConfirm={handleLogoutConfirm}
                message="Are you sure you want to log out?"
            />
        </>
    );
};

const NavListItem: React.FC<{
    to: string;
    title: string;
    children: React.ReactNode;
}> = ({to, title, children}) => {
    return (
        <li>
            <NavLink
                to={to}
                className={cn(
                    "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground"
                )}
            >
                <div className="text-sm font-medium leading-none">{title}</div>
                <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">
                    {children}
                </p>
            </NavLink>
        </li>
    );
};

export default Navbar;