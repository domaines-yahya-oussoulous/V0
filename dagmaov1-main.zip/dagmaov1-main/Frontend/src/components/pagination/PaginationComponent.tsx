import React from 'react';
import {
    Pagination,
    PaginationContent,
    PaginationEllipsis,
    PaginationItem,
    PaginationLink,
    PaginationNext,
    PaginationPrevious,
} from "@/components/ui/pagination";

interface PaginationProps {
    currentPage: number;
    totalPages: number;
    onPageChange: (page: number) => void;
}

const PaginationComponent: React.FC<PaginationProps> = ({ currentPage, totalPages, onPageChange }) => {
    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            onPageChange(page);
        }
    };

    const renderPageLinks = () => {
        const pageLinks = [];
        for (let i = 1; i <= totalPages; i++) {
            pageLinks.push(
                <PaginationItem key={i}>
                    <PaginationLink href="#" isActive={i === currentPage} onClick={() => handlePageChange(i)}>
                        {i}
                    </PaginationLink>
                </PaginationItem>
            );
        }
        return pageLinks;
    };

    return (
        <Pagination className="flex justify-center items-center py-4">
            <PaginationContent className="flex flex-wrap md:flex-nowrap overflow-x-auto scrollbar-hide">
                <PaginationItem>
                    <PaginationPrevious
                        href="#"
                        onClick={() => handlePageChange(currentPage - 1)}
                        className={`${
                            currentPage <= 1 ? 'opacity-50 pointer-events-none' : 'cursor-pointer'
                        }`}
                    >
                        Previous
                    </PaginationPrevious>
                </PaginationItem>
                {renderPageLinks()}
                {totalPages > 5 && (
                    <PaginationItem className="hidden md:block">
                        <PaginationEllipsis />
                    </PaginationItem>
                )}
                <PaginationItem>
                    <PaginationNext
                        href="#"
                        onClick={() => handlePageChange(currentPage + 1)}
                        className={`${
                            currentPage >= totalPages ? 'opacity-50 pointer-events-none' : 'cursor-pointer'
                        }`}
                    >
                        Next
                    </PaginationNext>
                </PaginationItem>
            </PaginationContent>
        </Pagination>
    );
};

export default PaginationComponent;
