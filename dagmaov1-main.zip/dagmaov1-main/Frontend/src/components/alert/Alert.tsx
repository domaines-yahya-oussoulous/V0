import React from 'react';

export const Alert: React.FC<{ type: 'success' | 'error', message: string }> = ({ type, message }) => {
    const alertClasses = {
        success: 'bg-green-500',
        error: 'bg-red-500',
    };

    const iconClasses = {
        success: 'text-green-100',
        error: 'text-red-100',
    };

    return (
        <div className={`fixed bottom-4 right-4 w-80 px-4 py-3 rounded-md shadow-lg ${alertClasses[type]} text-white flex items-center`} role="alert">
            <svg className={`h-5 w-5 ${iconClasses[type]} mr-2`} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16zm-1.293-5.293a1 1 0 0 1 1.414-1.414L10 11.586l2.293-2.293a1 1 0 0 1 1.414 1.414L11.414 13l2.293 2.293a1 1 0 0 1-1.414 1.414L10 14.414l-2.293 2.293a1 1 0 1 1-1.414-1.414L8.586 13 6.293 10.707a1 1 0 1 1 1.414-1.414L10 11.586l2.293-2.293a1 1 0 1 1 1.414 1.414L11.414 13l2.293 2.293a1 1 0 0 1-1.414 1.414L10 14.414l-2.293 2.293a1 1 0 0 1-1.414 0z" clipRule="evenodd" />
            </svg>
            <div>
                <p className="text-sm font-medium">{message}</p>
            </div>
        </div>
    );
};
