import React from 'react';
import { Button } from '@/components/ui/button.tsx';

interface ConfirmationModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    message: string;
}

const ConfirmationModal: React.FC<ConfirmationModalProps> = ({ isOpen, onClose, onConfirm, message }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 max-w-sm w-full mx-4 sm:mx-0">
                <p className="text-lg font-semibold mb-4">Confirm Action</p>
                <p className="mb-6 text-gray-700">{message}</p>
                <div className="flex flex-col sm:flex-row sm:justify-end gap-4">
                    <Button
                        onClick={onConfirm}
                        className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors w-full sm:w-auto"
                    >
                        Yes
                    </Button>
                    <Button
                        onClick={onClose}
                        className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400 transition-colors w-full sm:w-auto"
                    >
                        Cancel
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default ConfirmationModal;
