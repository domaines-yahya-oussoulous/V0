import React, { useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Button } from "@/components/ui/button.tsx";

interface MessageModalProps {
    LeftButtonLabel: string;
    text: string;
    visible: boolean;
    success: boolean;
    onPressEvent?: () => void;
}

const MessageModal: React.FC<MessageModalProps> = ({ LeftButtonLabel, text, visible, success, onPressEvent }) => {
    useEffect(() => {
        if (visible) {
            // Add class to body to block scroll
            document.body.style.overflow = 'hidden';
        } else {
            // Remove class from body to enable scroll
            document.body.style.overflow = 'auto';
        }

        // Cleanup: Remove class when component unmounts or visibility changes
        return () => {
            document.body.style.overflow = 'auto';
        };
    }, [visible]);

    if (!visible) return null;

    return createPortal(
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white p-8 max-w-lg mx-auto">
                <p className="text-center mb-6 text-gray-600 text-xl font-semibold">{text}</p>
                <div className="flex justify-center">
                    <Button
                        className={`py-3 px-6 rounded-sm ${success ? 'bg-green-400 hover:bg-green-200' : 'bg-red-800 hover:bg-red-500 '} text-white`}
                        onClick={onPressEvent}
                    >
                        {LeftButtonLabel}
                    </Button>
                </div>
            </div>
        </div>,
        document.body
    );
};

export default MessageModal;
