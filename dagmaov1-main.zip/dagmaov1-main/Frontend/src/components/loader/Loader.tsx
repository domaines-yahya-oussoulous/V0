import React from 'react';
import { HashLoader } from "react-spinners";

interface LoaderProps {
    loading: boolean;
    size?: number;
    color?: string;
}

const Loader: React.FC<LoaderProps> = ({ loading, size = 220, color = "#9e8116" }) => {
    React.useEffect(() => {
        document.body.style.overflow = loading ? 'hidden' : 'auto';
        return () => {
            document.body.style.overflow = 'auto';
        };
    }, [loading]);

    return (
        <div className={`absolute inset-0 flex justify-center items-center ${loading ? 'block' : 'hidden'} bg-white bg-opacity-50`}>
            <HashLoader
                color={color}
                loading={loading}
                size={size}
                aria-label="Loading Spinner"
                data-testid="loader"
            />
        </div>
    );
};

export default Loader;
