import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
    Select,
    SelectContent,
    SelectGroup,
    SelectItem,
    SelectLabel,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select"; // Ajustez le chemin d'importation si nécessaire

const WorkOrderPageSelector: React.FC = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [selectedPage, setSelectedPage] = useState('');

    useEffect(() => {
        // Extraire le chemin à partir de location.pathname
        setSelectedPage(location.pathname);
    }, [location]);

    const handleSelectChange = (value: string) => {
        setSelectedPage(value);
        if (value) {
            navigate(value);
        }
    };

    return (
        <div className="maintenance-page-selector">
            <Select onValueChange={handleSelectChange} value={selectedPage}>
                <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select a page" />
                </SelectTrigger>
                <SelectContent>
                    <SelectGroup>
                        <SelectLabel>Pages</SelectLabel>
                        <SelectItem value="/preventive-maintenance">Preventive</SelectItem>
                        <SelectItem value="/corrective-maintenance">Corrective</SelectItem>
                    </SelectGroup>
                </SelectContent>
            </Select>
        </div>
    );
};

export default WorkOrderPageSelector;
