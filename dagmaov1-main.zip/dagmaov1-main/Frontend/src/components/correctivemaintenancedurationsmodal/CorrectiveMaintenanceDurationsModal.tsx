import React, { useState } from 'react';
import { Button } from '@/components/ui/button.tsx';
import { Label } from '@/components/ui/label.tsx';
import { Input } from '@/components/ui/input.tsx';

interface CompleteModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (realDownTime: number, realDownTimeUnit: string, interventionRealDuration: number, interventionRealDurationUnit: string) => void;
}

const units = ['HOURS', 'DAYS', 'MONTHS']; // Define your units here

const CorrectiveMaintenanceDurationsModal: React.FC<CompleteModalProps> = ({ isOpen, onClose, onConfirm }) => {
    const [realDownTime, setRealDownTime] = useState<string>('');
    const [realDownTimeUnit, setRealDownTimeUnit] = useState<string>(units[0]);
    const [interventionRealDuration, setInterventionRealDuration] = useState<string>('');
    const [interventionRealDurationUnit, setInterventionRealDurationUnit] = useState<string>(units[0]);

    const handleConfirm = () => {
        const realDownTimeNum = parseFloat(realDownTime);
        const interventionRealDurationNum = parseFloat(interventionRealDuration);

        if (!isNaN(realDownTimeNum) && !isNaN(interventionRealDurationNum)) {
            onConfirm(realDownTimeNum, realDownTimeUnit, interventionRealDurationNum, interventionRealDurationUnit);
        } else {
            alert("Please enter valid numbers for real down time and intervention real duration.");
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50 p-4 sm:p-6">
            <div className="bg-white rounded-lg overflow-hidden shadow-lg w-full max-w-xl sm:max-w-2xl">
                <div className="p-4 sm:p-6 border-b">
                    <h3 className="text-lg sm:text-2xl font-semibold">Complete Maintenance</h3>
                </div>
                <div className="p-4 sm:p-6 overflow-y-auto max-h-96">
                    <div className="space-y-4">
                        <div>
                            <Label htmlFor="realDownTime" className="block text-sm font-medium text-gray-700">
                                Real Down Time
                            </Label>
                            <Input
                                id="realDownTime"
                                type="text"
                                value={realDownTime}
                                onChange={(e) => setRealDownTime(e.target.value)}
                                placeholder="Enter real down time"
                                className="mt-1 p-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
                            />
                        </div>
                        <div>
                            <Label htmlFor="realDownTimeUnit" className="block text-sm font-medium text-gray-700">
                                Real Down Time Unit
                            </Label>
                            <select
                                id="realDownTimeUnit"
                                value={realDownTimeUnit}
                                onChange={(e) => setRealDownTimeUnit(e.target.value)}
                                className="mt-1 p-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
                            >
                                {units.map((unit) => (
                                    <option key={unit} value={unit}>{unit}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <Label htmlFor="interventionRealDuration" className="block text-sm font-medium text-gray-700">
                                Intervention Real Duration
                            </Label>
                            <Input
                                id="interventionRealDuration"
                                type="text"
                                value={interventionRealDuration}
                                onChange={(e) => setInterventionRealDuration(e.target.value)}
                                placeholder="Enter intervention real duration"
                                className="mt-1 p-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
                            />
                        </div>
                        <div>
                            <Label htmlFor="interventionRealDurationUnit" className="block text-sm font-medium text-gray-700">
                                Intervention Real Duration Unit
                            </Label>
                            <select
                                id="interventionRealDurationUnit"
                                value={interventionRealDurationUnit}
                                onChange={(e) => setInterventionRealDurationUnit(e.target.value)}
                                className="mt-1 p-2 w-full border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
                            >
                                {units.map((unit) => (
                                    <option key={unit} value={unit}>{unit}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                </div>
                <div className="p-4 sm:p-6 border-t flex justify-end">
                    <Button onClick={onClose} className="mr-2 sm:mr-3">Cancel</Button>
                    <Button onClick={handleConfirm} className="bg-blue-500 text-white">Confirm</Button>
                </div>
            </div>
        </div>
    );
};

export default CorrectiveMaintenanceDurationsModal;
