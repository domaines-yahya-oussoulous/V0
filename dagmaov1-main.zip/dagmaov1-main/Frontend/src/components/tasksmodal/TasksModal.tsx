import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Button } from '@/components/ui/button.tsx';
import { Label } from '@/components/ui/label.tsx';
import { Textarea } from '@/components/ui/textarea.tsx';
import { CheckSquare, XSquare } from 'lucide-react'; // Importing React Lucide icons

interface Task {
    id: string;
    description: string;
    interventionId: string;
}

interface TasksModalProps {
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (selectedTasks: string[], description: string) => void;
    interventionId: string; // Added interventionId to props interface
}

const TasksModal: React.FC<TasksModalProps> = ({ isOpen, onClose, onConfirm, interventionId }) => {
    const [tasks, setTasks] = useState<Task[]>([]);
    const [selectedTasks, setSelectedTasks] = useState<string[]>([]);
    const [description, setDescription] = useState<string>('');

    useEffect(() => {
        if (isOpen) {
            const fetchTasks = async () => {
                try {
                    const response = await axios.get(`/intervention-operations/${interventionId}`);
                    setTasks(response.data.operations);
                } catch (error) {
                    console.error('Error fetching tasks:', error);
                }
            };

            fetchTasks();
        }
    }, [isOpen, interventionId]);

    const handleCheckboxChange = (taskId: string) => {
        setSelectedTasks((prevSelectedTasks) =>
            prevSelectedTasks.includes(taskId)
                ? prevSelectedTasks.filter((id) => id !== taskId)
                : [...prevSelectedTasks, taskId]
        );
    };

    const handleConfirm = () => {
        onConfirm(selectedTasks, description);
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-40 p-4 sm:p-6">
            <div className="bg-white rounded-lg overflow-hidden shadow-lg w-full max-w-xl sm:max-w-2xl">
                <div className="p-4 sm:p-6 border-b border-gray-200 bg-gray-100">
                    <h3 className="text-lg sm:text-2xl font-semibold text-gray-800 flex items-center">
                        <CheckSquare className="mr-2 text-blue-600" />
                        Select Tasks
                    </h3>
                </div>
                <div className="p-4 sm:p-6 bg-gray-50">
                    <div className="space-y-4">
                        {tasks.map((task) => (
                            <div key={task.id} className="flex items-start">
                                <input
                                    type="checkbox"
                                    id={task.id}
                                    checked={selectedTasks.includes(task.id)}
                                    onChange={() => handleCheckboxChange(task.id)}
                                    className="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                />
                                <Label htmlFor={task.id} className="ml-3 text-sm sm:text-lg text-gray-700 break-all">
                                    {task.description}
                                </Label>
                            </div>
                        ))}
                        <Textarea
                            value={description}
                            onChange={(e) => setDescription(e.target.value)}
                            placeholder="Enter description"
                            className="mt-4 w-full p-2 sm:p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring focus:ring-blue-500"
                            rows={4}
                        />
                    </div>
                </div>
                <div className="p-4 sm:p-6 border-t border-gray-200 bg-gray-100 flex justify-end">
                    <Button onClick={onClose} className="mr-2 sm:mr-3 bg-red-600 text-white hover:bg-red-500">
                        <XSquare className="mr-1" />
                        Cancel
                    </Button>
                    <Button onClick={handleConfirm} className="bg-blue-600 text-white hover:bg-blue-700">
                        <CheckSquare className="mr-1" />
                        Confirm
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default TasksModal;
