import React from 'react';

interface DashboardCardProps {
    imageSrc?: string; // Make imageSrc optional
    title: string;
    progress?: number; // Make progress optional
    badgeValue: string;
}

const getBadgeColor = (progress?: number): string => {
    if (progress === undefined) return 'bg-gradient-to-r from-blue-400 to-blue-600'; // Default to blue if no progress
    if (progress < 30) return 'bg-gradient-to-r from-red-400 to-red-600';
    if (progress >= 30 && progress <= 70) return 'bg-gradient-to-r from-yellow-400 to-yellow-600';
    return 'bg-gradient-to-r from-green-400 to-green-600';
};

const getProgressColor = (progress: number): string => {
    if (progress < 30) return 'bg-gradient-to-r from-red-300 to-red-500';
    if (progress >= 30 && progress <= 70) return 'bg-gradient-to-r from-yellow-300 to-yellow-500';
    return 'bg-gradient-to-r from-green-300 to-green-500';
};

const DashboardCard: React.FC<DashboardCardProps> = ({
                                                         imageSrc,
                                                         title,
                                                         progress,
                                                         badgeValue
                                                     }) => {
    const badgeColor = getBadgeColor(progress);
    const progressColor = progress !== undefined ? getProgressColor(progress) : '';

    return (
        <div className="bg-white shadow-sm rounded-lg border border-gray-100 overflow-hidden flex flex-col sm:flex-row items-start sm:items-center sm:space-x-2 p-2 sm:p-3 transition-transform transform hover:scale-105 hover:shadow-md">
            {/* Conditionally render the image only if imageSrc is provided */}
            {imageSrc && (
                <img
                    src={imageSrc}
                    alt={title}
                    className="w-12 h-12 sm:w-16 sm:h-16 object-cover rounded-lg border-2 border-gray-100 shadow-sm"
                />
            )}
            <div className="flex-1 flex flex-col justify-between mt-2 sm:mt-0">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-2">
                    <h2 className="text-sm sm:text-base font-semibold text-gray-800">{title}</h2>
                    <div
                        className={`text-xs sm:text-sm font-semibold inline-block py-1 px-2 sm:px-3 rounded-full text-white ${badgeColor}`}
                    >
                        {badgeValue}
                    </div>
                </div>

                {/* Only render the progress bar if progress is defined */}
                {progress !== undefined && (
                    <div className="relative w-64 md:w-full">
                        <div className="flex items-center mb-1">
                            <span className="text-xs sm:text-sm font-medium text-gray-500">Progress</span>
                        </div>
                        <div className="relative pt-1">
                            <div className="flex-grow h-1 sm:h-2 bg-gray-200 rounded-full shadow-inner">
                                <div
                                    className={`h-full ${progressColor} rounded-full transition-all duration-300 ease-in-out`}
                                    style={{ width: `${progress}%` }}
                                    aria-label={`Progress bar: ${progress}%`}
                                ></div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default DashboardCard;
