import { combineReducers } from '@reduxjs/toolkit';
import equipmentSlice from "@/features/equipment/EquipmentSlice.ts";
import preventiveMaintenanceSlice from "@/features/preventive-maintenance/PreventiveMaintenanceSlice.ts";
import sparePartsSlice from "@/features/spareparts/SparePartsSlice.ts";
import correctiveMaintenanceSlice from "@/features/corrective-maintenance/CorrectiveMaintenanceSlice.ts";
import loginSlice from "@/features/login/loginSlice.ts";
import CitySlice from "@/features/city/CitySlice.ts";
import FarmSlice from "@/features/farm/FarmSlice.ts";
import EquipmentCategorySlice from "@/features/equipment/category/EquipmentCategorySlice.ts";
import SparepartsCategorySlice from "@/features/spareparts/category/SparepartsCategorySlice.ts";
import UserSlice from "@/features/user/UserSlice.ts";
import InterventionSlice from "@/features/intervention/InterventionSlice.ts";

const rootReducer = combineReducers({
    equipment: equipmentSlice,
    spareParts: sparePartsSlice,
    preventiveMaintenance: preventiveMaintenanceSlice,
    correctiveMaintenance: correctiveMaintenanceSlice,
    users: loginSlice,
    cities: CitySlice,
    farms: FarmSlice,
    equipmentCategories: EquipmentCategorySlice,
    sparePartsCategories: SparepartsCategorySlice,
    user: UserSlice,
    interventions: InterventionSlice
});

export default rootReducer;
