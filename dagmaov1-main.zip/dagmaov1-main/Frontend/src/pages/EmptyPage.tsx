import React from 'react';

const EmptyPag: React.FC = () => {
    return (
        <div>
            <h1>empty</h1>
            {/* Your content here */}
        </div>
    );
};

export default EmptyPag;
