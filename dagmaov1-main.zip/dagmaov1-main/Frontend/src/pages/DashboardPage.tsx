import React, {useState, useEffect} from 'react';
import axios from 'axios';
import {Button} from "@/components/ui/button.tsx";
import {Input} from "@/components/ui/input.tsx";
import {Label} from "@/components/ui/label.tsx";
import {Search, X, Home, BarChart, Box, Bell} from "lucide-react"; // Import icons
import DomainPage from "@/features/dashboard/domain/DomainPage.tsx";
import KpisPage from "@/features/dashboard/kpis/KpisPage.tsx";
import EquipmentsPage from "@/features/dashboard/equipments/EquipmentsPage.tsx";
import AlertsPage from "@/features/dashboard/alerts/AlertsPage.tsx";
import { Toaster } from "@/components/ui/toaster.tsx";
import {toast} from "@/components/ui/use-toast.ts";

const DashboardPage: React.FC = () => {
    const [isSearchPanelVisible, setSearchPanelVisible] = useState(false);
    const [currentView, setCurrentView] = useState<'domain' | 'kpis' | 'equipments' | 'alerts'>('domain');
    const [farms, setFarms] = useState<any[]>([]);
    const [farmsId, setFarmsId] = useState<number[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [loading, setLoading] = useState(true); // Add loading state
    const toggleSearchPanel = () => {
        setSearchPanelVisible(prev => !prev);
    };

    const handleViewChange = (view: 'domain' | 'kpis' | 'equipments' | 'alerts') => {
        setCurrentView(view);
    };

    useEffect(() => {
        const fetchFarms = async () => {
            setLoading(true);
            try {
                const response = await axios.get('farms');
                const fetchedFarms = response.data['hydra:member'];
                setFarms(fetchedFarms);

                if (fetchedFarms.length > 0) {
                    setFarmsId([fetchedFarms[0].id]);
                }
            } catch (error) {
                toast({
                    title: "Error",
                    description: "Error fetching farms",
                    variant: "destructive",
                });
            }finally {
                setLoading(false);
            }
        };

        fetchFarms();
    }, []);

    const handleCheckboxChange = (id: number, isChecked: boolean) => {
        setFarmsId(prevFarmsId => {
            if (isChecked) {
                return [...prevFarmsId, id];
            } else {
                return prevFarmsId.filter(farmId => farmId !== id);
            }
        });
    };

    const handleSelectAllChange = (isChecked: boolean) => {
        if (isChecked) {
            setFarmsId(filteredFarms.map(farm => farm.id));  // Select only filtered farms
        } else {
            setFarmsId(prevFarmsId => prevFarmsId.filter(id => !filteredFarms.some(farm => farm.id === id)));  // Deselect only filtered farms
        }
    };

    const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setSearchTerm(value);
        setFarmsId([]);  // Deselect all farms when typing
    };

    const filteredFarms = farms.filter(farm =>
        farm.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const isAllFilteredFarmsSelected = filteredFarms.length > 0 && filteredFarms.every(farm => farmsId.includes(farm.id));

    let CurrentViewComponent;
    switch (currentView) {
        case 'domain':
            CurrentViewComponent = () => <DomainPage farmsId={farmsId}/>;
            break;
        case 'kpis':
            CurrentViewComponent = KpisPage;
            break;
        case 'equipments':
            CurrentViewComponent = EquipmentsPage;
            break;
        case 'alerts':
            CurrentViewComponent = AlertsPage;
            break;
        default:
            CurrentViewComponent = () => <DomainPage farmsId={farmsId}/>;
    }

    const buttonStyles = (view: 'domain' | 'kpis' | 'equipments' | 'alerts') => {
        const baseStyles = 'text-sm px-4 py-2 rounded-md transition-all duration-300 flex items-center justify-center shadow-lg hover:shadow-xl transform hover:scale-105';
        let activeStyles = '';
        let hoverStyles = '';

        switch (view) {
            case 'domain':
                activeStyles = 'bg-blue-600 text-white';
                hoverStyles = 'hover:bg-blue-700';
                break;
            case 'kpis':
                activeStyles = 'bg-green-600 text-white';
                hoverStyles = 'hover:bg-green-700';
                break;
            case 'equipments':
                activeStyles = 'bg-yellow-600 text-white';
                hoverStyles = 'hover:bg-yellow-700';
                break;
            case 'alerts':
                activeStyles = 'bg-red-600 text-white';
                hoverStyles = 'hover:bg-red-700';
                break;
            default:
                activeStyles = 'bg-gray-200 text-gray-800';
                hoverStyles = 'hover:bg-gray-300';
        }

        return `${baseStyles} ${currentView === view ? activeStyles : 'bg-gray-200 text-gray-800'} ${hoverStyles}`;
    };

    return (<>
        <div className="relative h-screen flex flex-col md:flex-row bg-gray-100">
            {/* Sidebar */}
            <div
                className={`border-t-4 border-r-4 z-40 md:z-0 absolute md:relative p-4 top-[75px] md:top-0 bg-gray-50 shadow-lg overflow-auto flex flex-col w-full max-w-[300px] md:w-auto h-full transition-transform duration-300 ease-in-out ${isSearchPanelVisible ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0`}>
                <div className="relative mt-2 w-11/12 mx-auto">
    <span className="absolute inset-y-0 left-0 flex items-center pl-3">
        <Search className="w-5 h-5 text-gray-400"/>
    </span>
                    <Input
                        type="text"
                        placeholder="Search"
                        className="pl-10 pr-4 py-2 w-full rounded-lg border border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        value={searchTerm}
                        onChange={handleSearchChange}
                    />
                </div>
                <div className="p-5 flex flex-col space-y-4">
                    {loading ? (
                        <div className="flex items-center justify-center h-24">
                            <div
                                className="w-8 h-8 border-4 border-t-4 border-[#9e8116] border-solid rounded-full animate-spin"></div>
                        </div>
                    ) : (
                        <>
                            <div
                                className="flex py-2 pr-12 items-center space-x-2 bg-white rounded-lg p-6 border border-blue-300 shadow-sm transition-transform duration-200 transform hover:scale-105">
                                <input
                                    type="checkbox"
                                    id="select-all"
                                    checked={isAllFilteredFarmsSelected}
                                    onChange={(e) => handleSelectAllChange(e.target.checked)}
                                />
                                <Label htmlFor="select-all" className="font-semibold text-gray-700">Select all</Label>
                            </div>
                            {filteredFarms.map((farm) => (
                                <div key={farm.id}
                                     className="flex py-2 pr-12 items-center space-x-2 bg-white rounded-lg p-6 border shadow-sm transition-transform duration-200 transform hover:scale-105">
                                    <input
                                        type="checkbox"
                                        id={`checkbox-${farm.id}`}
                                        checked={farmsId.includes(farm.id)}
                                        onChange={(e) => handleCheckboxChange(farm.id, e.target.checked)}
                                    />
                                    <Label htmlFor={`checkbox-${farm.id}`} className="text-gray-700">{farm.name}</Label>
                                </div>
                            ))}
                        </>
                    )}
                </div>
        </div>

    {/* Main Content and Navbar */
    }
    <div className="flex flex-col flex-1">
        <nav
            className="sticky top-0 p-4 text-white shadow-lg z-30 border-b-2 bg-gray-50 border-muted transition-transform duration-300">
            <div className="flex items-center justify-between md:justify-around">
                <div className="md:hidden flex items-center">
                    {isSearchPanelVisible ? (
                        <X className="w-6 h-6 text-red-400 cursor-pointer transition-transform duration-200 transform hover:scale-110"
                           onClick={toggleSearchPanel}/>
                    ) : (
                        <Search
                            className="w-6 h-6 text-gray-800 cursor-pointer transition-transform duration-200 transform hover:scale-110"
                            onClick={toggleSearchPanel}/>
                    )}
                </div>
                <div className="hidden md:flex space-x-8">
                    <Button className={buttonStyles('domain')} onClick={() => handleViewChange('domain')}>
                        <Home className="w-5 h-5"/> <span className="ml-2">Domain</span>
                    </Button>
                    <Button className={buttonStyles('kpis')} onClick={() => handleViewChange('kpis')}>
                        <BarChart className="w-5 h-5"/> <span className="ml-2">Kpis</span>
                    </Button>
                    <Button className={buttonStyles('equipments')}
                            onClick={() => handleViewChange('equipments')}>
                        <Box className="w-5 h-5"/> <span className="ml-2">Equipments</span>
                    </Button>
                    <Button className={buttonStyles('alerts')} onClick={() => handleViewChange('alerts')}>
                        <Bell className="w-5 h-5"/> <span className="ml-2">Alerts</span>
                            </Button>
                        </div>
                        <div className="flex md:hidden space-x-2">
                            <Button className={buttonStyles('domain')} onClick={() => handleViewChange('domain')}>
                                <Home className="w-5 h-5"/>
                            </Button>
                            <Button className={buttonStyles('kpis')} onClick={() => handleViewChange('kpis')}>
                                <BarChart className="w-5 h-5"/>
                            </Button>
                            <Button className={buttonStyles('equipments')}
                                    onClick={() => handleViewChange('equipments')}>
                                <Box className="w-5 h-5"/>
                            </Button>
                            <Button className={buttonStyles('alerts')} onClick={() => handleViewChange('alerts')}>
                                <Bell className="w-5 h-5"/>
                            </Button>
                        </div>
                    </div>
                </nav>
                <main className="flex-1 p-6 overflow-auto bg-gray-50">
                    <CurrentViewComponent/>
                </main>
            </div>
        </div>
            <Toaster/>
        </>
    );
};

export default DashboardPage;
