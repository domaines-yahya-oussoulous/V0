import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchInterventions, setPage, setSearchTerm } from '@/features/intervention/InterventionSlice';
import { RootState, AppDispatch } from '@/store';
import PaginationComponent from "@/components/pagination/PaginationComponent";
import { InterventionDataTable } from "@/features/intervention/InterventionDataTable";
import InterventionColumns from "@/features/intervention/InterventionColumns";

const InterventionPage: React.FC = () => {
    const dispatch: AppDispatch = useDispatch();
    const { interventions, loading, currentPage, itemsPerPage, total, searchTerm, deleteLoading } = useSelector((state: RootState) => state.interventions);

    useEffect(() => {
        dispatch(fetchInterventions(currentPage, itemsPerPage, searchTerm));
    }, [dispatch, currentPage, itemsPerPage, searchTerm]);

    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            dispatch(setPage(page));
        }
    };

    const handleSearch = (searchTerm: string) => {
        dispatch(setSearchTerm(searchTerm));
        dispatch(fetchInterventions(1, itemsPerPage, searchTerm)); // Reset to first page on search
    };

    const totalPages = Math.ceil(total / itemsPerPage);

    return (
        <section className='py-10'>
            <div className='max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8'>
                <h1 className='mb-6 text-3xl font-bold'>All Interventions</h1>
                <InterventionDataTable columns={InterventionColumns} data={interventions} loading={loading || deleteLoading} onSearch={handleSearch} />
                <div className="flex items-center justify-center py-4">
                    <PaginationComponent currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
            </div>
        </section>
    );
};

export default InterventionPage;
