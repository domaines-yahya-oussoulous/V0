import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import {AppDispatch, RootState} from '@/store';
import { CorrectiveMaintenanceDataTable } from '@/features/corrective-maintenance/CorrectiveMaintenanceDataTable';

import PaginationComponent from "@/components/pagination/PaginationComponent.tsx";
import {
    fetchCorrectiveMaintenance,
    setPage,
    setSearchTerm
} from "@/features/corrective-maintenance/CorrectiveMaintenanceSlice.ts";
import {CorrectiveMaintenanceColumns} from "@/features/corrective-maintenance/CorrectiveMaintenanceColumns.tsx";

const CorrectiveMaintenancePage: React.FC = () => {
    const dispatch:AppDispatch = useDispatch();
    const { maintenanceData, loading, error, currentPage, itemsPerPage, total, searchTerm, deleteLoading } = useSelector((state: RootState) => state.correctiveMaintenance);

    useEffect(() => {
        dispatch(fetchCorrectiveMaintenance(currentPage, itemsPerPage, searchTerm));
    }, [dispatch, currentPage, itemsPerPage, searchTerm]);

    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            dispatch(setPage(page));
        }
    };

    const handleSearch = (searchTerm: string) => {
        dispatch(setSearchTerm(searchTerm));
        dispatch(fetchCorrectiveMaintenance(1, itemsPerPage, searchTerm)); // Reset to first page on search
    };

    const totalPages = Math.ceil(total / itemsPerPage);

    return (
        <section className='py-10'>
            <div className='max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8'>
                <h1 className='mb-6 text-3xl font-bold'>Corrective Maintenance</h1>
                {error && <p className="text-red-500">{error}</p>}
                <CorrectiveMaintenanceDataTable columns={CorrectiveMaintenanceColumns} data={maintenanceData} loading={loading || deleteLoading} onSearch={handleSearch} />
                <div className="flex items-center justify-center space-x-2 py-4">
                    <PaginationComponent currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
            </div>
        </section>
    );
};

export default CorrectiveMaintenancePage;
