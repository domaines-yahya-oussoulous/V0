import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import {AppDispatch, RootState} from '@/store';
import {fetchEquipmentCategories, setPage,setSearchTerm} from "@/features/equipment/category/EquipmentCategorySlice.ts";
import {EquipmentCategoryDataTable} from "@/features/equipment/category/EquipmentCategoryDataTable.tsx";
import EquipmentCategoryColumns from "@/features/equipment/category/EquipmentCategoryColumns.tsx";
import PaginationComponent from "@/components/pagination/PaginationComponent.tsx";



const EquipmentCategoryPage: React.FC = () => {
    const dispatch:AppDispatch = useDispatch();
    const { equipmentCategories, loading, error, currentPage, itemsPerPage, total, searchTerm, deleteLoading } = useSelector((state: RootState) => state.equipmentCategories);

    useEffect(() => {
        dispatch(fetchEquipmentCategories(currentPage, itemsPerPage, searchTerm));
    }, [dispatch, currentPage, itemsPerPage, searchTerm]);

    const handlePageChange = (page: number) => {
        if (page > 0 && page <= totalPages) {
            dispatch(setPage(page));
        }
    };

    const handleSearch = (searchTerm: string) => {
        dispatch(setSearchTerm(searchTerm));
        dispatch(fetchEquipmentCategories(1, itemsPerPage, searchTerm)); // Reset to first page on search
    };

    const totalPages = Math.ceil(total / itemsPerPage);

    return (
        <section className='py-10'>
            <div className='max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8'>
                <h1 className='mb-6 text-3xl font-bold'>Equipment Categories</h1>
                {error && <p className="text-red-500">{error}</p>}
                <EquipmentCategoryDataTable columns={EquipmentCategoryColumns} data={equipmentCategories} loading={loading || deleteLoading} onSearch={handleSearch} />
                <div className="flex items-center justify-center space-x-2 py-4">
                    <PaginationComponent currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
                </div>
            </div>
        </section>
    );
};

export default EquipmentCategoryPage;
