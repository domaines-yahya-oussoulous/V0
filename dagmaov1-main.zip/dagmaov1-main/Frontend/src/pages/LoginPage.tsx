import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage, Form } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import images from "@/assets/images";
import PreventAuthRoute from "@/hoc/PreventAuthRoute.tsx";
import { useDispatch, useSelector } from "react-redux";
import { clearError, login, logout } from "@/features/login/loginSlice.ts";
import Loader from "@/components/loader/Loader.tsx";
import React, { useEffect } from "react";
import { AppDispatch, RootState } from "@/store";
import { Toaster } from "@/components/ui/toaster.tsx";
import { toast } from "@/components/ui/use-toast.ts";
import { LogIn, Lock } from 'lucide-react';

// Define form validation schema
const formSchema = z.object({
    email: z.string().email(),
    password: z.string()
});

// Keyframes for animation
const keyframes = `
@keyframes fadeIn {
    0% { opacity: 0; }
    100% { opacity: 1; }
}

@keyframes slideIn {
    0% { transform: translateY(20px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
}
`;

export default function LoginPage() {
    const dispatch: AppDispatch = useDispatch();
    const { loading, error } = useSelector((state: RootState) => state.users);
    const form = useForm<z.infer<typeof formSchema>>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            email: "",
            password: ""
        }
    });

    // Handle form submission
    const handleSubmit = (values: z.infer<typeof formSchema>) => {
        dispatch(logout());
        dispatch(login(values.email, values.password));
    };

    // Handle error display and clearing
    useEffect(() => {
        if (error) {
            toast({
                title: "Error",
                description: error?.response?.data?.message || 'An unknown error occurred',
                variant: "destructive",
            });
            dispatch(clearError()); // Assuming you have a clearError action to reset error state
        }
    }, [error, dispatch]);

    // Show loader while loading
    if (loading) {
        return <Loader loading={loading} />;
    }

    // Render the login page
    return (
        <PreventAuthRoute>
            <style>{keyframes}</style>
            <div className="flex min-h-screen items-center justify-center bg-gradient-to-r from-teal-400 via-cyan-500 to-blue-500 bg-cover bg-center relative animate-fadeIn" style={{backgroundImage: `url(${images.loginHero})`}}>
                <img src={images.companyLogoGold} alt="companyLogoGold" className="fixed top-5 right-5 w-56 object-contain animate-slideIn"/>
                <div className="hidden lg:flex w-1/2"></div>
                <div className="flex flex-col gap-4 min-h-screen items-center justify-center p-4 w-full lg:w-1/2 lg:bg-black lg:bg-opacity-50">
                    <Card className="w-full max-w-sm z-20 bg-white bg-opacity-90 shadow-lg rounded-lg transition-transform transform hover:scale-105 animate-slideIn">
                        <CardHeader>
                            <CardTitle className="flex items-center gap-2 text-[#9e8116]"><LogIn size={24} /> Login</CardTitle>
                            <CardDescription className="text-gray-600">
                                Please enter your email and password
                            </CardDescription>
                        </CardHeader>
                        <CardContent>
                            <Form {...form}>
                                <form className="flex flex-col gap-4" onSubmit={form.handleSubmit(handleSubmit)}>
                                    <FormField control={form.control} name="email" render={({ field }) => (
                                        <FormItem>
                                            <FormLabel className="text-[#9e8116]">Email</FormLabel>
                                            <FormControl>
                                                <Input placeholder="jonh@doe.com" type="email" {...field} className="transition-transform hover:scale-105" />
                                            </FormControl>
                                            <FormDescription className="text-gray-500">
                                                Email address used for authentication in GMAO
                                            </FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )} />
                                    <FormField control={form.control} name="password" render={({ field }) => (
                                        <FormItem>
                                            <FormLabel className="text-[#9e8116]">Password</FormLabel>
                                            <FormControl>
                                                <Input type="password" placeholder="Password" {...field} className="transition-transform hover:scale-105" />
                                            </FormControl>
                                            <FormDescription className="text-gray-500">
                                                Password utilized for authentication in GMAO
                                            </FormDescription>
                                            <FormDescription></FormDescription>
                                            <FormMessage />
                                        </FormItem>
                                    )} />
                                    <Button type="submit" className="bg-[#9e8116] hover:bg-amber-400 text-white transition-transform transform hover:scale-105">
                                        <Lock size={20} className="mr-2" /> Login
                                    </Button>
                                </form>
                            </Form>
                        </CardContent>
                    </Card>
                </div>
            </div>
            <Toaster />
        </PreventAuthRoute>
    );
}
